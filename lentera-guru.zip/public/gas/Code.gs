/**
 * Lentera Guru — SMP Zainul Hasan Genggong
 * Backend Google Apps Script + Google Spreadsheet
 *
 * Cara Deploy:
 * 1. Buka Google Spreadsheet baru (atau gunakan script.google.com).
 * 2. Klik Ekstensi -> Apps Script.
 * 3. Salin seluruh isi file Code.gs ini ke editor Code.gs.
 * 4. Buat file HTML baru bernama "Index" (Index.html), lalu tempel isi file Index.html hasil unduhan.
 * 5. Klik Terapkan -> Deployment Baru -> Jenis: Aplikasi Web.
 *    - Jalankan sebagai: Saya (pemilik spreadsheet)
 *    - Yang memiliki akses: Siapa saja / Pengguna dengan Akun Google (sesuai kebutuhan)
 */

var SCHEMA = {
  classes: {
    sheetName: 'Classes',
    headers: ['id', 'ownerId', 'name', 'gradeLevel', 'academicYear', 'homeroomTeacher', 'createdAt', 'updatedAt'],
    numericCols: []
  },
  subjects: {
    sheetName: 'Subjects',
    headers: ['id', 'ownerId', 'code', 'name', 'createdAt', 'updatedAt'],
    numericCols: []
  },
  students: {
    sheetName: 'Students',
    headers: ['id', 'ownerId', 'nis', 'fullName', 'gender', 'classId', 'createdAt', 'updatedAt'],
    numericCols: []
  },
  categories: {
    sheetName: 'GradingCategories',
    headers: ['id', 'ownerId', 'subjectId', 'name', 'weight', 'createdAt', 'updatedAt'],
    numericCols: ['weight']
  },
  grades: {
    sheetName: 'AcademicGrades',
    headers: ['id', 'ownerId', 'date', 'classId', 'subjectId', 'categoryId', 'studentId', 'score', 'assessmentType', 'chapter', 'assessmentOrder', 'assessmentLabel', 'notes', 'createdAt', 'updatedAt'],
    numericCols: ['score', 'assessmentOrder']
  },
  attitudes: {
    sheetName: 'AttitudeAssessments',
    headers: ['id', 'ownerId', 'date', 'classId', 'subjectId', 'studentId', 'aspect', 'predicate', 'notes', 'createdAt', 'updatedAt'],
    numericCols: []
  },
  journals: {
    sheetName: 'TeachingJournals',
    headers: ['id', 'ownerId', 'date', 'lessonHours', 'classId', 'subjectId', 'topic', 'presentCount', 'sickCount', 'permissionCount', 'absentCount', 'reflection', 'createdAt', 'updatedAt'],
    numericCols: ['presentCount', 'sickCount', 'permissionCount', 'absentCount']
  },
  attendances: {
    sheetName: 'StudentAttendance',
    headers: ['id', 'ownerId', 'journalId', 'date', 'classId', 'subjectId', 'studentId', 'status', 'createdAt', 'updatedAt'],
    numericCols: []
  },
  lessonSlots: {
    sheetName: 'LessonSlots',
    headers: ['id', 'ownerId', 'label', 'startTime', 'endTime', 'order', 'createdAt', 'updatedAt'],
    numericCols: ['order']
  },
  teachingSchedules: {
    sheetName: 'TeachingSchedules',
    headers: ['id', 'ownerId', 'dayOfWeek', 'slotId', 'classId', 'subjectId', 'createdAt', 'updatedAt'],
    numericCols: ['dayOfWeek']
  },
  users: {
    sheetName: 'Users',
    headers: ['id', 'uid', 'email', 'displayName', 'role', 'status', 'nip', 'subjectSpecialty', 'createdAt', 'updatedAt'],
    numericCols: []
  }
};

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Lentera Guru — SMP Zainul Hasan Genggong')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1.0')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function onOpen() {
  try {
    SpreadsheetApp.getUi()
      .createMenu('Lentera Guru')
      .addItem('Inisialisasi Tab Database', 'gasInitializeDatabase')
      .addToUi();
  } catch (e) {
    // Ignore when not running inside UI container
  }
}

function gasInitializeDatabase() {
  var ss = getTargetSpreadsheet_();
  ensureAllSheets_(ss);
  return ss.getUrl();
}

function getTargetSpreadsheet_() {
  var active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) {
    return active;
  }
  var props = PropertiesService.getScriptProperties();
  var savedId = props.getProperty('SPREADSHEET_ID');
  if (savedId) {
    try {
      return SpreadsheetApp.openById(savedId);
    } catch (e) {
      // Recreate if missing/deleted
    }
  }
  var created = SpreadsheetApp.create('Database Lentera Guru — SMP Zainul Hasan Genggong');
  props.setProperty('SPREADSHEET_ID', created.getId());
  return created;
}

function ensureSheet_(ss, key) {
  var cfg = SCHEMA[key];
  var sheet = ss.getSheetByName(cfg.sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(cfg.sheetName);
  }
  if (sheet.getLastRow() === 0) {
    var headerRange = sheet.getRange(1, 1, 1, cfg.headers.length);
    headerRange.setValues([cfg.headers]);
    headerRange.setFontWeight('bold');
    headerRange.setBackground('#1E3A8A');
    headerRange.setFontColor('#FFFFFF');
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, sheet.getMaxRows(), cfg.headers.length).setNumberFormat('@');
    for (var i = 0; i < cfg.numericCols.length; i++) {
      var colIdx = cfg.headers.indexOf(cfg.numericCols[i]) + 1;
      if (colIdx > 0) {
        sheet.getRange(2, colIdx, sheet.getMaxRows() - 1, 1).setNumberFormat('0.##');
      }
    }
  }
  return sheet;
}

function ensureAllSheets_(ss) {
  var keys = Object.keys(SCHEMA);
  for (var i = 0; i < keys.length; i++) {
    ensureSheet_(ss, keys[i]);
  }
  // Remove default empty "Sheet1" if we created other tabs
  var defaultSheet = ss.getSheetByName('Sheet1');
  if (defaultSheet && ss.getSheets().length > 1 && defaultSheet.getLastRow() === 0) {
    try {
      ss.deleteSheet(defaultSheet);
    } catch (e) {}
  }
}

function getCurrentOwnerInfo_() {
  var email = '';
  try {
    email = Session.getActiveUser().getEmail() || Session.getEffectiveUser().getEmail() || '';
  } catch (e) {
    email = '';
  }
  if (!email) {
    email = 'guru@smpzaha.sch.id';
  }
  var displayName = email.split('@')[0].replace(/[._-]+/g, ' ');
  displayName = displayName.replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  return {
    uid: email,
    email: email,
    displayName: displayName || 'Guru Pengajar'
  };
}

function newId_() {
  return Utilities.getUuid();
}

function nowIso_() {
  return new Date().toISOString();
}

function formatCellValue_(val, headerName, numericCols, tz) {
  if (val === null || val === undefined || val === '') {
    if (headerName === 'assessmentOrder') return '';
    return numericCols.indexOf(headerName) >= 0 ? 0 : '';
  }
  if (numericCols.indexOf(headerName) >= 0) {
    var num = Number(val);
    if (headerName === 'assessmentOrder') {
      return isNaN(num) || num <= 0 ? '' : num;
    }
    return isNaN(num) ? 0 : num;
  }
  if (Object.prototype.toString.call(val) === '[object Date]') {
    if (headerName === 'date') {
      return Utilities.formatDate(val, tz, 'yyyy-MM-dd');
    }
    if (headerName === 'startTime' || headerName === 'endTime') {
      return Utilities.formatDate(val, tz, 'HH:mm');
    }
    return val.toISOString();
  }
  return String(val);
}

function readSheetObjects_(ss, key) {
  var cfg = SCHEMA[key];
  var sheet = ensureSheet_(ss, key);
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) {
    return [];
  }
  var lastCol = Math.max(cfg.headers.length, sheet.getLastColumn());
  var rawHeaders = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var colIndexByHeader = {};
  for (var hc = 0; hc < rawHeaders.length; hc++) {
    var hName = String(rawHeaders[hc] || '').trim();
    if (hName && colIndexByHeader[hName] === undefined) {
      colIndexByHeader[hName] = hc;
    }
  }
  var tz = Session.getScriptTimeZone() || 'Asia/Jakarta';
  var values = sheet.getRange(2, 1, lastRow - 1, lastCol).getValues();
  var out = [];
  for (var r = 0; r < values.length; r++) {
    var row = values[r];
    var idIdx = colIndexByHeader['id'] !== undefined ? colIndexByHeader['id'] : 0;
    if (!row[idIdx]) continue;
    var obj = {};
    for (var c = 0; c < cfg.headers.length; c++) {
      var h = cfg.headers[c];
      var colPos = colIndexByHeader[h];
      var rawCell = colPos !== undefined ? row[colPos] : '';
      obj[h] = formatCellValue_(rawCell, h, cfg.numericCols, tz);
    }
    out.push(obj);
  }
  return out;
}

function writeSheetObjects_(ss, key, items) {
  var cfg = SCHEMA[key];
  var sheet = ensureSheet_(ss, key);
  var maxRows = sheet.getMaxRows();
  var clearCols = Math.max(cfg.headers.length, sheet.getLastColumn());
  var headerRange = sheet.getRange(1, 1, 1, cfg.headers.length);
  headerRange.setValues([cfg.headers]);
  headerRange.setFontWeight('bold');
  headerRange.setBackground('#1E3A8A');
  headerRange.setFontColor('#FFFFFF');
  if (clearCols > cfg.headers.length) {
    sheet.getRange(1, cfg.headers.length + 1, 1, clearCols - cfg.headers.length).clearContent();
  }
  if (maxRows > 1) {
    sheet.getRange(2, 1, maxRows - 1, clearCols).clearContent();
  }
  if (!items || items.length === 0) {
    return;
  }
  var rows = [];
  for (var i = 0; i < items.length; i++) {
    var item = items[i];
    var row = [];
    for (var c = 0; c < cfg.headers.length; c++) {
      var h = cfg.headers[c];
      var v = item[h];
      if (v === undefined || v === null || v === '') {
        if (h === 'assessmentOrder') {
          row.push('');
        } else {
          row.push(cfg.numericCols.indexOf(h) >= 0 ? 0 : '');
        }
      } else if (cfg.numericCols.indexOf(h) >= 0) {
        var n = Number(v);
        if (h === 'assessmentOrder') {
          row.push(isNaN(n) || n <= 0 ? '' : n);
        } else {
          row.push(isNaN(n) ? 0 : n);
        }
      } else {
        row.push(String(v));
      }
    }
    rows.push(row);
  }
  var targetRange = sheet.getRange(2, 1, rows.length, cfg.headers.length);
  targetRange.setNumberFormat('@');
  for (var k = 0; k < cfg.numericCols.length; k++) {
    var colIdx = cfg.headers.indexOf(cfg.numericCols[k]) + 1;
    if (colIdx > 0) {
      sheet.getRange(2, colIdx, rows.length, 1).setNumberFormat('0.##');
    }
  }
  targetRange.setValues(rows);
}

function appendSheetObjects_(ss, key, newItems) {
  if (!newItems || newItems.length === 0) return;
  var cfg = SCHEMA[key];
  var sheet = ensureSheet_(ss, key);
  var lastCol = Math.max(1, sheet.getLastColumn());
  var rawHeaders = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var activeHeaders = [];
  var seen = {};
  for (var hc = 0; hc < rawHeaders.length; hc++) {
    var hName = String(rawHeaders[hc] || '').trim();
    if (hName) {
      activeHeaders.push(hName);
      seen[hName] = true;
    }
  }
  var appendedMissing = false;
  for (var ch = 0; ch < cfg.headers.length; ch++) {
    if (!seen[cfg.headers[ch]]) {
      activeHeaders.push(cfg.headers[ch]);
      seen[cfg.headers[ch]] = true;
      appendedMissing = true;
    }
  }
  if (appendedMissing) {
    var syncRange = sheet.getRange(1, 1, 1, activeHeaders.length);
    syncRange.setValues([activeHeaders]);
    syncRange.setFontWeight('bold');
    syncRange.setBackground('#1E3A8A');
    syncRange.setFontColor('#FFFFFF');
  }
  var startRow = Math.max(2, sheet.getLastRow() + 1);
  var rows = [];
  for (var i = 0; i < newItems.length; i++) {
    var item = newItems[i];
    var row = [];
    for (var c = 0; c < activeHeaders.length; c++) {
      var h = activeHeaders[c];
      var v = item[h];
      if (v === undefined || v === null || v === '') {
        if (h === 'assessmentOrder') {
          row.push('');
        } else {
          row.push(cfg.numericCols.indexOf(h) >= 0 ? 0 : '');
        }
      } else if (cfg.numericCols.indexOf(h) >= 0) {
        var n = Number(v);
        if (h === 'assessmentOrder') {
          row.push(isNaN(n) || n <= 0 ? '' : n);
        } else {
          row.push(isNaN(n) ? 0 : n);
        }
      } else {
        row.push(String(v));
      }
    }
    rows.push(row);
  }
  var targetRange = sheet.getRange(startRow, 1, rows.length, activeHeaders.length);
  targetRange.setNumberFormat('@');
  for (var k = 0; k < cfg.numericCols.length; k++) {
    var colIdx = activeHeaders.indexOf(cfg.numericCols[k]) + 1;
    if (colIdx > 0) {
      sheet.getRange(startRow, colIdx, rows.length, 1).setNumberFormat('0.##');
    }
  }
  targetRange.setValues(rows);
}

function resolveCurrentUserProfile_(ss, owner) {
  var users = readSheetObjects_(ss, 'users');
  var existing = null;
  for (var i = 0; i < users.length; i++) {
    if (users[i].uid === owner.uid || String(users[i].email || '').toLowerCase() === String(owner.email || '').toLowerCase()) {
      existing = users[i];
      break;
    }
  }
  if (!existing) {
    var ts = nowIso_();
    var assignedRole = users.length === 0 ? 'admin' : 'guru';
    existing = {
      id: owner.uid,
      uid: owner.uid,
      email: owner.email,
      displayName: owner.displayName || (assignedRole === 'admin' ? 'Administrator' : 'Guru Pengajar'),
      role: assignedRole,
      status: 'active',
      nip: '',
      subjectSpecialty: '',
      createdAt: ts,
      updatedAt: ts
    };
    appendSheetObjects_(ss, 'users', [existing]);
  }
  return existing;
}

function filterOwned_(items, ownerUid) {
  var out = [];
  for (var i = 0; i < items.length; i++) {
    var itemOwner = items[i].ownerId;
    if (!itemOwner || itemOwner === ownerUid) {
      out.push(items[i]);
    }
  }
  return out;
}

function getSnapshot_(ss, owner) {
  var resolvedOwner = owner || getCurrentOwnerInfo_();
  var userProfile = resolveCurrentUserProfile_(ss, resolvedOwner);
  var allUsers = readSheetObjects_(ss, 'users');
  return {
    classes: filterOwned_(readSheetObjects_(ss, 'classes'), resolvedOwner.uid),
    subjects: filterOwned_(readSheetObjects_(ss, 'subjects'), resolvedOwner.uid),
    students: filterOwned_(readSheetObjects_(ss, 'students'), resolvedOwner.uid),
    categories: filterOwned_(readSheetObjects_(ss, 'categories'), resolvedOwner.uid),
    grades: filterOwned_(readSheetObjects_(ss, 'grades'), resolvedOwner.uid),
    attitudes: filterOwned_(readSheetObjects_(ss, 'attitudes'), resolvedOwner.uid),
    journals: filterOwned_(readSheetObjects_(ss, 'journals'), resolvedOwner.uid),
    attendances: filterOwned_(readSheetObjects_(ss, 'attendances'), resolvedOwner.uid),
    lessonSlots: filterOwned_(readSheetObjects_(ss, 'lessonSlots'), resolvedOwner.uid),
    teachingSchedules: filterOwned_(readSheetObjects_(ss, 'teachingSchedules'), resolvedOwner.uid),
    userProfile: userProfile,
    userProfiles: userProfile.role === 'admin' ? allUsers : []
  };
}

function withLock_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    var ss = getTargetSpreadsheet_();
    ensureAllSheets_(ss);
    var owner = getCurrentOwnerInfo_();
    var profile = resolveCurrentUserProfile_(ss, owner);
    if (profile.status === 'inactive') {
      throw new Error('Akun Anda sedang dinonaktifkan oleh Administrator.');
    }
    var result = fn(ss, owner, profile);
    SpreadsheetApp.flush();
    return {
      result: result,
      snapshot: getSnapshot_(ss, owner)
    };
  } finally {
    lock.releaseLock();
  }
}

function gasGetBootstrapData() {
  var ss = getTargetSpreadsheet_();
  ensureAllSheets_(ss);
  var owner = getCurrentOwnerInfo_();
  var profile = resolveCurrentUserProfile_(ss, owner);
  return {
    user: owner,
    userProfile: profile,
    spreadsheetUrl: ss.getUrl(),
    spreadsheetName: ss.getName(),
    snapshot: getSnapshot_(ss, owner)
  };
}

/* ===========================
 * MULTI-USER PROFILES & RBAC
 * =========================== */
function gasUpdateOwnProfile(input) {
  return withLock_(function (ss, owner) {
    var users = readSheetObjects_(ss, 'users');
    var ts = nowIso_();
    for (var i = 0; i < users.length; i++) {
      if (users[i].uid === owner.uid) {
        users[i].displayName = String(input.displayName || users[i].displayName).trim();
        users[i].nip = String(input.nip || '').trim();
        users[i].subjectSpecialty = String(input.subjectSpecialty || '').trim();
        users[i].updatedAt = ts;
      }
    }
    writeSheetObjects_(ss, 'users', users);
    return null;
  });
}

function gasAdminCreateUser(input) {
  return withLock_(function (ss, owner, profile) {
    if (profile.role !== 'admin') {
      throw new Error('Hanya Administrator yang dapat menambah pengguna.');
    }
    var email = String(input.email || '').trim().toLowerCase();
    if (!email) {
      throw new Error('Email pengguna wajib diisi.');
    }
    var users = readSheetObjects_(ss, 'users');
    for (var i = 0; i < users.length; i++) {
      if (String(users[i].email || '').toLowerCase() === email) {
        throw new Error('Email ini sudah terdaftar pada daftar pengguna.');
      }
    }
    var ts = nowIso_();
    appendSheetObjects_(ss, 'users', [{
      id: email,
      uid: email,
      email: email,
      displayName: String(input.displayName || 'Guru Pengajar').trim(),
      role: input.role === 'admin' ? 'admin' : 'guru',
      status: 'active',
      nip: String(input.nip || '').trim(),
      subjectSpecialty: String(input.subjectSpecialty || '').trim(),
      createdAt: ts,
      updatedAt: ts
    }]);
    return email;
  });
}

function gasAdminUpdateUser(targetUid, input) {
  return withLock_(function (ss, owner, profile) {
    if (profile.role !== 'admin') {
      throw new Error('Hanya Administrator yang dapat mengubah data pengguna.');
    }
    var nextRole = input.role === 'admin' ? 'admin' : 'guru';
    var nextStatus = input.status === 'inactive' ? 'inactive' : 'active';
    if (targetUid === owner.uid && (nextRole !== 'admin' || nextStatus !== 'active')) {
      throw new Error('Anda tidak dapat mencabut hak Administrator atau menonaktifkan akun Anda sendiri.');
    }
    var users = readSheetObjects_(ss, 'users');
    var ts = nowIso_();
    for (var i = 0; i < users.length; i++) {
      if (users[i].uid === targetUid) {
        users[i].displayName = String(input.displayName || users[i].displayName).trim();
        users[i].role = nextRole;
        users[i].status = nextStatus;
        users[i].nip = String(input.nip || '').trim();
        users[i].subjectSpecialty = String(input.subjectSpecialty || '').trim();
        users[i].updatedAt = ts;
      }
    }
    writeSheetObjects_(ss, 'users', users);
    return null;
  });
}

function gasAdminDeleteUser(targetUid) {
  return withLock_(function (ss, owner, profile) {
    if (profile.role !== 'admin') {
      throw new Error('Hanya Administrator yang dapat menghapus pengguna.');
    }
    if (targetUid === owner.uid) {
      throw new Error('Anda tidak dapat menghapus profil akun Anda sendiri.');
    }
    var users = readSheetObjects_(ss, 'users').filter(function (u) { return u.uid !== targetUid; });
    writeSheetObjects_(ss, 'users', users);
    return null;
  });
}

/* ===========================
 * CLASSES CRUD
 * =========================== */
function gasAddClass(input) {
  return withLock_(function (ss, owner) {
    var id = newId_();
    var ts = nowIso_();
    appendSheetObjects_(ss, 'classes', [{
      id: id,
      ownerId: owner.uid,
      name: String(input.name || '').trim(),
      gradeLevel: String(input.gradeLevel || '').trim(),
      academicYear: String(input.academicYear || '').trim(),
      homeroomTeacher: String(input.homeroomTeacher || '').trim(),
      createdAt: ts,
      updatedAt: ts
    }]);
    return id;
  });
}

function gasUpdateClass(id, input) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'classes');
    var ts = nowIso_();
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) {
        list[i].name = String(input.name || '').trim();
        list[i].gradeLevel = String(input.gradeLevel || '').trim();
        list[i].academicYear = String(input.academicYear || '').trim();
        list[i].homeroomTeacher = String(input.homeroomTeacher || '').trim();
        list[i].updatedAt = ts;
      }
    }
    writeSheetObjects_(ss, 'classes', list);
    return null;
  });
}

function gasDeleteClass(id) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'classes').filter(function (x) { return x.id !== id; });
    writeSheetObjects_(ss, 'classes', list);
    return null;
  });
}

function gasDeleteClassesBulk(ids) {
  return withLock_(function (ss, owner) {
    var idMap = {};
    for (var i = 0; i < (ids || []).length; i++) {
      if (ids[i]) idMap[String(ids[i])] = true;
    }
    var list = readSheetObjects_(ss, 'classes');
    var deleted = 0;
    var kept = [];
    for (var j = 0; j < list.length; j++) {
      var item = list[j];
      var owned = !item.ownerId || item.ownerId === owner.uid;
      if (owned && idMap[item.id]) {
        deleted++;
      } else {
        kept.push(item);
      }
    }
    writeSheetObjects_(ss, 'classes', kept);
    return deleted;
  });
}

/* ===========================
 * SUBJECTS CRUD
 * =========================== */
function gasAddSubject(input) {
  return withLock_(function (ss, owner) {
    var id = newId_();
    var ts = nowIso_();
    appendSheetObjects_(ss, 'subjects', [{
      id: id,
      ownerId: owner.uid,
      code: String(input.code || '').trim().toUpperCase(),
      name: String(input.name || '').trim(),
      createdAt: ts,
      updatedAt: ts
    }]);
    return id;
  });
}

function gasUpdateSubject(id, input) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'subjects');
    var ts = nowIso_();
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) {
        list[i].code = String(input.code || '').trim().toUpperCase();
        list[i].name = String(input.name || '').trim();
        list[i].updatedAt = ts;
      }
    }
    writeSheetObjects_(ss, 'subjects', list);
    return null;
  });
}

function gasDeleteSubject(id) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'subjects').filter(function (x) { return x.id !== id; });
    writeSheetObjects_(ss, 'subjects', list);
    return null;
  });
}

function gasDeleteSubjectsBulk(ids) {
  return withLock_(function (ss, owner) {
    var idMap = {};
    for (var i = 0; i < (ids || []).length; i++) {
      if (ids[i]) idMap[String(ids[i])] = true;
    }
    var list = readSheetObjects_(ss, 'subjects');
    var deleted = 0;
    var kept = [];
    for (var j = 0; j < list.length; j++) {
      var item = list[j];
      var owned = !item.ownerId || item.ownerId === owner.uid;
      if (owned && idMap[item.id]) {
        deleted++;
      } else {
        kept.push(item);
      }
    }
    writeSheetObjects_(ss, 'subjects', kept);
    return deleted;
  });
}

/* ===========================
 * STUDENTS CRUD & BULK IMPORT
 * =========================== */
function gasAddStudent(input) {
  return withLock_(function (ss, owner) {
    var id = newId_();
    var ts = nowIso_();
    appendSheetObjects_(ss, 'students', [{
      id: id,
      ownerId: owner.uid,
      nis: String(input.nis || '').trim(),
      fullName: String(input.fullName || '').trim(),
      gender: input.gender === 'P' ? 'P' : 'L',
      classId: String(input.classId || ''),
      createdAt: ts,
      updatedAt: ts
    }]);
    return id;
  });
}

function gasUpdateStudent(id, input) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'students');
    var ts = nowIso_();
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) {
        list[i].nis = String(input.nis || '').trim();
        list[i].fullName = String(input.fullName || '').trim();
        list[i].gender = input.gender === 'P' ? 'P' : 'L';
        list[i].classId = String(input.classId || '');
        list[i].updatedAt = ts;
      }
    }
    writeSheetObjects_(ss, 'students', list);
    return null;
  });
}

function gasDeleteStudent(id) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'students').filter(function (x) { return x.id !== id; });
    writeSheetObjects_(ss, 'students', list);
    return null;
  });
}

function gasDeleteStudentsBulk(ids) {
  return withLock_(function (ss, owner) {
    var idMap = {};
    for (var i = 0; i < (ids || []).length; i++) {
      if (ids[i]) idMap[String(ids[i])] = true;
    }
    var list = readSheetObjects_(ss, 'students');
    var deleted = 0;
    var kept = [];
    for (var j = 0; j < list.length; j++) {
      var item = list[j];
      var owned = !item.ownerId || item.ownerId === owner.uid;
      if (owned && idMap[item.id]) {
        deleted++;
      } else {
        kept.push(item);
      }
    }
    writeSheetObjects_(ss, 'students', kept);
    return deleted;
  });
}

function gasBulkImportStudents(rows, createMissingClasses, defaultAcademicYear) {
  return withLock_(function (ss, owner) {
    var existingClasses = readSheetObjects_(ss, 'classes');
    var classMap = {};
    for (var i = 0; i < existingClasses.length; i++) {
      classMap[String(existingClasses[i].name || '').trim().toLowerCase()] = existingClasses[i].id;
    }

    var newClasses = [];
    var missingNames = {};
    for (var r = 0; r < rows.length; r++) {
      var row = rows[r];
      if (!row.classId && row.className) {
        var key = String(row.className).trim().toLowerCase();
        if (key && !classMap[key] && !missingNames[key]) {
          missingNames[key] = String(row.className).trim();
        }
      }
    }

    var ts = nowIso_();
    if (createMissingClasses) {
      var missingKeys = Object.keys(missingNames);
      for (var m = 0; m < missingKeys.length; m++) {
        var mk = missingKeys[m];
        var cname = missingNames[mk];
        var cid = newId_();
        var guessLevel = cname.split(' ')[0] || 'Umum';
        classMap[mk] = cid;
        newClasses.push({
          id: cid,
          ownerId: owner.uid,
          name: cname,
          gradeLevel: 'Tingkat ' + guessLevel,
          academicYear: defaultAcademicYear || '2026/2027',
          homeroomTeacher: '',
          createdAt: ts,
          updatedAt: ts
        });
      }
      if (newClasses.length > 0) {
        appendSheetObjects_(ss, 'classes', newClasses);
      }
    }

    var newStudents = [];
    for (var j = 0; j < rows.length; j++) {
      var st = rows[j];
      var resolvedClassId = st.classId || classMap[String(st.className || '').trim().toLowerCase()];
      if (!resolvedClassId) continue;
      newStudents.push({
        id: newId_(),
        ownerId: owner.uid,
        nis: String(st.nis || '').trim(),
        fullName: String(st.fullName || '').trim(),
        gender: st.gender === 'P' ? 'P' : 'L',
        classId: resolvedClassId,
        createdAt: ts,
        updatedAt: ts
      });
    }
    if (newStudents.length > 0) {
      appendSheetObjects_(ss, 'students', newStudents);
    }

    return {
      importedCount: newStudents.length,
      createdClassesCount: newClasses.length
    };
  });
}

/* ===========================
 * GRADING CATEGORIES CRUD
 * =========================== */
function gasAddCategory(input) {
  return withLock_(function (ss, owner) {
    var id = newId_();
    var ts = nowIso_();
    appendSheetObjects_(ss, 'categories', [{
      id: id,
      ownerId: owner.uid,
      subjectId: String(input.subjectId || ''),
      name: String(input.name || '').trim(),
      weight: Number(input.weight || 0),
      createdAt: ts,
      updatedAt: ts
    }]);
    return id;
  });
}

function gasUpdateCategory(id, input) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'categories');
    var ts = nowIso_();
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) {
        list[i].subjectId = String(input.subjectId || '');
        list[i].name = String(input.name || '').trim();
        list[i].weight = Number(input.weight || 0);
        list[i].updatedAt = ts;
      }
    }
    writeSheetObjects_(ss, 'categories', list);
    return null;
  });
}

function gasDeleteCategory(id) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'categories').filter(function (x) { return x.id !== id; });
    writeSheetObjects_(ss, 'categories', list);
    return null;
  });
}

/* ===========================
 * ACADEMIC GRADES CRUD & BATCH
 * =========================== */
function gasSaveBatchGrades(entries) {
  return withLock_(function (ss, owner) {
    var existing = readSheetObjects_(ss, 'grades');
    var byId = {};
    for (var i = 0; i < existing.length; i++) {
      byId[existing[i].id] = existing[i];
    }
    var ts = nowIso_();
    var toAppend = [];
    for (var j = 0; j < entries.length; j++) {
      var e = entries[j];
      var rawOrder = Number(e.assessmentOrder);
      var validOrder = !isNaN(rawOrder) && rawOrder >= 1 ? Math.round(rawOrder) : '';
      var cleanType = e.assessmentType === 'sumatif' ? 'sumatif' : (e.assessmentType === 'formatif' ? 'formatif' : '');
      var cleanChapter = String(e.chapter || '').trim();
      var cleanLabel = String(e.assessmentLabel || '').trim();
      if (e.existingId && byId[e.existingId]) {
        var target = byId[e.existingId];
        target.date = String(e.date || '');
        target.classId = String(e.classId || '');
        target.subjectId = String(e.subjectId || '');
        target.categoryId = String(e.categoryId || '');
        target.studentId = String(e.studentId || '');
        target.score = Number(e.score || 0);
        target.assessmentType = cleanType;
        target.chapter = cleanChapter;
        target.assessmentOrder = validOrder;
        target.assessmentLabel = cleanLabel;
        target.notes = String(e.notes || '').trim();
        target.updatedAt = ts;
      } else {
        toAppend.push({
          id: newId_(),
          ownerId: owner.uid,
          date: String(e.date || ''),
          classId: String(e.classId || ''),
          subjectId: String(e.subjectId || ''),
          categoryId: String(e.categoryId || ''),
          studentId: String(e.studentId || ''),
          score: Number(e.score || 0),
          assessmentType: cleanType,
          chapter: cleanChapter,
          assessmentOrder: validOrder,
          assessmentLabel: cleanLabel,
          notes: String(e.notes || '').trim(),
          createdAt: ts,
          updatedAt: ts
        });
      }
    }
    writeSheetObjects_(ss, 'grades', existing.concat(toAppend));
    return null;
  });
}

function gasUpdateGrade(id, input) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'grades');
    var ts = nowIso_();
    var rawOrder = Number(input.assessmentOrder);
    var validOrder = !isNaN(rawOrder) && rawOrder >= 1 ? Math.round(rawOrder) : '';
    var cleanType = input.assessmentType === 'sumatif' ? 'sumatif' : (input.assessmentType === 'formatif' ? 'formatif' : '');
    var cleanChapter = String(input.chapter || '').trim();
    var cleanLabel = String(input.assessmentLabel || '').trim();
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) {
        list[i].date = String(input.date || '');
        list[i].classId = String(input.classId || '');
        list[i].subjectId = String(input.subjectId || '');
        list[i].categoryId = String(input.categoryId || '');
        list[i].studentId = String(input.studentId || '');
        list[i].score = Number(input.score || 0);
        list[i].assessmentType = cleanType;
        list[i].chapter = cleanChapter;
        list[i].assessmentOrder = validOrder;
        list[i].assessmentLabel = cleanLabel;
        list[i].notes = String(input.notes || '').trim();
        list[i].updatedAt = ts;
      }
    }
    writeSheetObjects_(ss, 'grades', list);
    return null;
  });
}

function gasDeleteGrade(id) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'grades').filter(function (x) { return x.id !== id; });
    writeSheetObjects_(ss, 'grades', list);
    return null;
  });
}

function gasDeleteGradesBulk(ids) {
  return withLock_(function (ss, owner) {
    var idMap = {};
    for (var i = 0; i < (ids || []).length; i++) {
      if (ids[i]) idMap[String(ids[i])] = true;
    }
    var list = readSheetObjects_(ss, 'grades');
    var deleted = 0;
    var kept = [];
    for (var j = 0; j < list.length; j++) {
      var item = list[j];
      var owned = !item.ownerId || item.ownerId === owner.uid;
      if (owned && idMap[item.id]) {
        deleted++;
      } else {
        kept.push(item);
      }
    }
    writeSheetObjects_(ss, 'grades', kept);
    return deleted;
  });
}

/* ===========================
 * ATTITUDE ASSESSMENTS CRUD & BATCH
 * =========================== */
function gasSaveBatchAttitudes(entries) {
  return withLock_(function (ss, owner) {
    var existing = readSheetObjects_(ss, 'attitudes');
    var byId = {};
    for (var i = 0; i < existing.length; i++) {
      byId[existing[i].id] = existing[i];
    }
    var ts = nowIso_();
    var toAppend = [];
    for (var j = 0; j < entries.length; j++) {
      var e = entries[j];
      if (e.existingId && byId[e.existingId]) {
        var target = byId[e.existingId];
        target.date = String(e.date || '');
        target.classId = String(e.classId || '');
        target.subjectId = String(e.subjectId || '');
        target.studentId = String(e.studentId || '');
        target.aspect = String(e.aspect || '').trim();
        target.predicate = String(e.predicate || 'Baik');
        target.notes = String(e.notes || '').trim();
        target.updatedAt = ts;
      } else {
        toAppend.push({
          id: newId_(),
          ownerId: owner.uid,
          date: String(e.date || ''),
          classId: String(e.classId || ''),
          subjectId: String(e.subjectId || ''),
          studentId: String(e.studentId || ''),
          aspect: String(e.aspect || '').trim(),
          predicate: String(e.predicate || 'Baik'),
          notes: String(e.notes || '').trim(),
          createdAt: ts,
          updatedAt: ts
        });
      }
    }
    writeSheetObjects_(ss, 'attitudes', existing.concat(toAppend));
    return null;
  });
}

function gasUpdateAttitude(id, input) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'attitudes');
    var ts = nowIso_();
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) {
        list[i].date = String(input.date || '');
        list[i].classId = String(input.classId || '');
        list[i].subjectId = String(input.subjectId || '');
        list[i].studentId = String(input.studentId || '');
        list[i].aspect = String(input.aspect || '').trim();
        list[i].predicate = String(input.predicate || 'Baik');
        list[i].notes = String(input.notes || '').trim();
        list[i].updatedAt = ts;
      }
    }
    writeSheetObjects_(ss, 'attitudes', list);
    return null;
  });
}

function gasDeleteAttitude(id) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'attitudes').filter(function (x) { return x.id !== id; });
    writeSheetObjects_(ss, 'attitudes', list);
    return null;
  });
}

function gasDeleteAttitudesBulk(ids) {
  return withLock_(function (ss, owner) {
    var idMap = {};
    for (var i = 0; i < (ids || []).length; i++) {
      if (ids[i]) idMap[String(ids[i])] = true;
    }
    var list = readSheetObjects_(ss, 'attitudes');
    var deleted = 0;
    var kept = [];
    for (var j = 0; j < list.length; j++) {
      var item = list[j];
      var owned = !item.ownerId || item.ownerId === owner.uid;
      if (owned && idMap[item.id]) {
        deleted++;
      } else {
        kept.push(item);
      }
    }
    writeSheetObjects_(ss, 'attitudes', kept);
    return deleted;
  });
}

/* ===========================
 * TEACHING JOURNALS & ATTENDANCE
 * =========================== */
function gasSaveJournalWithAttendance(input, studentStatuses) {
  return withLock_(function (ss, owner) {
    var journals = readSheetObjects_(ss, 'journals');
    var attendances = readSheetObjects_(ss, 'attendances');
    var ts = nowIso_();
    var journalId = input.id || newId_();
    var updatedExisting = false;

    for (var i = 0; i < journals.length; i++) {
      if (journals[i].id === journalId) {
        journals[i].date = String(input.date || '');
        journals[i].lessonHours = String(input.lessonHours || '').trim();
        journals[i].classId = String(input.classId || '');
        journals[i].subjectId = String(input.subjectId || '');
        journals[i].topic = String(input.topic || '').trim();
        journals[i].presentCount = Number(input.presentCount || 0);
        journals[i].sickCount = Number(input.sickCount || 0);
        journals[i].permissionCount = Number(input.permissionCount || 0);
        journals[i].absentCount = Number(input.absentCount || 0);
        journals[i].reflection = String(input.reflection || '').trim();
        journals[i].updatedAt = ts;
        updatedExisting = true;
        break;
      }
    }

    if (!updatedExisting) {
      journals.push({
        id: journalId,
        ownerId: owner.uid,
        date: String(input.date || ''),
        lessonHours: String(input.lessonHours || '').trim(),
        classId: String(input.classId || ''),
        subjectId: String(input.subjectId || ''),
        topic: String(input.topic || '').trim(),
        presentCount: Number(input.presentCount || 0),
        sickCount: Number(input.sickCount || 0),
        permissionCount: Number(input.permissionCount || 0),
        absentCount: Number(input.absentCount || 0),
        reflection: String(input.reflection || '').trim(),
        createdAt: ts,
        updatedAt: ts
      });
    }

    var keptAttendances = attendances.filter(function (a) {
      return a.journalId !== journalId;
    });

    var newAttendances = [];
    for (var j = 0; j < studentStatuses.length; j++) {
      var st = studentStatuses[j];
      newAttendances.push({
        id: newId_(),
        ownerId: owner.uid,
        journalId: journalId,
        date: String(input.date || ''),
        classId: String(input.classId || ''),
        subjectId: String(input.subjectId || ''),
        studentId: String(st.studentId || ''),
        status: String(st.status || 'Hadir'),
        createdAt: ts,
        updatedAt: ts
      });
    }

    writeSheetObjects_(ss, 'journals', journals);
    writeSheetObjects_(ss, 'attendances', keptAttendances.concat(newAttendances));
    return null;
  });
}

function gasDeleteJournal(id) {
  return withLock_(function (ss) {
    var journals = readSheetObjects_(ss, 'journals').filter(function (x) { return x.id !== id; });
    var attendances = readSheetObjects_(ss, 'attendances').filter(function (x) { return x.journalId !== id; });
    writeSheetObjects_(ss, 'journals', journals);
    writeSheetObjects_(ss, 'attendances', attendances);
    return null;
  });
}

function gasDeleteJournalsBulk(ids) {
  return withLock_(function (ss, owner) {
    var idMap = {};
    for (var i = 0; i < (ids || []).length; i++) {
      if (ids[i]) idMap[String(ids[i])] = true;
    }
    var journals = readSheetObjects_(ss, 'journals');
    var deleted = 0;
    var keptJournals = [];
    var removedJournalIds = {};
    for (var j = 0; j < journals.length; j++) {
      var item = journals[j];
      var owned = !item.ownerId || item.ownerId === owner.uid;
      if (owned && idMap[item.id]) {
        deleted++;
        removedJournalIds[item.id] = true;
      } else {
        keptJournals.push(item);
      }
    }
    var attendances = readSheetObjects_(ss, 'attendances').filter(function (a) {
      var owned = !a.ownerId || a.ownerId === owner.uid;
      return !(owned && removedJournalIds[a.journalId]);
    });
    writeSheetObjects_(ss, 'journals', keptJournals);
    writeSheetObjects_(ss, 'attendances', attendances);
    return deleted;
  });
}

/* ===========================
 * LESSON SLOTS & SCHEDULES
 * =========================== */
function gasAddLessonSlot(input) {
  return withLock_(function (ss, owner) {
    var id = newId_();
    var ts = nowIso_();
    appendSheetObjects_(ss, 'lessonSlots', [{
      id: id,
      ownerId: owner.uid,
      label: String(input.label || '').trim(),
      startTime: String(input.startTime || ''),
      endTime: String(input.endTime || ''),
      order: Number(input.order || 0),
      createdAt: ts,
      updatedAt: ts
    }]);
    return id;
  });
}

function gasUpdateLessonSlot(id, input) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'lessonSlots');
    var ts = nowIso_();
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) {
        list[i].label = String(input.label || '').trim();
        list[i].startTime = String(input.startTime || '');
        list[i].endTime = String(input.endTime || '');
        list[i].order = Number(input.order || 0);
        list[i].updatedAt = ts;
      }
    }
    writeSheetObjects_(ss, 'lessonSlots', list);
    return null;
  });
}

function gasDeleteLessonSlot(id) {
  return withLock_(function (ss) {
    var slots = readSheetObjects_(ss, 'lessonSlots').filter(function (x) { return x.id !== id; });
    var schedules = readSheetObjects_(ss, 'teachingSchedules').filter(function (x) { return x.slotId !== id; });
    writeSheetObjects_(ss, 'lessonSlots', slots);
    writeSheetObjects_(ss, 'teachingSchedules', schedules);
    return null;
  });
}

function gasSeedDefaultLessonSlots(defaultSlots) {
  return withLock_(function (ss, owner) {
    var ts = nowIso_();
    var items = [];
    for (var i = 0; i < defaultSlots.length; i++) {
      var s = defaultSlots[i];
      items.push({
        id: newId_(),
        ownerId: owner.uid,
        label: s.label,
        startTime: s.startTime,
        endTime: s.endTime,
        order: Number(s.order || i + 1),
        createdAt: ts,
        updatedAt: ts
      });
    }
    appendSheetObjects_(ss, 'lessonSlots', items);
    return null;
  });
}

function gasAddSchedule(input) {
  return withLock_(function (ss, owner) {
    var id = newId_();
    var ts = nowIso_();
    appendSheetObjects_(ss, 'teachingSchedules', [{
      id: id,
      ownerId: owner.uid,
      dayOfWeek: Number(input.dayOfWeek || 0),
      slotId: String(input.slotId || ''),
      classId: String(input.classId || ''),
      subjectId: String(input.subjectId || ''),
      createdAt: ts,
      updatedAt: ts
    }]);
    return id;
  });
}

function gasUpdateSchedule(id, input) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'teachingSchedules');
    var ts = nowIso_();
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) {
        list[i].dayOfWeek = Number(input.dayOfWeek || 0);
        list[i].slotId = String(input.slotId || '');
        list[i].classId = String(input.classId || '');
        list[i].subjectId = String(input.subjectId || '');
        list[i].updatedAt = ts;
      }
    }
    writeSheetObjects_(ss, 'teachingSchedules', list);
    return null;
  });
}

function gasDeleteSchedule(id) {
  return withLock_(function (ss) {
    var list = readSheetObjects_(ss, 'teachingSchedules').filter(function (x) { return x.id !== id; });
    writeSheetObjects_(ss, 'teachingSchedules', list);
    return null;
  });
}

/* ===========================
 * SEED SAMPLE DATA
 * =========================== */
function gasSeedSampleData(defaultSlots) {
  return withLock_(function (ss, owner) {
    var ts = nowIso_();
    var c1Id = newId_();
    var c2Id = newId_();
    var s1Id = newId_();
    var s2Id = newId_();

    appendSheetObjects_(ss, 'classes', [
      {
        id: c1Id,
        ownerId: owner.uid,
        name: 'VII A',
        gradeLevel: 'Kelas VII',
        academicYear: '2026/2027',
        homeroomTeacher: owner.displayName || 'Wali Kelas VII A',
        createdAt: ts,
        updatedAt: ts
      },
      {
        id: c2Id,
        ownerId: owner.uid,
        name: 'VII B',
        gradeLevel: 'Kelas VII',
        academicYear: '2026/2027',
        homeroomTeacher: 'Dra. Siti Aminah, M.Pd.',
        createdAt: ts,
        updatedAt: ts
      }
    ]);

    appendSheetObjects_(ss, 'subjects', [
      { id: s1Id, ownerId: owner.uid, code: 'MAT-07', name: 'Matematika', createdAt: ts, updatedAt: ts },
      { id: s2Id, ownerId: owner.uid, code: 'IPA-07', name: 'Ilmu Pengetahuan Alam', createdAt: ts, updatedAt: ts }
    ]);

    var sampleStudents = [
      { nis: '2026101', fullName: 'Ahmad Rizky Pratama', gender: 'L', classId: c1Id },
      { nis: '2026102', fullName: 'Aulia Putri Maharani', gender: 'P', classId: c1Id },
      { nis: '2026103', fullName: 'Bagas Adriansyah', gender: 'L', classId: c1Id },
      { nis: '2026104', fullName: 'Citra Dewi Lestari', gender: 'P', classId: c1Id },
      { nis: '2026105', fullName: 'Dimas Saputra Wijaya', gender: 'L', classId: c1Id },
      { nis: '2026201', fullName: 'Fajar Ramadhan', gender: 'L', classId: c2Id },
      { nis: '2026202', fullName: 'Gita Kusuma Wardani', gender: 'P', classId: c2Id },
      { nis: '2026203', fullName: 'Hendra Gunawan', gender: 'L', classId: c2Id },
      { nis: '2026204', fullName: 'Intan Permata Sari', gender: 'P', classId: c2Id }
    ];
    var studentRows = [];
    for (var i = 0; i < sampleStudents.length; i++) {
      studentRows.push({
        id: newId_(),
        ownerId: owner.uid,
        nis: sampleStudents[i].nis,
        fullName: sampleStudents[i].fullName,
        gender: sampleStudents[i].gender,
        classId: sampleStudents[i].classId,
        createdAt: ts,
        updatedAt: ts
      });
    }
    appendSheetObjects_(ss, 'students', studentRows);

    var catNames = ['Tugas Harian', 'Ulangan Harian', 'PTS', 'PAS'];
    var catRows = [];
    for (var c = 0; c < catNames.length; c++) {
      catRows.push({
        id: newId_(),
        ownerId: owner.uid,
        subjectId: s1Id,
        name: catNames[c],
        weight: 25,
        createdAt: ts,
        updatedAt: ts
      });
    }
    appendSheetObjects_(ss, 'categories', catRows);

    var c1Students = studentRows.slice(0, 5);
    var dates = ['2026-11-02', '2026-11-09', '2026-11-16'];
    var scoreMatrix = [
      [88, 84, 90],
      [92, 95, 94],
      [74, 78, 82],
      [85, 86, 89],
      [68, 72, 79]
    ];
    var gradeRows = [];
    var attitudeRows = [];
    for (var idx = 0; idx < c1Students.length; idx++) {
      var st = c1Students[idx];
      for (var d = 0; d < dates.length; d++) {
        gradeRows.push({
          id: newId_(),
          ownerId: owner.uid,
          date: dates[d],
          classId: c1Id,
          subjectId: s1Id,
          categoryId: catRows[d % catRows.length].id,
          studentId: st.id,
          score: scoreMatrix[idx][d],
          notes: d === 2 ? 'Menguasai materi fungsi kuadrat' : '',
          createdAt: ts,
          updatedAt: ts
        });
      }
      attitudeRows.push({
        id: newId_(),
        ownerId: owner.uid,
        date: '2026-11-16',
        classId: c1Id,
        subjectId: s1Id,
        studentId: st.id,
        aspect: idx % 2 === 0 ? 'Kedisiplinan' : 'Keaktifan',
        predicate: idx === 1 ? 'Sangat Baik' : idx === 4 ? 'Cukup' : 'Baik',
        notes: idx === 1 ? 'Membantu menjelaskan soal di papan tulis dengan runtut.' : idx === 4 ? 'Perlu pendampingan fokus saat latihan mandiri.' : '',
        createdAt: ts,
        updatedAt: ts
      });
    }
    appendSheetObjects_(ss, 'grades', gradeRows);
    appendSheetObjects_(ss, 'attitudes', attitudeRows);

    var journalId = newId_();
    appendSheetObjects_(ss, 'journals', [{
      id: journalId,
      ownerId: owner.uid,
      date: '2026-11-16',
      lessonHours: 'Jam ke 1-2 (07:00 - 08:30)',
      classId: c1Id,
      subjectId: s1Id,
      topic: 'Persamaan dan Fungsi Kuadrat',
      presentCount: 4,
      sickCount: 1,
      permissionCount: 0,
      absentCount: 0,
      reflection: 'Sebagian besar siswa aktif berdiskusi. Latihan pemfaktoran perlu diperkuat pada pertemuan berikutnya.',
      createdAt: ts,
      updatedAt: ts
    }]);

    var attRows = [];
    for (var a = 0; a < c1Students.length; a++) {
      attRows.push({
        id: newId_(),
        ownerId: owner.uid,
        journalId: journalId,
        date: '2026-11-16',
        classId: c1Id,
        subjectId: s1Id,
        studentId: c1Students[a].id,
        status: a === 4 ? 'Sakit' : 'Hadir',
        createdAt: ts,
        updatedAt: ts
      });
    }
    appendSheetObjects_(ss, 'attendances', attRows);

    var slotRows = [];
    for (var sl = 0; sl < defaultSlots.length; sl++) {
      slotRows.push({
        id: newId_(),
        ownerId: owner.uid,
        label: defaultSlots[sl].label,
        startTime: defaultSlots[sl].startTime,
        endTime: defaultSlots[sl].endTime,
        order: Number(defaultSlots[sl].order || sl + 1),
        createdAt: ts,
        updatedAt: ts
      });
    }
    appendSheetObjects_(ss, 'lessonSlots', slotRows);

    var todayDay = new Date().getDay();
    if (slotRows.length >= 3) {
      appendSheetObjects_(ss, 'teachingSchedules', [
        { id: newId_(), ownerId: owner.uid, dayOfWeek: todayDay, slotId: slotRows[0].id, classId: c1Id, subjectId: s1Id, createdAt: ts, updatedAt: ts },
        { id: newId_(), ownerId: owner.uid, dayOfWeek: todayDay, slotId: slotRows[2].id, classId: c2Id, subjectId: s2Id, createdAt: ts, updatedAt: ts }
      ]);
    }
    return null;
  });
}

/* ===========================
 * RESTORE BACKUP DATA (JSON)
 * =========================== */
function gasRestoreBackupData(payload, mode) {
  return withLock_(function (ss, owner) {
    var raw = (payload && payload.data) || {};
    var ts = nowIso_();
    var isMerge = mode === 'merge';

    function mergeById(existingArr, incomingArr) {
      var otherOwners = [];
      var myExisting = [];
      for (var p = 0; p < existingArr.length; p++) {
        var row = existingArr[p];
        if (row.ownerId && row.ownerId !== owner.uid) {
          otherOwners.push(row);
        } else {
          myExisting.push(row);
        }
      }
      if (!isMerge) return otherOwners.concat(incomingArr);
      var map = {};
      var order = [];
      for (var i = 0; i < myExisting.length; i++) {
        map[myExisting[i].id] = myExisting[i];
        order.push(myExisting[i].id);
      }
      for (var j = 0; j < incomingArr.length; j++) {
        var item = incomingArr[j];
        if (!map[item.id]) order.push(item.id);
        map[item.id] = item;
      }
      var res = [];
      for (var k = 0; k < order.length; k++) {
        res.push(map[order[k]]);
      }
      return otherOwners.concat(res);
    }

    function toIdSet(arr) {
      var s = {};
      for (var i = 0; i < arr.length; i++) {
        if (!arr[i].ownerId || arr[i].ownerId === owner.uid) {
          s[arr[i].id] = true;
        }
      }
      return s;
    }

    var skippedOrphans = 0;
    var restoredCounts = {
      classes: 0,
      subjects: 0,
      lessonSlots: 0,
      students: 0,
      gradingCategories: 0,
      teachingJournals: 0,
      teachingSchedules: 0,
      academicGrades: 0,
      attitudeAssessments: 0,
      studentAttendance: 0
    };

    var inClasses = (raw.classes || []).map(function (c) {
      return {
        id: c.id || newId_(),
        ownerId: owner.uid,
        name: String(c.name || 'Kelas').trim(),
        gradeLevel: String(c.gradeLevel || 'Umum').trim(),
        academicYear: String(c.academicYear || '2026/2027').trim(),
        homeroomTeacher: String(c.homeroomTeacher || '').trim(),
        createdAt: ts,
        updatedAt: ts
      };
    });
    var inSubjects = (raw.subjects || []).map(function (s) {
      return {
        id: s.id || newId_(),
        ownerId: owner.uid,
        code: String(s.code || 'MAPEL').trim().toUpperCase(),
        name: String(s.name || 'Mata Pelajaran').trim(),
        createdAt: ts,
        updatedAt: ts
      };
    });
    var inSlots = (raw.lessonSlots || []).map(function (sl, idx) {
      return {
        id: sl.id || newId_(),
        ownerId: owner.uid,
        label: String(sl.label || ('Jam ke-' + (idx + 1))).trim(),
        startTime: String(sl.startTime || '07:00'),
        endTime: String(sl.endTime || '07:45'),
        order: Number(sl.order !== undefined ? sl.order : idx + 1),
        createdAt: ts,
        updatedAt: ts
      };
    });

    var finalClasses = mergeById(readSheetObjects_(ss, 'classes'), inClasses);
    var finalSubjects = mergeById(readSheetObjects_(ss, 'subjects'), inSubjects);
    var finalSlots = mergeById(readSheetObjects_(ss, 'lessonSlots'), inSlots);

    var knownClasses = toIdSet(finalClasses);
    var knownSubjects = toIdSet(finalSubjects);
    var knownSlots = toIdSet(finalSlots);

    var inStudents = [];
    (raw.students || []).forEach(function (st) {
      if (!knownClasses[st.classId]) { skippedOrphans++; return; }
      inStudents.push({
        id: st.id || newId_(),
        ownerId: owner.uid,
        nis: String(st.nis || '000').trim(),
        fullName: String(st.fullName || 'Siswa').trim(),
        gender: st.gender === 'P' ? 'P' : 'L',
        classId: st.classId,
        createdAt: ts,
        updatedAt: ts
      });
    });

    var inCategories = [];
    (raw.gradingCategories || []).forEach(function (cat) {
      if (!knownSubjects[cat.subjectId]) { skippedOrphans++; return; }
      inCategories.push({
        id: cat.id || newId_(),
        ownerId: owner.uid,
        subjectId: cat.subjectId,
        name: String(cat.name || 'Kategori').trim(),
        weight: Number(cat.weight || 0),
        createdAt: ts,
        updatedAt: ts
      });
    });

    var inJournals = [];
    (raw.teachingJournals || []).forEach(function (j) {
      if (!knownClasses[j.classId] || !knownSubjects[j.subjectId]) { skippedOrphans++; return; }
      inJournals.push({
        id: j.id || newId_(),
        ownerId: owner.uid,
        date: String(j.date || ''),
        lessonHours: String(j.lessonHours || 'Jam ke-1').trim(),
        classId: j.classId,
        subjectId: j.subjectId,
        topic: String(j.topic || 'Materi Pembelajaran').trim(),
        presentCount: Number(j.presentCount || 0),
        sickCount: Number(j.sickCount || 0),
        permissionCount: Number(j.permissionCount || 0),
        absentCount: Number(j.absentCount || 0),
        reflection: String(j.reflection || '').trim(),
        createdAt: ts,
        updatedAt: ts
      });
    });

    var inSchedules = [];
    (raw.teachingSchedules || []).forEach(function (sch) {
      if (!knownSlots[sch.slotId] || !knownClasses[sch.classId] || !knownSubjects[sch.subjectId]) {
        skippedOrphans++;
        return;
      }
      inSchedules.push({
        id: sch.id || newId_(),
        ownerId: owner.uid,
        dayOfWeek: Number(sch.dayOfWeek !== undefined ? sch.dayOfWeek : 1),
        slotId: sch.slotId,
        classId: sch.classId,
        subjectId: sch.subjectId,
        createdAt: ts,
        updatedAt: ts
      });
    });

    var finalStudents = mergeById(readSheetObjects_(ss, 'students'), inStudents);
    var finalCategories = mergeById(readSheetObjects_(ss, 'categories'), inCategories);
    var finalJournals = mergeById(readSheetObjects_(ss, 'journals'), inJournals);
    var finalSchedules = mergeById(readSheetObjects_(ss, 'teachingSchedules'), inSchedules);

    var knownStudents = toIdSet(finalStudents);
    var knownCategories = toIdSet(finalCategories);
    var knownJournals = toIdSet(finalJournals);

    var inGrades = [];
    (raw.academicGrades || []).forEach(function (g) {
      if (!knownClasses[g.classId] || !knownSubjects[g.subjectId] || !knownCategories[g.categoryId] || !knownStudents[g.studentId]) {
        skippedOrphans++;
        return;
      }
      var rawOrd = Number(g.assessmentOrder);
      var cleanType = g.assessmentType === 'sumatif' ? 'sumatif' : (g.assessmentType === 'formatif' ? 'formatif' : '');
      inGrades.push({
        id: g.id || newId_(),
        ownerId: owner.uid,
        date: String(g.date || ''),
        classId: g.classId,
        subjectId: g.subjectId,
        categoryId: g.categoryId,
        studentId: g.studentId,
        score: Number(g.score || 0),
        assessmentType: cleanType,
        chapter: String(g.chapter || '').trim(),
        assessmentOrder: !isNaN(rawOrd) && rawOrd >= 1 ? Math.round(rawOrd) : '',
        assessmentLabel: String(g.assessmentLabel || '').trim(),
        notes: String(g.notes || '').trim(),
        createdAt: ts,
        updatedAt: ts
      });
    });

    var inAttitudes = [];
    (raw.attitudeAssessments || []).forEach(function (a) {
      if (!knownClasses[a.classId] || !knownSubjects[a.subjectId] || !knownStudents[a.studentId]) {
        skippedOrphans++;
        return;
      }
      inAttitudes.push({
        id: a.id || newId_(),
        ownerId: owner.uid,
        date: String(a.date || ''),
        classId: a.classId,
        subjectId: a.subjectId,
        studentId: a.studentId,
        aspect: String(a.aspect || 'Kedisiplinan').trim(),
        predicate: String(a.predicate || 'Baik'),
        notes: String(a.notes || '').trim(),
        createdAt: ts,
        updatedAt: ts
      });
    });

    var inAttendances = [];
    (raw.studentAttendance || []).forEach(function (att) {
      if (!knownJournals[att.journalId] || !knownClasses[att.classId] || !knownSubjects[att.subjectId] || !knownStudents[att.studentId]) {
        skippedOrphans++;
        return;
      }
      inAttendances.push({
        id: att.id || newId_(),
        ownerId: owner.uid,
        journalId: att.journalId,
        date: String(att.date || ''),
        classId: att.classId,
        subjectId: att.subjectId,
        studentId: att.studentId,
        status: String(att.status || 'Hadir'),
        createdAt: ts,
        updatedAt: ts
      });
    });

    var finalGrades = mergeById(readSheetObjects_(ss, 'grades'), inGrades);
    var finalAttitudes = mergeById(readSheetObjects_(ss, 'attitudes'), inAttitudes);
    var finalAttendances = mergeById(readSheetObjects_(ss, 'attendances'), inAttendances);

    writeSheetObjects_(ss, 'classes', finalClasses);
    writeSheetObjects_(ss, 'subjects', finalSubjects);
    writeSheetObjects_(ss, 'lessonSlots', finalSlots);
    writeSheetObjects_(ss, 'students', finalStudents);
    writeSheetObjects_(ss, 'categories', finalCategories);
    writeSheetObjects_(ss, 'journals', finalJournals);
    writeSheetObjects_(ss, 'teachingSchedules', finalSchedules);
    writeSheetObjects_(ss, 'grades', finalGrades);
    writeSheetObjects_(ss, 'attitudes', finalAttitudes);
    writeSheetObjects_(ss, 'attendances', finalAttendances);

    restoredCounts.classes = inClasses.length;
    restoredCounts.subjects = inSubjects.length;
    restoredCounts.lessonSlots = inSlots.length;
    restoredCounts.students = inStudents.length;
    restoredCounts.gradingCategories = inCategories.length;
    restoredCounts.teachingJournals = inJournals.length;
    restoredCounts.teachingSchedules = inSchedules.length;
    restoredCounts.academicGrades = inGrades.length;
    restoredCounts.attitudeAssessments = inAttitudes.length;
    restoredCounts.studentAttendance = inAttendances.length;

    var totalRestored = 0;
    var countKeys = Object.keys(restoredCounts);
    for (var ck = 0; ck < countKeys.length; ck++) {
      totalRestored += restoredCounts[countKeys[ck]];
    }

    return {
      restoredCounts: restoredCounts,
      totalRestored: totalRestored,
      skippedOrphans: skippedOrphans
    };
  });
}
