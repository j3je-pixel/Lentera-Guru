import React, { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Pencil, Save, Search, Trash2, X } from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useApp } from '../contexts/AppContext';
import {
  ATTITUDE_ASPECTS,
  ATTITUDE_PREDICATES,
  AttitudeAssessment,
  AttitudePredicate,
  FIELD_LIMITS,
} from '../types';
import { formatIndonesianDate, getTodayIso } from '../utils/exportUtils';

type TabKey = 'input' | 'riwayat';

interface AttitudeRowDraft {
  enabled: boolean;
  predicate: AttitudePredicate;
  notes: string;
}

export function SikapPage() {
  const {
    classes,
    subjects,
    students,
    attitudes,
    saveBatchAttitudes,
    updateAttitude,
    deleteAttitude,
    deleteAttitudesBulk,
  } = useApp();

  const [activeTab, setActiveTab] = useState<TabKey>('input');

  const [date, setDate] = useState(getTodayIso());
  const [classId, setClassId] = useState(classes[0]?.id ?? '');
  const [subjectId, setSubjectId] = useState(subjects[0]?.id ?? '');
  const [aspect, setAspect] = useState<string>(ATTITUDE_ASPECTS[0]);
  const [drafts, setDrafts] = useState<Record<string, AttitudeRowDraft>>({});
  const [savingBatch, setSavingBatch] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  // History filters
  const [histClassId, setHistClassId] = useState('ALL');
  const [histAspect, setHistAspect] = useState('ALL');
  const [histPredicate, setHistPredicate] = useState('ALL');
  const [histSearch, setHistSearch] = useState('');

  // Single edit/delete
  const [editing, setEditing] = useState<AttitudeAssessment | null>(null);
  const [editPredicate, setEditPredicate] =
    useState<AttitudePredicate>('Baik');
  const [editAspect, setEditAspect] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<AttitudeAssessment | null>(
    null
  );
  const [savingSingle, setSavingSingle] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleteMode, setBulkDeleteMode] = useState<
    'selected' | 'filtered' | null
  >(null);
  const [bulkDeleting, setBulkDeleting] = useState(false);

  const classMap = useMemo(
    () => new Map(classes.map((c) => [c.id, c.name])),
    [classes]
  );
  const subjectMap = useMemo(
    () => new Map(subjects.map((s) => [s.id, s.name])),
    [subjects]
  );
  const studentMap = useMemo(
    () => new Map(students.map((s) => [s.id, s])),
    [students]
  );

  useEffect(() => {
    if (!classId && classes.length > 0) setClassId(classes[0].id);
  }, [classes, classId]);

  useEffect(() => {
    if (!subjectId && subjects.length > 0) setSubjectId(subjects[0].id);
  }, [subjects, subjectId]);

  const classStudents = useMemo(
    () => students.filter((s) => s.classId === classId),
    [students, classId]
  );

  const existingMap = useMemo(() => {
    const map = new Map<string, AttitudeAssessment>();
    for (const a of attitudes) {
      if (
        a.date === date &&
        a.classId === classId &&
        a.subjectId === subjectId &&
        a.aspect === aspect
      ) {
        map.set(a.studentId, a);
      }
    }
    return map;
  }, [attitudes, date, classId, subjectId, aspect]);

  useEffect(() => {
    const next: Record<string, AttitudeRowDraft> = {};
    for (const st of classStudents) {
      const ex = existingMap.get(st.id);
      next[st.id] = {
        enabled: true,
        predicate: ex?.predicate ?? 'Baik',
        notes: ex?.notes ?? '',
      };
    }
    setDrafts(next);
    setSaveMessage(null);
  }, [classStudents, existingMap]);

  const handleSaveBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!date || !classId || !subjectId || !aspect.trim()) return;

    const entries = classStudents
      .map((st) => {
        const d = drafts[st.id];
        if (!d || !d.enabled) return null;
        const ex = existingMap.get(st.id);
        return {
          existingId: ex?.id,
          date,
          classId,
          subjectId,
          studentId: st.id,
          aspect,
          predicate: d.predicate,
          notes: d.notes,
        };
      })
      .filter((x): x is NonNullable<typeof x> => x !== null);

    if (entries.length === 0) return;

    setSavingBatch(true);
    setSaveMessage(null);
    try {
      await saveBatchAttitudes(entries);
      setSaveMessage(
        `${entries.length} catatan penilaian sikap berhasil disimpan.`
      );
    } finally {
      setSavingBatch(false);
    }
  };

  const filteredHistory = useMemo(() => {
    const q = histSearch.trim().toLowerCase();
    return attitudes.filter((a) => {
      if (histClassId !== 'ALL' && a.classId !== histClassId) return false;
      if (histAspect !== 'ALL' && a.aspect !== histAspect) return false;
      if (histPredicate !== 'ALL' && a.predicate !== histPredicate)
        return false;
      if (q) {
        const st = studentMap.get(a.studentId);
        const matchName = st?.fullName.toLowerCase().includes(q);
        const matchNotes = (a.notes ?? '').toLowerCase().includes(q);
        if (!matchName && !matchNotes) return false;
      }
      return true;
    });
  }, [
    attitudes,
    histClassId,
    histAspect,
    histPredicate,
    histSearch,
    studentMap,
  ]);

  const openEdit = (item: AttitudeAssessment) => {
    setEditing(item);
    setEditAspect(item.aspect);
    setEditPredicate(item.predicate);
    setEditNotes(item.notes ?? '');
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing) return;
    setSavingSingle(true);
    try {
      await updateAttitude(editing.id, {
        date: editing.date,
        classId: editing.classId,
        subjectId: editing.subjectId,
        studentId: editing.studentId,
        aspect: editAspect,
        predicate: editPredicate,
        notes: editNotes,
      });
      setEditing(null);
    } finally {
      setSavingSingle(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setSavingSingle(true);
    try {
      await deleteAttitude(deleteTarget.id);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(deleteTarget.id);
        return next;
      });
      setDeleteTarget(null);
    } finally {
      setSavingSingle(false);
    }
  };

  const filteredIds = useMemo(
    () => filteredHistory.map((a) => a.id),
    [filteredHistory]
  );

  const allFilteredSelected =
    filteredHistory.length > 0 &&
    filteredHistory.every((a) => selectedIds.has(a.id));

  const toggleSelectAll = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allFilteredSelected) {
        for (const id of filteredIds) next.delete(id);
      } else {
        for (const id of filteredIds) next.add(id);
      }
      return next;
    });
  };

  const toggleSelectRow = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleConfirmBulkDelete = async () => {
    const targetIds =
      bulkDeleteMode === 'filtered' ? filteredIds : Array.from(selectedIds);
    if (targetIds.length === 0) {
      setBulkDeleteMode(null);
      return;
    }
    setBulkDeleting(true);
    try {
      await deleteAttitudesBulk(targetIds);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        for (const id of targetIds) next.delete(id);
        return next;
      });
      setBulkDeleteMode(null);
    } finally {
      setBulkDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Penilaian Sikap Siswa
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Catat predikat sikap (Kedisiplinan, Tanggung Jawab, Kerja Sama,
            Keaktifan, Kejujuran) beserta catatan kejadian khusus.
          </p>
        </div>

        <div className="inline-flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-800/80 rounded-lg self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setActiveTab('input')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'input'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
            }`}
          >
            Input Penilaian Sikap
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('riwayat')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'riwayat'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
            }`}
          >
            Riwayat Sikap ({attitudes.length})
          </button>
        </div>
      </div>

      {activeTab === 'input' ? (
        <div className="space-y-5">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Tanggal
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Kelas
              </label>
              <select
                value={classId}
                onChange={(e) => setClassId(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              >
                <option value="">Pilih Kelas</option>
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Mata Pelajaran
              </label>
              <select
                value={subjectId}
                onChange={(e) => setSubjectId(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              >
                <option value="">Pilih Mapel</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.code} · {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Aspek Sikap
              </label>
              <select
                value={aspect}
                onChange={(e) => setAspect(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              >
                {ATTITUDE_ASPECTS.map((asp) => (
                  <option key={asp} value={asp}>
                    {asp}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {saveMessage && (
            <div className="p-3.5 text-sm text-emerald-900 dark:text-emerald-200 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
              <span>{saveMessage}</span>
            </div>
          )}

          {!classId || !subjectId ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center text-sm text-slate-500 dark:text-slate-400">
              Pilih Kelas dan Mata Pelajaran terlebih dahulu untuk mencatat
              penilaian sikap siswa.
            </div>
          ) : classStudents.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center text-sm text-slate-500 dark:text-slate-400">
              Belum ada siswa di kelas yang dipilih.
            </div>
          ) : (
            <form
              onSubmit={handleSaveBatch}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden"
            >
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-xs font-medium text-slate-500 dark:text-slate-400">
                      <th className="py-3 px-4 w-10 text-center">Pilih</th>
                      <th className="py-3 px-4">Siswa</th>
                      <th className="py-3 px-4 w-44">Predikat Sikap</th>
                      <th className="py-3 px-4">Catatan Kejadian Khusus</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                    {classStudents.map((st) => {
                      const d = drafts[st.id] ?? {
                        enabled: true,
                        predicate: 'Baik',
                        notes: '',
                      };
                      const updateRow = (patch: Partial<AttitudeRowDraft>) =>
                        setDrafts((prev) => ({
                          ...prev,
                          [st.id]: { ...d, ...patch },
                        }));

                      return (
                        <tr
                          key={st.id}
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                        >
                          <td className="py-2.5 px-4 text-center">
                            <input
                              type="checkbox"
                              checked={d.enabled}
                              onChange={(e) =>
                                updateRow({ enabled: e.target.checked })
                              }
                              className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
                            />
                          </td>
                          <td className="py-2.5 px-4">
                            <p className="font-medium text-slate-900 dark:text-slate-100">
                              {st.fullName}
                            </p>
                            <p className="font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                              {st.nis}
                            </p>
                          </td>
                          <td className="py-2.5 px-4">
                            <select
                              disabled={!d.enabled}
                              value={d.predicate}
                              onChange={(e) =>
                                updateRow({
                                  predicate: e.target
                                    .value as AttitudePredicate,
                                })
                              }
                              className="w-full px-2.5 py-1.5 text-sm border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 disabled:bg-slate-100 dark:disabled:bg-slate-800/60 disabled:text-slate-400 dark:disabled:text-slate-500"
                            >
                              {ATTITUDE_PREDICATES.map((p) => (
                                <option key={p} value={p}>
                                  {p}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="py-2.5 px-4">
                            <input
                              type="text"
                              disabled={!d.enabled}
                              maxLength={FIELD_LIMITS.ATTITUDE_NOTES}
                              value={d.notes}
                              onChange={(e) =>
                                updateRow({ notes: e.target.value })
                              }
                              placeholder="Contoh: Aktif membantu diskusi kelompok..."
                              className="w-full px-3 py-1.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-md placeholder:text-slate-400 dark:placeholder:text-slate-500 disabled:bg-slate-100 dark:disabled:bg-slate-800/60"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="px-5 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between gap-4">
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Hapus centang pada siswa yang tidak perlu dinilai pada sesi
                  ini.
                </p>
                <button
                  type="submit"
                  disabled={savingBatch}
                  className="inline-flex items-center gap-2 px-5 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Save className="w-4 h-4 shrink-0" />
                  <span>
                    {savingBatch ? 'Menyimpan...' : 'Simpan Penilaian Sikap'}
                  </span>
                </button>
              </div>
            </form>
          )}
        </div>
      ) : (
        <div className="space-y-5">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={histSearch}
                onChange={(e) => setHistSearch(e.target.value)}
                placeholder="Cari siswa atau catatan..."
                className="w-full pl-9 pr-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500"
              />
            </div>

            <select
              value={histClassId}
              onChange={(e) => setHistClassId(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200"
            >
              <option value="ALL">Semua Kelas</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>

            <select
              value={histAspect}
              onChange={(e) => setHistAspect(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200"
            >
              <option value="ALL">Semua Aspek</option>
              {ATTITUDE_ASPECTS.map((asp) => (
                <option key={asp} value={asp}>
                  {asp}
                </option>
              ))}
            </select>

            <select
              value={histPredicate}
              onChange={(e) => setHistPredicate(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200"
            >
              <option value="ALL">Semua Predikat</option>
              {ATTITUDE_PREDICATES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          {filteredHistory.length > 0 && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
                <label className="inline-flex items-center gap-2 cursor-pointer font-medium">
                  <input
                    type="checkbox"
                    checked={allFilteredSelected}
                    onChange={toggleSelectAll}
                    className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
                  />
                  <span>Pilih Semua ({filteredHistory.length})</span>
                </label>
                {selectedIds.size > 0 && (
                  <span className="font-mono text-blue-700 dark:text-blue-400 font-semibold">
                    · {selectedIds.size} terpilih
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {selectedIds.size > 0 && (
                  <button
                    type="button"
                    onClick={() => setBulkDeleteMode('selected')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Hapus Terpilih ({selectedIds.size})</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setBulkDeleteMode('filtered')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/60 rounded-lg cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>
                    Hapus{' '}
                    {filteredHistory.length === attitudes.length
                      ? 'Semua'
                      : 'Sesuai Filter'}{' '}
                    ({filteredHistory.length})
                  </span>
                </button>
              </div>
            </div>
          )}

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
            {filteredHistory.length === 0 ? (
              <div className="p-12 text-center text-sm text-slate-500 dark:text-slate-400">
                Belum ada riwayat penilaian sikap yang sesuai filter.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-xs font-medium text-slate-500 dark:text-slate-400">
                      <th className="py-3 px-3 w-10 text-center">
                        <input
                          type="checkbox"
                          checked={allFilteredSelected}
                          onChange={toggleSelectAll}
                          aria-label="Pilih semua penilaian sikap"
                          className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
                        />
                      </th>
                      <th className="py-3 px-4">Tanggal</th>
                      <th className="py-3 px-4">Siswa</th>
                      <th className="py-3 px-4">Kelas · Mapel</th>
                      <th className="py-3 px-4">Aspek</th>
                      <th className="py-3 px-4">Predikat</th>
                      <th className="py-3 px-4">Catatan Khusus</th>
                      <th className="py-3 px-4 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                    {filteredHistory.map((item) => {
                      const st = studentMap.get(item.studentId);
                      return (
                        <tr
                          key={item.id}
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                        >
                          <td className="py-2.5 px-3 text-center">
                            <input
                              type="checkbox"
                              checked={selectedIds.has(item.id)}
                              onChange={() => toggleSelectRow(item.id)}
                              className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
                            />
                          </td>
                          <td className="py-2.5 px-4 font-mono text-xs text-slate-600 dark:text-slate-300 tabular-nums whitespace-nowrap">
                            {formatIndonesianDate(item.date)}
                          </td>
                          <td className="py-2.5 px-4 font-medium text-slate-900 dark:text-slate-100">
                            {st?.fullName ?? 'Siswa'}
                          </td>
                          <td className="py-2.5 px-4 text-xs text-slate-600 dark:text-slate-300">
                            {classMap.get(item.classId) ?? '-'} ·{' '}
                            {subjectMap.get(item.subjectId) ?? '-'}
                          </td>
                          <td className="py-2.5 px-4 text-slate-700 dark:text-slate-200">
                            {item.aspect}
                          </td>
                          <td className="py-2.5 px-4">
                            <span
                              className={`text-xs font-medium ${
                                item.predicate === 'Sangat Baik'
                                  ? 'text-emerald-700 dark:text-emerald-400'
                                  : item.predicate === 'Baik'
                                  ? 'text-blue-700 dark:text-blue-400'
                                  : item.predicate === 'Cukup'
                                  ? 'text-amber-700 dark:text-amber-400'
                                  : 'text-red-700 dark:text-red-400'
                              }`}
                            >
                              {item.predicate}
                            </span>
                          </td>
                          <td className="py-2.5 px-4 text-xs text-slate-600 dark:text-slate-300 max-w-[240px]">
                            {item.notes || '-'}
                          </td>
                          <td className="py-2.5 px-4 text-right">
                            <div className="inline-flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => openEdit(item)}
                                className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-blue-700 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 rounded-md cursor-pointer"
                                title="Edit Penilaian Sikap"
                              >
                                <Pencil className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTarget(item)}
                                className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-red-700 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-md cursor-pointer"
                                title="Hapus Penilaian Sikap"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 dark:bg-slate-950/70">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display font-semibold text-lg text-slate-900 dark:text-slate-100">
                Edit Penilaian Sikap
              </h2>
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="p-1 text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 rounded-md cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Aspek Sikap
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.ATTITUDE_ASPECT}
                  value={editAspect}
                  onChange={(e) => setEditAspect(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Predikat
                </label>
                <select
                  value={editPredicate}
                  onChange={(e) =>
                    setEditPredicate(e.target.value as AttitudePredicate)
                  }
                  className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                >
                  {ATTITUDE_PREDICATES.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Catatan Kejadian Khusus
                </label>
                <textarea
                  rows={3}
                  maxLength={FIELD_LIMITS.ATTITUDE_NOTES}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setEditing(null)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={savingSingle}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {savingSingle ? 'Menyimpan...' : 'Simpan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Hapus Catatan Sikap"
        description="Apakah Anda yakin ingin menghapus catatan penilaian sikap siswa ini?"
        loading={savingSingle}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <ConfirmModal
        open={Boolean(bulkDeleteMode)}
        title="Hapus Data Penilaian Sikap"
        description={
          bulkDeleteMode === 'filtered'
            ? `Apakah Anda yakin ingin menghapus ${filteredHistory.length} catatan penilaian sikap yang ditampilkan? Tindakan ini tidak dapat dibatalkan.`
            : `Apakah Anda yakin ingin menghapus ${selectedIds.size} catatan penilaian sikap yang dipilih? Tindakan ini tidak dapat dibatalkan.`
        }
        confirmLabel="Ya, Hapus Penilaian"
        loading={bulkDeleting}
        onConfirm={handleConfirmBulkDelete}
        onCancel={() => setBulkDeleteMode(null)}
      />
    </div>
  );
}
