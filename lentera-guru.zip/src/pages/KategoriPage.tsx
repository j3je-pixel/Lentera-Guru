import React, { useMemo, useState } from 'react';
import { Pencil, Plus, Sparkles, Trash2, X } from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useApp } from '../contexts/AppContext';
import { FIELD_LIMITS, GradingCategory } from '../types';

export function KategoriPage() {
  const {
    subjects,
    categories,
    addCategory,
    updateCategory,
    deleteCategory,
  } = useApp();

  const [filterSubjectId, setFilterSubjectId] = useState('ALL');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<GradingCategory | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<GradingCategory | null>(null);

  const [subjectId, setSubjectId] = useState('');
  const [name, setName] = useState('');
  const [weight, setWeight] = useState<string>('25');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  const subjectMap = useMemo(
    () => new Map(subjects.map((s) => [s.id, `${s.code} · ${s.name}`])),
    [subjects]
  );

  const groupedCategories = useMemo(() => {
    const filtered = categories.filter((cat) => {
      if (filterSubjectId !== 'ALL' && cat.subjectId !== filterSubjectId)
        return false;
      return true;
    });

    const groups = new Map<
      string,
      {
        subjectId: string;
        subjectName: string;
        totalWeight: number;
        items: GradingCategory[];
      }
    >();

    for (const cat of filtered) {
      const key = cat.subjectId;
      if (!groups.has(key)) {
        groups.set(key, {
          subjectId: cat.subjectId,
          subjectName: subjectMap.get(cat.subjectId) ?? 'Mapel Tidak Ditemukan',
          totalWeight: 0,
          items: [],
        });
      }
      const grp = groups.get(key)!;
      grp.items.push(cat);
      grp.totalWeight += cat.weight;
    }

    return Array.from(groups.values()).sort((a, b) =>
      a.subjectName.localeCompare(b.subjectName, 'id')
    );
  }, [categories, filterSubjectId, subjectMap]);

  const openCreate = () => {
    setEditing(null);
    setSubjectId(
      filterSubjectId !== 'ALL' ? filterSubjectId : subjects[0]?.id ?? ''
    );
    setName('');
    setWeight('25');
    setFormError('');
    setModalOpen(true);
  };

  const openEdit = (cat: GradingCategory) => {
    setEditing(cat);
    setSubjectId(cat.subjectId);
    setName(cat.name);
    setWeight(String(cat.weight));
    setFormError('');
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numericWeight = Number(weight);
    if (
      !subjectId ||
      !name.trim() ||
      !Number.isFinite(numericWeight) ||
      numericWeight < 0 ||
      numericWeight > 100
    ) {
      setFormError(
        'Mata pelajaran, nama kategori, dan bobot (0–100) wajib diisi.'
      );
      return;
    }
    setSaving(true);
    setFormError('');
    try {
      if (editing) {
        await updateCategory(editing.id, {
          subjectId,
          name,
          weight: numericWeight,
        });
      } else {
        await addCategory({
          subjectId,
          name,
          weight: numericWeight,
        });
      }
      setModalOpen(false);
    } catch (err) {
      setFormError(
        err instanceof Error ? err.message : 'Gagal menyimpan kategori.'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleCreateStandardPreset = async () => {
    const targetSubject =
      filterSubjectId !== 'ALL' ? filterSubjectId : subjects[0]?.id;
    if (!targetSubject) return;
    setSaving(true);
    try {
      const defaults = [
        { name: 'Tugas Harian', weight: 25 },
        { name: 'Ulangan Harian', weight: 25 },
        { name: 'PTS', weight: 25 },
        { name: 'PAS', weight: 25 },
      ];
      for (const item of defaults) {
        await addCategory({
          subjectId: targetSubject,
          name: item.name,
          weight: item.weight,
        });
      }
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      await deleteCategory(deleteTarget.id);
      setDeleteTarget(null);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Kategori Penilaian & Bobot
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Atur komponen penilaian (Tugas Harian, Ulangan Harian, PTS, PAS) dan
            persentase bobot per mata pelajaran — berlaku untuk semua kelas.
          </p>
        </div>

        <button
          type="button"
          onClick={openCreate}
          disabled={subjects.length === 0}
          className="inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4 shrink-0" />
          <span>Tambah Kategori</span>
        </button>
      </div>

      {subjects.length === 0 && (
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-xl p-4 text-sm text-amber-900 dark:text-amber-200">
          Pastikan data <strong>Mata Pelajaran</strong> sudah tersedia sebelum
          mengatur kategori penilaian.
        </div>
      )}

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <select
          value={filterSubjectId}
          onChange={(e) => setFilterSubjectId(e.target.value)}
          className="flex-1 px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
        >
          <option value="ALL">Semua Mata Pelajaran</option>
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.code} · {s.name}
            </option>
          ))}
        </select>

        {subjects.length > 0 && (
          <button
            type="button"
            onClick={handleCreateStandardPreset}
            disabled={saving}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-medium text-blue-800 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-950 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 shrink-0" />
            <span>Buat Paket Bobot 100%</span>
          </button>
        )}
      </div>

      {groupedCategories.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center">
          <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
            Belum ada kategori penilaian
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">
            Tambahkan kategori seperti Tugas Harian, Ulangan Harian, PTS, dan
            PAS beserta bobot persentasenya. Kategori akan berlaku untuk semua
            kelas.
          </p>
          {subjects.length > 0 && (
            <button
              type="button"
              onClick={openCreate}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Kategori Penilaian</span>
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-5">
          {groupedCategories.map((grp) => {
            const isExact100 = Math.abs(grp.totalWeight - 100) < 0.01;
            return (
              <div
                key={grp.subjectId}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden"
              >
                <div className="px-5 py-3.5 bg-slate-50/70 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="font-display font-semibold text-base text-slate-900 dark:text-slate-100">
                      {grp.subjectName}
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Berlaku untuk semua kelas
                    </p>
                  </div>

                  <div className="text-xs font-medium tabular-nums">
                    {isExact100 ? (
                      <span className="text-emerald-700 dark:text-emerald-400">
                        Total Bobot: {grp.totalWeight}% (Ideal)
                      </span>
                    ) : (
                      <span className="text-amber-700 dark:text-amber-400">
                        Total Bobot: {grp.totalWeight}% (Disarankan 100%)
                      </span>
                    )}
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-100 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                        <th className="py-2.5 px-5">Nama Kategori Penilaian</th>
                        <th className="py-2.5 px-4 text-right w-40">
                          Persentase Bobot
                        </th>
                        <th className="py-2.5 px-5 text-right w-28">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                      {grp.items.map((cat) => (
                        <tr
                          key={cat.id}
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                        >
                          <td className="py-3 px-5 font-medium text-slate-900 dark:text-slate-100">
                            {cat.name}
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                            {cat.weight}%
                          </td>
                          <td className="py-3 px-5 text-right">
                            <div className="inline-flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => openEdit(cat)}
                                className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-blue-700 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 rounded-md cursor-pointer"
                                title="Edit Kategori"
                              >
                                <Pencil className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTarget(cat)}
                                className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-red-700 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-md cursor-pointer"
                                title="Hapus Kategori"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 dark:bg-slate-950/70">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display font-semibold text-lg text-slate-900 dark:text-slate-100">
                {editing
                  ? 'Edit Kategori Penilaian'
                  : 'Tambah Kategori Penilaian'}
              </h2>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1 text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 rounded-md cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 p-3 text-xs text-red-800 dark:text-red-200 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 rounded-lg">
                {formError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Mata Pelajaran
                </label>
                <select
                  required
                  value={subjectId}
                  onChange={(e) => setSubjectId(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                >
                  <option value="">Pilih Mata Pelajaran</option>
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.code} · {s.name}
                    </option>
                  ))}
                </select>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5">
                  Kategori dan bobot ini berlaku untuk semua kelas pada mata
                  pelajaran yang dipilih.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Nama Kategori Penilaian
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.CATEGORY_NAME}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Tugas Harian, Ulangan Harian, PTS, PAS"
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Persentase Bobot (%)
                </label>
                <input
                  type="number"
                  required
                  min={0}
                  max={100}
                  step="1"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {saving ? 'Menyimpan...' : 'Simpan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Hapus Kategori Penilaian"
        description={`Yakin ingin menghapus kategori "${deleteTarget?.name}" (${deleteTarget?.weight}%)?`}
        loading={saving}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
