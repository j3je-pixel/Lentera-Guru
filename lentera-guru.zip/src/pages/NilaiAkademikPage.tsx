import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Pencil,
  Plus,
  Save,
  Search,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useApp } from '../contexts/AppContext';
import {
  AcademicGrade,
  AssessmentType,
  DEFAULT_BAB_OPTIONS,
  FIELD_LIMITS,
  MIN_ASSESSMENTS_PER_BAB,
  SUMATIF_SCOPE_OPTIONS,
  isCategoryForAssessmentType,
  isSumatifCategoryName,
  resolveGradeAssessmentType,
} from '../types';
import {
  downloadGradeTemplateExcel,
  formatIndonesianDate,
  getTodayIso,
} from '../utils/exportUtils';

type TabKey = 'input' | 'riwayat';

interface ParsedGradeImportRow {
  rowNumber: number;
  date: string;
  assessmentType: AssessmentType;
  nis: string;
  studentName: string;
  className: string;
  subjectName: string;
  categoryName: string;
  chapter: string;
  assessmentOrder?: number;
  score: number | null;
  notes: string;
  matchedStudentId?: string;
  matchedClassId?: string;
  matchedSubjectId?: string;
  matchedCategoryId?: string;
  existingId?: string;
  error?: string;
}

function normalizeHeader(key: string): string {
  return key
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

function parseExcelDateValue(raw: unknown, fallbackDate: string): string {
  if (raw === null || raw === undefined) return fallbackDate;
  if (typeof raw === 'number' && Number.isFinite(raw)) {
    const parsed = XLSX.SSF.parse_date_code(raw);
    if (parsed && parsed.y && parsed.m && parsed.d) {
      return `${String(parsed.y).padStart(4, '0')}-${String(parsed.m).padStart(
        2,
        '0'
      )}-${String(parsed.d).padStart(2, '0')}`;
    }
  }
  const str = String(raw).trim();
  if (!str) return fallbackDate;

  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;

  const dmyMatch = str.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
  if (dmyMatch) {
    const [, d, m, y] = dmyMatch;
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }

  const ymdSlash = str.match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})$/);
  if (ymdSlash) {
    const [, y, m, d] = ymdSlash;
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }

  return '';
}

function parseOrderFromColumnHeader(normKey: string): number | null {
  const match =
    normKey.match(/^penilaian(?:ke)?(\d{1,2})$/) ||
    normKey.match(/^nilai(\d{1,2})$/) ||
    normKey.match(/^p(\d{1,2})$/) ||
    normKey.match(/^uh(\d{1,2})$/);
  if (!match) return null;
  const num = Number(match[1]);
  return num >= 1 && num <= 20 ? num : null;
}

function sortBabLabels(a: string, b: string): number {
  const numA = a.match(/\d+/)?.[0];
  const numB = b.match(/\d+/)?.[0];
  if (numA && numB && Number(numA) !== Number(numB)) {
    return Number(numA) - Number(numB);
  }
  return a.localeCompare(b, 'id');
}

export function NilaiAkademikPage() {
  const {
    classes,
    subjects,
    students,
    categories,
    grades,
    saveBatchGrades,
    updateGrade,
    deleteGrade,
    deleteGradesBulk,
  } = useApp();

  const [activeTab, setActiveTab] = useState<TabKey>('input');
  const [assessmentType, setAssessmentType] =
    useState<AssessmentType>('formatif');

  // Input form state
  const [classId, setClassId] = useState(classes[0]?.id ?? '');
  const [subjectId, setSubjectId] = useState(subjects[0]?.id ?? '');
  const [categoryId, setCategoryId] = useState('');
  const [selectedChapter, setSelectedChapter] = useState<string>('Bab 1');
  const [customChapterOpen, setCustomChapterOpen] = useState(false);
  const [customChapterInput, setCustomChapterInput] = useState('');

  // Standard (Tanpa Bab) mode inputs
  const [scoreInputs, setScoreInputs] = useState<Record<string, string>>({});
  const [noteInputs, setNoteInputs] = useState<Record<string, string>>({});

  // Bab Matrix mode inputs (minimum 3 assessments per Bab for Formatif, 1+ for Sumatif)
  const [slotCount, setSlotCount] = useState<number>(MIN_ASSESSMENTS_PER_BAB);
  const [activeSlot, setActiveSlot] = useState<number>(1);
  const [matrixScores, setMatrixScores] = useState<
    Record<string, Record<number, string>>
  >({});
  const [matrixNotes, setMatrixNotes] = useState<
    Record<string, Record<number, string>>
  >({});

  const [savingBatch, setSavingBatch] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Import Modal state
  const [importOpen, setImportOpen] = useState(false);
  const [importFileName, setImportFileName] = useState('');
  const [importRawRows, setImportRawRows] = useState<Record<string, unknown>[]>(
    []
  );
  const [importDefaultDate, setImportDefaultDate] = useState(getTodayIso());
  const [importDefaultAssessmentType, setImportDefaultAssessmentType] =
    useState<AssessmentType>('formatif');
  const [importDefaultClassId, setImportDefaultClassId] = useState('');
  const [importDefaultSubjectId, setImportDefaultSubjectId] = useState('');
  const [importDefaultCategoryId, setImportDefaultCategoryId] = useState('');
  const [importDefaultChapter, setImportDefaultChapter] = useState('Bab 1');
  const [importError, setImportError] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const importFileRef = useRef<HTMLInputElement | null>(null);

  // History filter & selection state
  const [histAssessmentType, setHistAssessmentType] = useState<
    'ALL' | AssessmentType
  >('ALL');
  const [histClassId, setHistClassId] = useState('ALL');
  const [histSubjectId, setHistSubjectId] = useState('ALL');
  const [histCategoryId, setHistCategoryId] = useState('ALL');
  const [histChapter, setHistChapter] = useState('ALL');
  const [histDate, setHistDate] = useState('');
  const [histSearch, setHistSearch] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleteMode, setBulkDeleteMode] = useState<
    'selected' | 'filtered' | null
  >(null);
  const [bulkDeleting, setBulkDeleting] = useState(false);

  // Edit single history grade
  const [editingGrade, setEditingGrade] = useState<AcademicGrade | null>(null);
  const [editAssessmentType, setEditAssessmentType] =
    useState<AssessmentType>('formatif');
  const [editScore, setEditScore] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editDate, setEditDate] = useState('');
  const [editChapter, setEditChapter] = useState('');
  const [editOrder, setEditOrder] = useState('1');
  const [deleteTarget, setDeleteTarget] = useState<AcademicGrade | null>(null);
  const [savingSingle, setSavingSingle] = useState(false);

  const classMap = useMemo(
    () => new Map(classes.map((c) => [c.id, c.name])),
    [classes]
  );
  const subjectMap = useMemo(
    () => new Map(subjects.map((s) => [s.id, s.name])),
    [subjects]
  );
  const categoryMap = useMemo(
    () => new Map(categories.map((c) => [c.id, c.name])),
    [categories]
  );
  const studentMap = useMemo(
    () => new Map(students.map((s) => [s.id, s])),
    [students]
  );

  // Ensure default selections when data loads
  useEffect(() => {
    if (!classId && classes.length > 0) setClassId(classes[0].id);
  }, [classes, classId]);

  useEffect(() => {
    if (!subjectId && subjects.length > 0) setSubjectId(subjects[0].id);
  }, [subjects, subjectId]);

  const availableCategories = useMemo(() => {
    const orderRank = (name: string): number => {
      const lower = name.trim().toLowerCase();
      if (lower.includes('tugas harian')) return 1;
      if (lower.includes('ulangan harian')) return 2;
      if (lower === 'pts' || lower.includes('sts')) return 3;
      if (lower === 'pas' || lower.includes('sas')) return 4;
      return 10;
    };
    return categories
      .filter(
        (c) =>
          c.subjectId === subjectId &&
          (!c.classId || c.classId === classId) &&
          isCategoryForAssessmentType(c.name, assessmentType)
      )
      .sort((a, b) => {
        const diff = orderRank(a.name) - orderRank(b.name);
        return diff !== 0 ? diff : a.name.localeCompare(b.name, 'id');
      });
  }, [categories, classId, subjectId, assessmentType]);

  useEffect(() => {
    if (
      availableCategories.length > 0 &&
      !availableCategories.some((c) => c.id === categoryId)
    ) {
      setCategoryId(availableCategories[0].id);
    } else if (availableCategories.length === 0) {
      setCategoryId('');
    }
  }, [availableCategories, categoryId]);

  const gradeTypeCounts = useMemo(() => {
    let formatif = 0;
    let sumatif = 0;
    for (const g of grades) {
      const t = resolveGradeAssessmentType(g, categoryMap.get(g.categoryId));
      if (t === 'sumatif') sumatif += 1;
      else formatif += 1;
    }
    return { formatif, sumatif };
  }, [grades, categoryMap]);

  const handleSwitchAssessmentType = (nextType: AssessmentType) => {
    setAssessmentType(nextType);
    if (activeTab === 'riwayat') {
      setHistAssessmentType(nextType);
    }
    setSaveMessage(null);
    setSaveError(null);
    if (nextType === 'sumatif') {
      setSelectedChapter((prev) =>
        !prev ||
        prev === 'Bab 1' ||
        DEFAULT_BAB_OPTIONS.includes(
          prev as (typeof DEFAULT_BAB_OPTIONS)[number]
        )
          ? SUMATIF_SCOPE_OPTIONS[0]
          : prev
      );
      setSlotCount(1);
      setActiveSlot(1);
    } else {
      setSelectedChapter((prev) =>
        (SUMATIF_SCOPE_OPTIONS as readonly string[]).includes(prev) || !prev
          ? 'Bab 1'
          : prev
      );
      setSlotCount(MIN_ASSESSMENTS_PER_BAB);
      setActiveSlot(1);
    }
  };

  const chapterOptions = useMemo(() => {
    const ordered: string[] = [];
    const seen = new Set<string>();
    const addOption = (val: string) => {
      const cleaned = val.trim();
      if (cleaned && !seen.has(cleaned)) {
        seen.add(cleaned);
        ordered.push(cleaned);
      }
    };

    if (assessmentType === 'sumatif') {
      SUMATIF_SCOPE_OPTIONS.forEach(addOption);
      DEFAULT_BAB_OPTIONS.forEach(addOption);
    } else {
      DEFAULT_BAB_OPTIONS.forEach(addOption);
    }

    const customFromGrades: string[] = [];
    for (const g of grades) {
      const gType = resolveGradeAssessmentType(g, categoryMap.get(g.categoryId));
      if (gType === assessmentType && g.chapter && g.chapter.trim()) {
        if (!seen.has(g.chapter.trim())) {
          customFromGrades.push(g.chapter.trim());
        }
      }
    }
    customFromGrades.sort(sortBabLabels).forEach(addOption);
    if (selectedChapter && selectedChapter.trim()) {
      addOption(selectedChapter);
    }
    return ordered;
  }, [assessmentType, grades, categoryMap, selectedChapter]);

  const usedChaptersInHistory = useMemo(() => {
    const set = new Set<string>();
    for (const g of grades) {
      if (g.chapter && g.chapter.trim()) {
        set.add(g.chapter.trim());
      }
    }
    return Array.from(set).sort(sortBabLabels);
  }, [grades]);

  const classStudents = useMemo(
    () => students.filter((s) => s.classId === classId),
    [students, classId]
  );

  const isBabMode = selectedChapter.trim() !== '';

  // Existing grades in standard (Tanpa Bab) mode filtered by assessmentType
  const existingStandardMap = useMemo(() => {
    const map = new Map<string, AcademicGrade>();
    if (isBabMode) return map;
    for (const g of grades) {
      if (
        !g.chapter &&
        g.classId === classId &&
        g.subjectId === subjectId &&
        g.categoryId === categoryId &&
        resolveGradeAssessmentType(g, categoryMap.get(g.categoryId)) ===
          assessmentType
      ) {
        if (!map.has(g.studentId)) {
          map.set(g.studentId, g);
        }
      }
    }
    return map;
  }, [
    grades,
    isBabMode,
    classId,
    subjectId,
    categoryId,
    assessmentType,
    categoryMap,
  ]);

  // Existing grades in Bab / Lingkup Materi mode keyed by `${studentId}:${assessmentOrder}`
  const existingBabMap = useMemo(() => {
    const map = new Map<string, AcademicGrade>();
    if (!isBabMode) return map;
    const ch = selectedChapter.trim();
    for (const g of grades) {
      if (
        (g.chapter ?? '').trim() === ch &&
        g.classId === classId &&
        g.subjectId === subjectId &&
        g.categoryId === categoryId &&
        resolveGradeAssessmentType(g, categoryMap.get(g.categoryId)) ===
          assessmentType
      ) {
        const order =
          g.assessmentOrder && g.assessmentOrder >= 1 ? g.assessmentOrder : 1;
        const key = `${g.studentId}:${order}`;
        if (!map.has(key)) {
          map.set(key, g);
        }
      }
    }
    return map;
  }, [
    grades,
    isBabMode,
    selectedChapter,
    classId,
    subjectId,
    categoryId,
    assessmentType,
    categoryMap,
  ]);

  // Adjust slotCount dynamically when context changes so all existing orders fit
  useEffect(() => {
    if (!isBabMode) return;
    const minSlots = assessmentType === 'formatif' ? MIN_ASSESSMENTS_PER_BAB : 1;
    let maxOrder = minSlots;
    for (const g of existingBabMap.values()) {
      const ord = g.assessmentOrder ?? 1;
      if (ord > maxOrder) maxOrder = ord;
    }
    setSlotCount(Math.min(20, Math.max(minSlots, maxOrder)));
    setActiveSlot(1);
  }, [
    isBabMode,
    assessmentType,
    existingBabMap,
    selectedChapter,
    classId,
    subjectId,
    categoryId,
  ]);

  // Pre-fill inputs for Standard mode
  useEffect(() => {
    if (isBabMode) return;
    const nextScores: Record<string, string> = {};
    const nextNotes: Record<string, string> = {};
    for (const st of classStudents) {
      const ex = existingStandardMap.get(st.id);
      nextScores[st.id] = ex ? String(ex.score) : '';
      nextNotes[st.id] = ex?.notes ?? '';
    }
    setScoreInputs(nextScores);
    setNoteInputs(nextNotes);
    setSaveMessage(null);
    setSaveError(null);
  }, [isBabMode, classStudents, existingStandardMap]);

  // Pre-fill matrix inputs for Bab mode
  useEffect(() => {
    if (!isBabMode) return;
    const nextScores: Record<string, Record<number, string>> = {};
    const nextNotes: Record<string, Record<number, string>> = {};
    for (const st of classStudents) {
      const rowScores: Record<number, string> = {};
      const rowNotes: Record<number, string> = {};
      for (let k = 1; k <= slotCount; k++) {
        const ex = existingBabMap.get(`${st.id}:${k}`);
        rowScores[k] = ex ? String(ex.score) : '';
        rowNotes[k] = ex?.notes ?? '';
      }
      nextScores[st.id] = rowScores;
      nextNotes[st.id] = rowNotes;
    }
    setMatrixScores(nextScores);
    setMatrixNotes(nextNotes);
    setSaveMessage(null);
    setSaveError(null);
  }, [isBabMode, classStudents, existingBabMap, slotCount]);

  // Count which slots have at least one valid entered score in Bab mode
  const slotFilledCounts = useMemo(() => {
    const counts: Record<number, number> = {};
    for (let k = 1; k <= slotCount; k++) {
      let c = 0;
      for (const st of classStudents) {
        const raw = (matrixScores[st.id]?.[k] ?? '').trim();
        if (raw !== '' && Number.isFinite(Number(raw))) {
          c += 1;
        }
      }
      counts[k] = c;
    }
    return counts;
  }, [slotCount, classStudents, matrixScores]);

  const totalSlotsFilledCount = useMemo(() => {
    let count = 0;
    for (let k = 1; k <= slotCount; k++) {
      if ((slotFilledCounts[k] ?? 0) > 0) count += 1;
    }
    return count;
  }, [slotCount, slotFilledCounts]);

  const handleAddCustomChapter = () => {
    const cleaned = customChapterInput.trim().slice(0, FIELD_LIMITS.GRADE_CHAPTER);
    if (!cleaned) return;
    setSelectedChapter(cleaned);
    setCustomChapterInput('');
    setCustomChapterOpen(false);
  };

  const handleSaveBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveError(null);
    setSaveMessage(null);
    if (!classId || !subjectId || !categoryId) return;

    const todayIso = getTodayIso();
    const typeLabel =
      assessmentType === 'sumatif'
        ? 'Penilaian Sumatif'
        : 'Penilaian Formatif';

    if (!isBabMode) {
      const entries = classStudents
        .map((st) => {
          const raw = (scoreInputs[st.id] ?? '').trim();
          if (raw === '') return null;
          const num = Number(raw);
          if (!Number.isFinite(num) || num < 0 || num > 100) return null;
          const ex = existingStandardMap.get(st.id);
          return {
            existingId: ex?.id,
            date: ex?.date ?? todayIso,
            classId,
            subjectId,
            categoryId,
            studentId: st.id,
            score: num,
            assessmentType,
            notes: noteInputs[st.id] ?? '',
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null);

      if (entries.length === 0) {
        setSaveError('Isi minimal satu nilai siswa (0 - 100) untuk disimpan.');
        return;
      }

      setSavingBatch(true);
      try {
        await saveBatchGrades(entries);
        setSaveMessage(
          `${entries.length} nilai ${typeLabel} berhasil disimpan ke riwayat penilaian.`
        );
      } catch (err) {
        setSaveError(
          err instanceof Error ? err.message : 'Gagal menyimpan nilai siswa.'
        );
      } finally {
        setSavingBatch(false);
      }
      return;
    }

    // Bab / Lingkup Materi mode: collect all filled & changed (or new) cells across P1..slotCount
    const ch = selectedChapter.trim();
    const entries: {
      existingId?: string;
      date: string;
      classId: string;
      subjectId: string;
      categoryId: string;
      studentId: string;
      score: number;
      assessmentType: AssessmentType;
      chapter: string;
      assessmentOrder: number;
      assessmentLabel: string;
      notes: string;
    }[] = [];

    for (const st of classStudents) {
      for (let k = 1; k <= slotCount; k++) {
        const raw = (matrixScores[st.id]?.[k] ?? '').trim();
        if (raw === '') continue;
        const num = Number(raw);
        if (!Number.isFinite(num) || num < 0 || num > 100) continue;
        const note = (matrixNotes[st.id]?.[k] ?? '').trim();
        const ex = existingBabMap.get(`${st.id}:${k}`);

        // Preserve original date if existing entry wasn't modified; use selected date for new/edited entries
        const isUnchanged =
          ex &&
          ex.score === num &&
          (ex.notes ?? '').trim() === note &&
          resolveGradeAssessmentType(ex, categoryMap.get(ex.categoryId)) ===
            assessmentType;
        if (isUnchanged) continue;

        entries.push({
          existingId: ex?.id,
          date: ex?.date ?? todayIso,
          classId,
          subjectId,
          categoryId,
          studentId: st.id,
          score: num,
          assessmentType,
          chapter: ch,
          assessmentOrder: k,
          assessmentLabel: `Penilaian ${k}`,
          notes: note,
        });
      }
    }

    if (entries.length === 0) {
      const hasAnySaved = Array.from(existingBabMap.keys()).length > 0;
      if (hasAnySaved) {
        setSaveMessage(
          `Tidak ada perubahan nilai baru pada ${typeLabel} · ${ch}.`
        );
      } else {
        setSaveError(
          'Isi minimal satu nilai siswa pada kolom penilaian yang tersedia (0 - 100) sebelum menyimpan.'
        );
      }
      return;
    }

    setSavingBatch(true);
    try {
      await saveBatchGrades(entries);
      setSaveMessage(
        `${entries.length} entri ${typeLabel} (${ch}) berhasil disimpan ke riwayat penilaian.`
      );
    } catch (err) {
      setSaveError(
        err instanceof Error ? err.message : 'Gagal menyimpan nilai.'
      );
    } finally {
      setSavingBatch(false);
    }
  };

  // =========================================================================
  // IMPORT PENILAIAN (EXCEL / CSV)
  // =========================================================================
  const importAvailableCategories = useMemo(
    () =>
      categories.filter(
        (c) =>
          c.subjectId === importDefaultSubjectId &&
          (!c.classId || c.classId === importDefaultClassId) &&
          isCategoryForAssessmentType(c.name, importDefaultAssessmentType)
      ),
    [
      categories,
      importDefaultSubjectId,
      importDefaultClassId,
      importDefaultAssessmentType,
    ]
  );

  useEffect(() => {
    if (
      importAvailableCategories.length > 0 &&
      !importAvailableCategories.some((c) => c.id === importDefaultCategoryId)
    ) {
      setImportDefaultCategoryId(importAvailableCategories[0].id);
    } else if (importAvailableCategories.length === 0) {
      setImportDefaultCategoryId('');
    }
  }, [importAvailableCategories, importDefaultCategoryId]);

  const openImportModal = () => {
    setImportDefaultDate(getTodayIso());
    setImportDefaultAssessmentType(assessmentType);
    setImportDefaultClassId(classId || classes[0]?.id || '');
    setImportDefaultSubjectId(subjectId || subjects[0]?.id || '');
    setImportDefaultCategoryId(categoryId || '');
    setImportDefaultChapter(
      selectedChapter ||
        (assessmentType === 'sumatif' ? SUMATIF_SCOPE_OPTIONS[0] : 'Bab 1')
    );
    setImportFileName('');
    setImportRawRows([]);
    setImportError(null);
    if (importFileRef.current) importFileRef.current.value = '';
    setImportOpen(true);
  };

  const handleImportFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportError(null);
    setImportFileName(file.name);

    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      if (!firstSheetName) {
        setImportError('File tidak memiliki sheet data.');
        setImportRawRows([]);
        return;
      }
      const sheet = workbook.Sheets[firstSheetName];
      const rawJson = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
        defval: '',
      });
      if (rawJson.length === 0) {
        setImportError(
          'File kosong atau tidak berisi baris nilai. Gunakan template yang tersedia.'
        );
        setImportRawRows([]);
        return;
      }
      setImportRawRows(rawJson);
    } catch {
      setImportError(
        'Gagal membaca file. Pastikan format file adalah .xlsx, .xls, atau .csv yang valid.'
      );
      setImportRawRows([]);
    }
  };

  const parsedImportRows = useMemo<ParsedGradeImportRow[]>(() => {
    if (importRawRows.length === 0) return [];

    const classByName = new Map(
      classes.map((c) => [c.name.trim().toLowerCase(), c])
    );
    const subjectByKey = new Map<string, (typeof subjects)[number]>();
    for (const s of subjects) {
      subjectByKey.set(s.name.trim().toLowerCase(), s);
      subjectByKey.set(s.code.trim().toLowerCase(), s);
    }
    const studentByNis = new Map(
      students.map((st) => [st.nis.trim().toLowerCase(), st])
    );

    const existingIndex = new Map<string, AcademicGrade>();
    for (const g of grades) {
      const gType = resolveGradeAssessmentType(g, categoryMap.get(g.categoryId));
      if (g.chapter && g.chapter.trim()) {
        const ord =
          g.assessmentOrder && g.assessmentOrder >= 1 ? g.assessmentOrder : 1;
        existingIndex.set(
          `${gType}|BAB|${g.studentId}|${g.classId}|${g.subjectId}|${g.categoryId}|${g.chapter.trim().toLowerCase()}|${ord}`,
          g
        );
      } else {
        existingIndex.set(
          `${gType}|STD|${g.date}|${g.studentId}|${g.classId}|${g.subjectId}|${g.categoryId}`,
          g
        );
      }
    }

    const results: ParsedGradeImportRow[] = [];

    importRawRows.forEach((rawRow, idx) => {
      const rowNum = idx + 2;
      const normEntries: Record<string, unknown> = {};
      const wideScoreCols: { order: number; rawVal: unknown }[] = [];

      for (const [k, v] of Object.entries(rawRow)) {
        const nk = normalizeHeader(k);
        normEntries[nk] = v;
        const wideOrd = parseOrderFromColumnHeader(nk);
        if (wideOrd !== null) {
          wideScoreCols.push({ order: wideOrd, rawVal: v });
        }
      }

      const rawDate =
        normEntries['tanggal'] ?? normEntries['date'] ?? normEntries['tgl'];
      const parsedDate = parseExcelDateValue(rawDate, importDefaultDate);

      const nis = String(
        normEntries['nis'] ??
          normEntries['nomorinduk'] ??
          normEntries['nisn'] ??
          ''
      ).trim();
      const studentNameInput = String(
        normEntries['namasiswa'] ??
          normEntries['namalengkap'] ??
          normEntries['nama'] ??
          normEntries['siswa'] ??
          ''
      ).trim();
      const classInput = String(
        normEntries['kelas'] ?? normEntries['namakelas'] ?? ''
      ).trim();
      const subjectInput = String(
        normEntries['matapelajaran'] ??
          normEntries['mapel'] ??
          normEntries['subject'] ??
          ''
      ).trim();
      const categoryInput = String(
        normEntries['kategori'] ??
          normEntries['kategoripenilaian'] ??
          normEntries['category'] ??
          ''
      ).trim();
      const typeInput = String(
        normEntries['jenispenilaian'] ??
          normEntries['jenis'] ??
          normEntries['tipepenilaian'] ??
          normEntries['tipe'] ??
          normEntries['assessmenttype'] ??
          ''
      )
        .trim()
        .toLowerCase();

      const chapterInput = String(
        normEntries['bab'] ??
          normEntries['materi'] ??
          normEntries['lingkupmateri'] ??
          normEntries['chapter'] ??
          ''
      ).trim();
      const notes = String(
        normEntries['catatan'] ??
          normEntries['keterangan'] ??
          normEntries['notes'] ??
          ''
      )
        .trim()
        .slice(0, FIELD_LIMITS.GRADE_NOTES);

      const resolvedChapter = (
        chapterInput || importDefaultChapter
      ).slice(0, FIELD_LIMITS.GRADE_CHAPTER);

      let resolvedAssessmentType: AssessmentType = importDefaultAssessmentType;
      if (typeInput.includes('sumatif') || typeInput === 's') {
        resolvedAssessmentType = 'sumatif';
      } else if (typeInput.includes('formatif') || typeInput === 'f') {
        resolvedAssessmentType = 'formatif';
      } else if (!typeInput) {
        const hintText = `${categoryInput} ${resolvedChapter}`.toLowerCase();
        if (isSumatifCategoryName(hintText)) {
          resolvedAssessmentType = 'sumatif';
        }
      }

      // Resolve student & class
      const studentFromNis = nis ? studentByNis.get(nis.toLowerCase()) : undefined;
      const explicitClass = classInput
        ? classByName.get(classInput.toLowerCase())
        : undefined;

      const resolvedClassId =
        explicitClass?.id ??
        studentFromNis?.classId ??
        importDefaultClassId;
      const resolvedClassName =
        classMap.get(resolvedClassId) ?? (classInput || '-');

      let matchedStudent = studentFromNis;
      if (!matchedStudent && studentNameInput) {
        const nameLower = studentNameInput.toLowerCase();
        matchedStudent =
          students.find(
            (st) =>
              st.classId === resolvedClassId &&
              st.fullName.trim().toLowerCase() === nameLower
          ) ??
          students.find((st) => st.fullName.trim().toLowerCase() === nameLower);
      }

      // Resolve subject
      const explicitSubject = subjectInput
        ? subjectByKey.get(subjectInput.toLowerCase())
        : undefined;
      const resolvedSubjectId =
        explicitSubject?.id ?? (subjectInput ? '' : importDefaultSubjectId);
      const resolvedSubjectName =
        subjectMap.get(resolvedSubjectId) ?? (subjectInput || '-');

      // Resolve category
      const explicitCategory = categoryInput
        ? categories.find(
            (c) =>
              c.name.trim().toLowerCase() === categoryInput.toLowerCase() &&
              (!resolvedSubjectId || c.subjectId === resolvedSubjectId) &&
              (!c.classId || !resolvedClassId || c.classId === resolvedClassId)
          ) ??
          categories.find(
            (c) => c.name.trim().toLowerCase() === categoryInput.toLowerCase()
          )
        : undefined;
      const resolvedCategoryId =
        explicitCategory?.id ?? (categoryInput ? '' : importDefaultCategoryId);
      const resolvedCategoryName =
        categoryMap.get(resolvedCategoryId) ?? (categoryInput || '-');

      const buildValidationError = (scoreVal: number | null, orderVal?: number) => {
        if (!parsedDate) return 'Format tanggal tidak valid';
        if (!matchedStudent) {
          return nis
            ? `Siswa NIS "${nis}" tidak ditemukan`
            : 'Siswa tidak ditemukan (isi NIS / Nama Siswa)';
        }
        if (!resolvedClassId) return `Kelas "${classInput || '-'}" tidak ditemukan`;
        if (!resolvedSubjectId)
          return `Mapel "${subjectInput || '-'}" tidak ditemukan`;
        if (!resolvedCategoryId)
          return `Kategori "${categoryInput || '-'}" tidak ditemukan`;
        if (scoreVal === null || !Number.isFinite(scoreVal) || scoreVal < 0 || scoreVal > 100) {
          return 'Nilai harus angka 0 - 100';
        }
        if (
          resolvedChapter &&
          orderVal !== undefined &&
          (!Number.isInteger(orderVal) || orderVal < 1 || orderVal > 20)
        ) {
          return 'Penilaian Ke harus 1 - 20';
        }
        return undefined;
      };

      const lookupExisting = (orderVal?: number) => {
        if (!matchedStudent || !resolvedClassId || !resolvedSubjectId || !resolvedCategoryId) {
          return undefined;
        }
        if (resolvedChapter) {
          const ord = orderVal ?? 1;
          return existingIndex.get(
            `${resolvedAssessmentType}|BAB|${matchedStudent.id}|${resolvedClassId}|${resolvedSubjectId}|${resolvedCategoryId}|${resolvedChapter.toLowerCase()}|${ord}`
          )?.id;
        }
        return existingIndex.get(
          `${resolvedAssessmentType}|STD|${parsedDate}|${matchedStudent.id}|${resolvedClassId}|${resolvedSubjectId}|${resolvedCategoryId}`
        )?.id;
      };

      // Check if wide columns (P1, P2, P3...) have values while single "Nilai" column is absent/empty
      const singleScoreRaw =
        normEntries['nilai'] ?? normEntries['score'] ?? normEntries['skor'];
      const hasSingleScore =
        singleScoreRaw !== undefined && String(singleScoreRaw).trim() !== '';

      const filledWide = wideScoreCols.filter(
        (w) => w.rawVal !== undefined && String(w.rawVal).trim() !== ''
      );

      if (!hasSingleScore && filledWide.length > 0) {
        for (const w of filledWide) {
          const num = Number(String(w.rawVal).replace(',', '.').trim());
          const scoreVal = Number.isFinite(num) ? num : null;
          const err = buildValidationError(scoreVal, w.order);
          results.push({
            rowNumber: rowNum,
            date: parsedDate || importDefaultDate,
            assessmentType: resolvedAssessmentType,
            nis: matchedStudent?.nis ?? nis,
            studentName: matchedStudent?.fullName ?? (studentNameInput || '-'),
            className: resolvedClassName,
            subjectName: resolvedSubjectName,
            categoryName: resolvedCategoryName,
            chapter: resolvedChapter || 'Bab 1',
            assessmentOrder: w.order,
            score: scoreVal,
            notes,
            matchedStudentId: matchedStudent?.id,
            matchedClassId: resolvedClassId || undefined,
            matchedSubjectId: resolvedSubjectId || undefined,
            matchedCategoryId: resolvedCategoryId || undefined,
            existingId: lookupExisting(w.order),
            error: err,
          });
        }
        return;
      }

      // Standard single-row format
      const orderRaw =
        normEntries['penilaianke'] ??
        normEntries['ke'] ??
        normEntries['assessmentorder'] ??
        normEntries['pertemuanke'] ??
        normEntries['order'];
      const parsedOrder =
        orderRaw !== undefined && String(orderRaw).trim() !== ''
          ? Number(String(orderRaw).trim())
          : resolvedChapter
          ? 1
          : undefined;

      const parsedScore =
        singleScoreRaw !== undefined && String(singleScoreRaw).trim() !== ''
          ? Number(String(singleScoreRaw).replace(',', '.').trim())
          : NaN;
      const scoreVal = Number.isFinite(parsedScore) ? parsedScore : null;
      const err = buildValidationError(scoreVal, parsedOrder);

      results.push({
        rowNumber: rowNum,
        date: parsedDate || importDefaultDate,
        assessmentType: resolvedAssessmentType,
        nis: matchedStudent?.nis ?? nis,
        studentName: matchedStudent?.fullName ?? (studentNameInput || '-'),
        className: resolvedClassName,
        subjectName: resolvedSubjectName,
        categoryName: resolvedCategoryName,
        chapter: resolvedChapter,
        assessmentOrder: resolvedChapter ? parsedOrder : undefined,
        score: scoreVal,
        notes,
        matchedStudentId: matchedStudent?.id,
        matchedClassId: resolvedClassId || undefined,
        matchedSubjectId: resolvedSubjectId || undefined,
        matchedCategoryId: resolvedCategoryId || undefined,
        existingId: lookupExisting(parsedOrder),
        error: err,
      });
    });

    return results;
  }, [
    importRawRows,
    classes,
    subjects,
    students,
    categories,
    grades,
    importDefaultDate,
    importDefaultAssessmentType,
    importDefaultClassId,
    importDefaultSubjectId,
    importDefaultCategoryId,
    importDefaultChapter,
    classMap,
    subjectMap,
    categoryMap,
  ]);

  const validImportRows = useMemo(
    () => parsedImportRows.filter((r) => !r.error),
    [parsedImportRows]
  );

  const invalidImportRows = useMemo(
    () => parsedImportRows.filter((r) => Boolean(r.error)),
    [parsedImportRows]
  );

  const handleConfirmImport = async () => {
    if (validImportRows.length === 0) return;
    setImporting(true);
    setImportError(null);
    try {
      const payload = validImportRows.map((r) => ({
        existingId: r.existingId,
        date: r.date,
        classId: r.matchedClassId!,
        subjectId: r.matchedSubjectId!,
        categoryId: r.matchedCategoryId!,
        studentId: r.matchedStudentId!,
        score: r.score!,
        assessmentType: r.assessmentType,
        ...(r.chapter
          ? {
              chapter: r.chapter,
              assessmentOrder: r.assessmentOrder ?? 1,
              assessmentLabel: `Penilaian ${r.assessmentOrder ?? 1}`,
            }
          : {}),
        notes: r.notes,
      }));
      await saveBatchGrades(payload);
      setImportOpen(false);
      setSaveMessage(
        `${payload.length} data penilaian dari file "${importFileName}" berhasil diimpor.`
      );
    } catch (err) {
      setImportError(
        err instanceof Error ? err.message : 'Gagal mengimpor data penilaian.'
      );
    } finally {
      setImporting(false);
    }
  };

  // =========================================================================
  // HISTORY FILTER & BULK DELETE
  // =========================================================================
  const filteredHistory = useMemo(() => {
    const q = histSearch.trim().toLowerCase();
    return grades.filter((g) => {
      if (
        histAssessmentType !== 'ALL' &&
        resolveGradeAssessmentType(g, categoryMap.get(g.categoryId)) !==
          histAssessmentType
      ) {
        return false;
      }
      if (histClassId !== 'ALL' && g.classId !== histClassId) return false;
      if (histSubjectId !== 'ALL' && g.subjectId !== histSubjectId) return false;
      if (histCategoryId !== 'ALL' && g.categoryId !== histCategoryId)
        return false;
      if (histChapter === 'NONE' && (g.chapter ?? '').trim() !== '')
        return false;
      if (
        histChapter !== 'ALL' &&
        histChapter !== 'NONE' &&
        (g.chapter ?? '').trim() !== histChapter
      )
        return false;
      if (histDate && g.date !== histDate) return false;
      if (q) {
        const st = studentMap.get(g.studentId);
        const nameMatch = st?.fullName.toLowerCase().includes(q);
        const nisMatch = st?.nis.toLowerCase().includes(q);
        const chapMatch = (g.chapter ?? '').toLowerCase().includes(q);
        if (!nameMatch && !nisMatch && !chapMatch) return false;
      }
      return true;
    });
  }, [
    grades,
    histAssessmentType,
    histClassId,
    histSubjectId,
    histCategoryId,
    histChapter,
    histDate,
    histSearch,
    studentMap,
    categoryMap,
  ]);

  const filteredIds = useMemo(
    () => filteredHistory.map((g) => g.id),
    [filteredHistory]
  );

  const allFilteredSelected =
    filteredHistory.length > 0 &&
    filteredHistory.every((g) => selectedIds.has(g.id));

  const toggleSelectAll = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allFilteredSelected) {
        for (const id of filteredIds) next.delete(id);
      } else {
        for (const id of filteredIds) next.add(id);
      }
      return next;
    });
  };

  const toggleSelectRow = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleConfirmBulkDelete = async () => {
    const targetIds =
      bulkDeleteMode === 'filtered' ? filteredIds : Array.from(selectedIds);
    if (targetIds.length === 0) {
      setBulkDeleteMode(null);
      return;
    }
    setBulkDeleting(true);
    try {
      const removed = await deleteGradesBulk(targetIds);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        for (const id of targetIds) next.delete(id);
        return next;
      });
      setBulkDeleteMode(null);
      setSaveMessage(`${removed} data penilaian akademik berhasil dihapus.`);
    } finally {
      setBulkDeleting(false);
    }
  };

  const openEditModal = (g: AcademicGrade) => {
    setEditingGrade(g);
    setEditAssessmentType(
      resolveGradeAssessmentType(g, categoryMap.get(g.categoryId))
    );
    setEditScore(String(g.score));
    setEditNotes(g.notes ?? '');
    setEditDate(g.date);
    setEditChapter(g.chapter ?? '');
    setEditOrder(String(g.assessmentOrder ?? 1));
  };

  const handleSaveSingleEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingGrade) return;
    const numeric = Number(editScore);
    if (!Number.isFinite(numeric) || numeric < 0 || numeric > 100) return;
    const ch = editChapter.trim();
    const ord = Math.max(1, Math.min(20, Math.round(Number(editOrder) || 1)));
    setSavingSingle(true);
    try {
      await updateGrade(editingGrade.id, {
        date: editDate,
        classId: editingGrade.classId,
        subjectId: editingGrade.subjectId,
        categoryId: editingGrade.categoryId,
        studentId: editingGrade.studentId,
        score: numeric,
        assessmentType: editAssessmentType,
        chapter: ch || undefined,
        assessmentOrder: ch ? ord : undefined,
        assessmentLabel: ch ? `Penilaian ${ord}` : undefined,
        notes: editNotes,
      });
      setEditingGrade(null);
    } finally {
      setSavingSingle(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setSavingSingle(true);
    try {
      await deleteGrade(deleteTarget.id);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(deleteTarget.id);
        return next;
      });
      setDeleteTarget(null);
    } finally {
      setSavingSingle(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Penilaian Akademik
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Terbagi menjadi <strong>Penilaian Formatif</strong> (proses harian
            per Bab) dan <strong>Penilaian Sumatif</strong> (lingkup materi,
            STS/PTS, SAS/PAS).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={downloadGradeTemplateExcel}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 shrink-0" />
            <span>Unduh Template</span>
          </button>

          <button
            type="button"
            onClick={openImportModal}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 shrink-0" />
            <span>Import Nilai (Excel/CSV)</span>
          </button>

          {/* Segmented Tab Control */}
          <div className="inline-flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-800/80 rounded-lg">
            <button
              type="button"
              onClick={() => setActiveTab('input')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'input'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              Input Nilai
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('riwayat')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'riwayat'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              Riwayat Penilaian ({grades.length})
            </button>
          </div>
        </div>
      </div>

      {/* Penilaian Formatif vs Penilaian Sumatif Switcher */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => handleSwitchAssessmentType('formatif')}
          className={`text-left p-4 rounded-xl border transition-all cursor-pointer ${
            (activeTab === 'input' && assessmentType === 'formatif') ||
            (activeTab === 'riwayat' && histAssessmentType === 'formatif')
              ? 'bg-blue-50/70 dark:bg-blue-950/40 border-blue-500 dark:border-blue-500 ring-1 ring-blue-500/30'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  (activeTab === 'input' && assessmentType === 'formatif') ||
                  (activeTab === 'riwayat' &&
                    histAssessmentType === 'formatif')
                    ? 'bg-blue-600 dark:bg-blue-400'
                    : 'bg-slate-300 dark:bg-slate-600'
                }`}
              />
              <span className="font-display font-semibold text-base text-slate-900 dark:text-slate-100">
                Penilaian Formatif
              </span>
            </div>
            <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300 tabular-nums">
              {gradeTypeCounts.formatif} entri
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 pl-5">
            Penilaian proses pembelajaran harian per Bab (P1, P2, P3, dst.
            bersifat opsional — tidak harus terisi semua).
          </p>
        </button>

        <button
          type="button"
          onClick={() => handleSwitchAssessmentType('sumatif')}
          className={`text-left p-4 rounded-xl border transition-all cursor-pointer ${
            (activeTab === 'input' && assessmentType === 'sumatif') ||
            (activeTab === 'riwayat' && histAssessmentType === 'sumatif')
              ? 'bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-500 dark:border-indigo-500 ring-1 ring-indigo-500/30'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  (activeTab === 'input' && assessmentType === 'sumatif') ||
                  (activeTab === 'riwayat' && histAssessmentType === 'sumatif')
                    ? 'bg-indigo-600 dark:bg-indigo-400'
                    : 'bg-slate-300 dark:bg-slate-600'
                }`}
              />
              <span className="font-display font-semibold text-base text-slate-900 dark:text-slate-100">
                Penilaian Sumatif
              </span>
            </div>
            <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-900/60 text-indigo-800 dark:text-indigo-300 tabular-nums">
              {gradeTypeCounts.sumatif} entri
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 pl-5">
            Penilaian hasil capaian per lingkup materi, Sumatif Tengah Semester
            (STS/PTS), dan Sumatif Akhir Semester (SAS/PAS).
          </p>
        </button>
      </div>

      {saveMessage && (
        <div className="p-3.5 text-sm text-emerald-900 dark:text-emerald-200 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 rounded-xl flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
            <span>{saveMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setSaveMessage(null)}
            className="p-1 hover:opacity-70 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {saveError && (
        <div className="p-3.5 text-sm text-red-900 dark:text-red-200 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 rounded-xl flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-red-700 dark:text-red-400 shrink-0" />
          <span>{saveError}</span>
        </div>
      )}

      {activeTab === 'input' ? (
        <div className="space-y-5">
          {/* Context Selectors */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Kelas
                </label>
                <select
                  value={classId}
                  onChange={(e) => setClassId(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                >
                  <option value="">Pilih Kelas</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.academicYear})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Mata Pelajaran
                </label>
                <select
                  value={subjectId}
                  onChange={(e) => setSubjectId(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                >
                  <option value="">Pilih Mata Pelajaran</option>
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.code} · {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Kategori Penilaian
                </label>
                <select
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                >
                  {availableCategories.length === 0 ? (
                    <option value="">
                      {assessmentType === 'sumatif'
                        ? 'Belum ada kategori Sumatif (Ulangan Harian, PTS, PAS)'
                        : 'Belum ada kategori Formatif (Tugas Harian)'}
                    </option>
                  ) : (
                    availableCategories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name} (Bobot {cat.weight}%)
                      </option>
                    ))
                  )}
                </select>
              </div>
            </div>

            {/* Bab Selector + Minimum 3 Assessments Indicator */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {assessmentType === 'sumatif'
                      ? 'Lingkup Materi / Jenis Sumatif'
                      : 'Bab / Materi Pembelajaran'}
                  </label>
                  <div className="flex items-center gap-2">
                    <select
                      value={selectedChapter}
                      onChange={(e) => setSelectedChapter(e.target.value)}
                      className="px-3 py-1.5 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                    >
                      {chapterOptions.map((bab) => (
                        <option key={bab} value={bab}>
                          {bab}
                        </option>
                      ))}
                      <option value="">Umum / Tanpa Bab</option>
                    </select>

                    <button
                      type="button"
                      onClick={() => setCustomChapterOpen((v) => !v)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900/60 rounded-lg cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>
                        {assessmentType === 'sumatif'
                          ? 'Lingkup Kustom'
                          : 'Bab Kustom'}
                      </span>
                    </button>
                  </div>
                </div>

                {customChapterOpen && (
                  <div className="flex items-end gap-2">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                        {assessmentType === 'sumatif'
                          ? 'Nama Lingkup Sumatif Baru'
                          : 'Nama Bab Baru'}
                      </label>
                      <input
                        type="text"
                        maxLength={FIELD_LIMITS.GRADE_CHAPTER}
                        value={customChapterInput}
                        onChange={(e) => setCustomChapterInput(e.target.value)}
                        placeholder={
                          assessmentType === 'sumatif'
                            ? 'Misal: Sumatif Bab 5'
                            : 'Misal: Bab 1 Aljabar'
                        }
                        className="px-3 py-1.5 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleAddCustomChapter}
                      className="px-3 py-1.5 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 rounded-lg cursor-pointer"
                    >
                      Pakai
                    </button>
                  </div>
                )}
              </div>

              {isBabMode && (
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`text-xs font-medium px-2.5 py-1 rounded-md border tabular-nums ${
                      totalSlotsFilledCount > 0
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                        : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {totalSlotsFilledCount}/{slotCount} Kolom Penilaian Terisi
                    (Opsional)
                  </span>

                  <div className="flex flex-wrap items-center gap-1">
                    {Array.from({ length: slotCount }, (_, i) => i + 1).map(
                      (k) => {
                        const isActive = activeSlot === k;
                        const filled = (slotFilledCounts[k] ?? 0) > 0;
                        return (
                          <button
                            key={k}
                            type="button"
                            onClick={() => setActiveSlot(k)}
                            title={`Pilih Catatan Penilaian ke-${k} (${slotFilledCounts[k] ?? 0} siswa terisi)`}
                            className={`px-2.5 py-1 text-xs font-mono font-semibold rounded-md border transition-colors cursor-pointer ${
                              isActive
                                ? 'bg-blue-700 border-blue-700 text-white dark:bg-blue-600 dark:border-blue-600'
                                : filled
                                ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
                                : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-blue-400'
                            }`}
                          >
                            P{k}
                          </button>
                        );
                      }
                    )}

                    {slotCount < 20 && (
                      <button
                        type="button"
                        onClick={() => setSlotCount((s) => Math.min(20, s + 1))}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Tambah Penilaian</span>
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Student Score Entry Grid */}
          {!classId || !subjectId || !categoryId ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center text-sm text-slate-500 dark:text-slate-400">
              Pilih Kelas, Mata Pelajaran, dan Kategori Penilaian terlebih
              dahulu. Jika kategori belum tersedia, tambahkan di menu{' '}
              <strong className="text-slate-800 dark:text-slate-200">
                Kategori Penilaian
              </strong>
              .
            </div>
          ) : classStudents.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center text-sm text-slate-500 dark:text-slate-400">
              Belum ada siswa yang terdaftar pada kelas ini.
            </div>
          ) : isBabMode ? (
            <form
              onSubmit={handleSaveBatch}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden"
            >
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-xs font-medium text-slate-500 dark:text-slate-400">
                      <th className="py-3 px-4 w-12">No</th>
                      <th className="py-3 px-3 w-28">NIS</th>
                      <th className="py-3 px-4 min-w-[180px]">Nama Siswa</th>
                      {Array.from({ length: slotCount }, (_, i) => i + 1).map(
                        (k) => (
                          <th key={k} className="py-3 px-2 w-24 text-center">
                            <button
                              type="button"
                              onClick={() => setActiveSlot(k)}
                              className={`px-2 py-0.5 rounded font-mono text-xs cursor-pointer ${
                                activeSlot === k
                                  ? 'bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 font-semibold'
                                  : 'hover:text-slate-800 dark:hover:text-slate-200'
                              }`}
                            >
                              P{k}
                            </button>
                          </th>
                        )
                      )}
                      <th className="py-3 px-3 w-24 text-right">Rata Bab</th>
                      <th className="py-3 px-4 min-w-[190px]">
                        Catatan P{activeSlot}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                    {classStudents.map((st, idx) => {
                      const rowScores = matrixScores[st.id] ?? {};
                      const numericVals: number[] = [];
                      for (let k = 1; k <= slotCount; k++) {
                        const raw = (rowScores[k] ?? '').trim();
                        if (raw !== '') {
                          const num = Number(raw);
                          if (Number.isFinite(num) && num >= 0 && num <= 100) {
                            numericVals.push(num);
                          }
                        }
                      }
                      const avgBab =
                        numericVals.length > 0
                          ? (
                              numericVals.reduce((a, b) => a + b, 0) /
                              numericVals.length
                            ).toFixed(1)
                          : '-';

                      return (
                        <tr
                          key={st.id}
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                        >
                          <td className="py-2.5 px-4 font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-xs text-slate-600 dark:text-slate-300 tabular-nums">
                            {st.nis}
                          </td>
                          <td className="py-2.5 px-4 font-medium text-slate-900 dark:text-slate-100">
                            {st.fullName}
                          </td>
                          {Array.from(
                            { length: slotCount },
                            (_, i) => i + 1
                          ).map((k) => {
                            const hasSaved = existingBabMap.has(
                              `${st.id}:${k}`
                            );
                            return (
                              <td key={k} className="py-2 px-2">
                                <input
                                  type="number"
                                  min={0}
                                  max={100}
                                  step="0.1"
                                  placeholder="0-100"
                                  value={rowScores[k] ?? ''}
                                  onFocus={() => setActiveSlot(k)}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setMatrixScores((prev) => ({
                                      ...prev,
                                      [st.id]: {
                                        ...(prev[st.id] ?? {}),
                                        [k]: val,
                                      },
                                    }));
                                  }}
                                  className={`w-full px-2 py-1.5 text-center text-sm font-mono tabular-nums bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border rounded-md placeholder:text-slate-400 dark:placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 ${
                                    hasSaved
                                      ? 'border-blue-300 dark:border-blue-800'
                                      : 'border-slate-200 dark:border-slate-700'
                                  }`}
                                />
                              </td>
                            );
                          })}
                          <td className="py-2.5 px-3 text-right font-mono font-semibold tabular-nums text-slate-800 dark:text-slate-200">
                            {avgBab}
                          </td>
                          <td className="py-2 px-4">
                            <input
                              type="text"
                              maxLength={FIELD_LIMITS.GRADE_NOTES}
                              placeholder={`Catatan P${activeSlot}...`}
                              value={matrixNotes[st.id]?.[activeSlot] ?? ''}
                              onChange={(e) => {
                                const val = e.target.value;
                                setMatrixNotes((prev) => ({
                                  ...prev,
                                  [st.id]: {
                                    ...(prev[st.id] ?? {}),
                                    [activeSlot]: val,
                                  },
                                }));
                              }}
                              className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-md placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="px-5 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Penilaian{' '}
                  <strong className="font-mono">P1..P{slotCount}</strong>{' '}
                  bersifat opsional — tidak harus terisi semua. Klik kolom untuk
                  mengubah catatan penilaian; kolom kosong tidak akan disimpan.
                </p>
                <button
                  type="submit"
                  disabled={savingBatch}
                  className={`inline-flex items-center justify-center gap-2 px-5 py-2 text-sm font-medium text-white disabled:opacity-60 rounded-lg whitespace-nowrap shrink-0 cursor-pointer ${
                    assessmentType === 'sumatif'
                      ? 'bg-indigo-700 hover:bg-indigo-800 dark:bg-indigo-600 dark:hover:bg-indigo-500'
                      : 'bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500'
                  }`}
                >
                  <Save className="w-4 h-4 shrink-0" />
                  <span>
                    {savingBatch
                      ? 'Menyimpan...'
                      : `Simpan ${
                          assessmentType === 'sumatif' ? 'Sumatif' : 'Formatif'
                        } (${selectedChapter})`}
                  </span>
                </button>
              </div>
            </form>
          ) : (
            <form
              onSubmit={handleSaveBatch}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden"
            >
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-xs font-medium text-slate-500 dark:text-slate-400">
                      <th className="py-3 px-4 w-14">No</th>
                      <th className="py-3 px-4 w-32">NIS</th>
                      <th className="py-3 px-4">Nama Siswa</th>
                      <th className="py-3 px-4 w-36">Nilai (0 - 100)</th>
                      <th className="py-3 px-4">Catatan (Opsional)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                    {classStudents.map((st, idx) => {
                      const hasExisting = existingStandardMap.has(st.id);
                      return (
                        <tr
                          key={st.id}
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                        >
                          <td className="py-2.5 px-4 font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-4 font-mono text-xs text-slate-600 dark:text-slate-300 tabular-nums">
                            {st.nis}
                          </td>
                          <td className="py-2.5 px-4">
                            <span className="font-medium text-slate-900 dark:text-slate-100">
                              {st.fullName}
                            </span>
                            {hasExisting && (
                              <span className="ml-2 text-xs text-blue-700 dark:text-blue-400">
                                · Tersimpan
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-4">
                            <input
                              type="number"
                              min={0}
                              max={100}
                              step="0.1"
                              placeholder="0 - 100"
                              value={scoreInputs[st.id] ?? ''}
                              onChange={(e) =>
                                setScoreInputs((prev) => ({
                                  ...prev,
                                  [st.id]: e.target.value,
                                }))
                              }
                              className="w-full px-3 py-1.5 text-sm font-mono tabular-nums bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-md placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                            />
                          </td>
                          <td className="py-2.5 px-4">
                            <input
                              type="text"
                              maxLength={FIELD_LIMITS.GRADE_NOTES}
                              placeholder="Catatan penilaian..."
                              value={noteInputs[st.id] ?? ''}
                              onChange={(e) =>
                                setNoteInputs((prev) => ({
                                  ...prev,
                                  [st.id]: e.target.value,
                                }))
                              }
                              className="w-full px-3 py-1.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-md placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="px-5 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between gap-4">
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Baris nilai yang dikosongkan tidak akan disimpan. Nilai yang
                  sudah tersimpan pada kategori ini akan otomatis diperbarui.
                </p>
                <button
                  type="submit"
                  disabled={savingBatch}
                  className={`inline-flex items-center gap-2 px-5 py-2 text-sm font-medium text-white disabled:opacity-60 rounded-lg whitespace-nowrap shrink-0 cursor-pointer ${
                    assessmentType === 'sumatif'
                      ? 'bg-indigo-700 hover:bg-indigo-800 dark:bg-indigo-600 dark:hover:bg-indigo-500'
                      : 'bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500'
                  }`}
                >
                  <Save className="w-4 h-4 shrink-0" />
                  <span>
                    {savingBatch
                      ? 'Menyimpan...'
                      : `Simpan Nilai ${
                          assessmentType === 'sumatif' ? 'Sumatif' : 'Formatif'
                        }`}
                  </span>
                </button>
              </div>
            </form>
          )}
        </div>
      ) : (
        <div className="space-y-5">
          {/* History Filters */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={histSearch}
                onChange={(e) => setHistSearch(e.target.value)}
                placeholder="Cari siswa / NIS / Bab..."
                className="w-full pl-9 pr-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>

            <select
              value={histAssessmentType}
              onChange={(e) => {
                const next = e.target.value as 'ALL' | AssessmentType;
                setHistAssessmentType(next);
                setHistCategoryId('ALL');
              }}
              className="px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200"
            >
              <option value="ALL">Semua Jenis Penilaian</option>
              <option value="formatif">Penilaian Formatif</option>
              <option value="sumatif">Penilaian Sumatif</option>
            </select>

            <select
              value={histClassId}
              onChange={(e) => setHistClassId(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200"
            >
              <option value="ALL">Semua Kelas</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>

            <select
              value={histSubjectId}
              onChange={(e) => setHistSubjectId(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200"
            >
              <option value="ALL">Semua Mapel</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>

            <select
              value={histCategoryId}
              onChange={(e) => setHistCategoryId(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200"
            >
              <option value="ALL">Semua Kategori</option>
              {categories
                .filter(
                  (cat) =>
                    (histSubjectId === 'ALL' ||
                      cat.subjectId === histSubjectId) &&
                    (histAssessmentType === 'ALL' ||
                      isCategoryForAssessmentType(cat.name, histAssessmentType))
                )
                .map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                    {histSubjectId === 'ALL' && subjectMap.get(cat.subjectId)
                      ? ` · ${subjectMap.get(cat.subjectId)}`
                      : ''}
                  </option>
                ))}
            </select>

            <select
              value={histChapter}
              onChange={(e) => setHistChapter(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200"
            >
              <option value="ALL">Semua Bab</option>
              <option value="NONE">Umum / Tanpa Bab</option>
              {usedChaptersInHistory.map((bab) => (
                <option key={bab} value={bab}>
                  {bab}
                </option>
              ))}
            </select>

            <input
              type="date"
              value={histDate}
              onChange={(e) => setHistDate(e.target.value)}
              className="px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
          </div>

          {/* Bulk Action Bar */}
          {filteredHistory.length > 0 && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
                <label className="inline-flex items-center gap-2 cursor-pointer font-medium">
                  <input
                    type="checkbox"
                    checked={allFilteredSelected}
                    onChange={toggleSelectAll}
                    className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
                  />
                  <span>Pilih Semua ({filteredHistory.length})</span>
                </label>
                {selectedIds.size > 0 && (
                  <span className="font-mono text-blue-700 dark:text-blue-400 font-semibold">
                    · {selectedIds.size} terpilih
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {selectedIds.size > 0 && (
                  <button
                    type="button"
                    onClick={() => setBulkDeleteMode('selected')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Hapus Terpilih ({selectedIds.size})</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setBulkDeleteMode('filtered')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/60 rounded-lg cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>
                    Hapus{' '}
                    {filteredHistory.length === grades.length
                      ? 'Semua'
                      : 'Sesuai Filter'}{' '}
                    ({filteredHistory.length})
                  </span>
                </button>
              </div>
            </div>
          )}

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
            {filteredHistory.length === 0 ? (
              <div className="p-12 text-center text-sm text-slate-500 dark:text-slate-400">
                Belum ada riwayat nilai yang cocok dengan filter.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-xs font-medium text-slate-500 dark:text-slate-400">
                      <th className="py-3 px-3 w-10 text-center">
                        <input
                          type="checkbox"
                          checked={allFilteredSelected}
                          onChange={toggleSelectAll}
                          aria-label="Pilih semua data penilaian"
                          className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
                        />
                      </th>
                      <th className="py-3 px-4">Tanggal</th>
                      <th className="py-3 px-4">Siswa</th>
                      <th className="py-3 px-4">Kelas</th>
                      <th className="py-3 px-4">Mata Pelajaran</th>
                      <th className="py-3 px-4">Jenis</th>
                      <th className="py-3 px-4">Kategori</th>
                      <th className="py-3 px-4">Bab / Ke</th>
                      <th className="py-3 px-4 text-right">Nilai</th>
                      <th className="py-3 px-4">Catatan</th>
                      <th className="py-3 px-4 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                    {filteredHistory.map((g) => {
                      const st = studentMap.get(g.studentId);
                      const checked = selectedIds.has(g.id);
                      const gType = resolveGradeAssessmentType(
                        g,
                        categoryMap.get(g.categoryId)
                      );
                      return (
                        <tr
                          key={g.id}
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                        >
                          <td className="py-2.5 px-3 text-center">
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => toggleSelectRow(g.id)}
                              className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
                            />
                          </td>
                          <td className="py-2.5 px-4 font-mono text-xs text-slate-600 dark:text-slate-300 tabular-nums whitespace-nowrap">
                            {formatIndonesianDate(g.date)}
                          </td>
                          <td className="py-2.5 px-4">
                            <p className="font-medium text-slate-900 dark:text-slate-100">
                              {st?.fullName ?? 'Siswa'}
                            </p>
                            <p className="font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                              {st?.nis ?? '-'}
                            </p>
                          </td>
                          <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300">
                            {classMap.get(g.classId) ?? '-'}
                          </td>
                          <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300">
                            {subjectMap.get(g.subjectId) ?? '-'}
                          </td>
                          <td className="py-2.5 px-4 whitespace-nowrap">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 text-[11px] font-medium rounded-md border ${
                                gType === 'sumatif'
                                  ? 'bg-indigo-50 dark:bg-indigo-950/50 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300'
                                  : 'bg-blue-50 dark:bg-blue-950/50 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300'
                              }`}
                            >
                              {gType === 'sumatif' ? 'Sumatif' : 'Formatif'}
                            </span>
                          </td>
                          <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300">
                            {categoryMap.get(g.categoryId) ?? '-'}
                          </td>
                          <td className="py-2.5 px-4 text-xs whitespace-nowrap">
                            {g.chapter ? (
                              <span className="font-medium text-blue-700 dark:text-blue-400">
                                {g.chapter}
                                {g.assessmentOrder
                                  ? ` · P${g.assessmentOrder}`
                                  : ''}
                              </span>
                            ) : (
                              <span className="text-slate-400 dark:text-slate-500">
                                Umum
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-4 text-right font-mono font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                            {g.score}
                          </td>
                          <td className="py-2.5 px-4 text-xs text-slate-500 dark:text-slate-400 max-w-[200px] truncate">
                            {g.notes || '-'}
                          </td>
                          <td className="py-2.5 px-4 text-right">
                            <div className="inline-flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => openEditModal(g)}
                                className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-blue-700 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 rounded-md cursor-pointer"
                                title="Edit Nilai"
                              >
                                <Pencil className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTarget(g)}
                                className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-red-700 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-md cursor-pointer"
                                title="Hapus Nilai"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Import Penilaian Modal */}
      {importOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/45 dark:bg-slate-950/75">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-4xl w-full max-h-[90vh] flex flex-col">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <FileSpreadsheet className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
                <div>
                  <h2 className="font-display font-semibold text-lg text-slate-900 dark:text-slate-100">
                    Import Penilaian dari Excel / CSV
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Mendukung format baris (Bab &amp; Penilaian Ke) maupun format
                    kolom matriks (P1, P2, P3...).
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setImportOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-md cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              {/* Fallback defaults */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-3">
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Pengaturan Default (dipakai jika kolom di file tidak diisi):
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Jenis Penilaian Default
                    </label>
                    <select
                      value={importDefaultAssessmentType}
                      onChange={(e) =>
                        setImportDefaultAssessmentType(
                          e.target.value as AssessmentType
                        )
                      }
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                    >
                      <option value="formatif">Penilaian Formatif</option>
                      <option value="sumatif">Penilaian Sumatif</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Tanggal Default
                    </label>
                    <input
                      type="date"
                      value={importDefaultDate}
                      onChange={(e) => setImportDefaultDate(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Kelas Default
                    </label>
                    <select
                      value={importDefaultClassId}
                      onChange={(e) => setImportDefaultClassId(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                    >
                      <option value="">Otomatis dari NIS</option>
                      {classes.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Mapel Default
                    </label>
                    <select
                      value={importDefaultSubjectId}
                      onChange={(e) =>
                        setImportDefaultSubjectId(e.target.value)
                      }
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                    >
                      <option value="">Pilih Mapel</option>
                      {subjects.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Kategori Default
                    </label>
                    <select
                      value={importDefaultCategoryId}
                      onChange={(e) =>
                        setImportDefaultCategoryId(e.target.value)
                      }
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                    >
                      <option value="">Pilih Kategori</option>
                      {importAvailableCategories.map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Bab Default
                    </label>
                    <input
                      type="text"
                      maxLength={FIELD_LIMITS.GRADE_CHAPTER}
                      value={importDefaultChapter}
                      onChange={(e) => setImportDefaultChapter(e.target.value)}
                      placeholder="Kosong = Umum"
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>
              </div>

              {/* File Picker */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <input
                    ref={importFileRef}
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    onChange={handleImportFileChange}
                    className="hidden"
                    id="import-grades-file"
                  />
                  <label
                    htmlFor="import-grades-file"
                    className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Pilih File Excel / CSV</span>
                  </label>
                  {importFileName && (
                    <span className="font-mono text-xs text-slate-600 dark:text-slate-300">
                      {importFileName}
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={downloadGradeTemplateExcel}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh Template Excel Penilaian</span>
                </button>
              </div>

              {importError && (
                <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-xs text-red-800 dark:text-red-200">
                  {importError}
                </div>
              )}

              {parsedImportRows.length > 0 && (
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center gap-4 text-xs">
                    <span className="font-medium text-emerald-700 dark:text-emerald-400">
                      Siap diimpor: {validImportRows.length} baris nilai
                    </span>
                    {invalidImportRows.length > 0 && (
                      <span className="font-medium text-red-700 dark:text-red-400">
                        Bermasalah (dilewati): {invalidImportRows.length} baris
                      </span>
                    )}
                  </div>

                  <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden max-h-72 overflow-y-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 sticky top-0">
                        <tr>
                          <th className="py-2 px-3">Baris</th>
                          <th className="py-2 px-3">Siswa</th>
                          <th className="py-2 px-3">Jenis</th>
                          <th className="py-2 px-3">Kelas · Mapel</th>
                          <th className="py-2 px-3">Kategori · Bab</th>
                          <th className="py-2 px-3 text-right">Nilai</th>
                          <th className="py-2 px-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {parsedImportRows.slice(0, 100).map((row, idx) => (
                          <tr
                            key={`${row.rowNumber}-${row.assessmentOrder ?? 0}-${idx}`}
                            className={
                              row.error
                                ? 'bg-red-50/40 dark:bg-red-950/20'
                                : ''
                            }
                          >
                            <td className="py-2 px-3 font-mono text-slate-500">
                              #{row.rowNumber}
                            </td>
                            <td className="py-2 px-3">
                              <span className="font-medium text-slate-900 dark:text-slate-100">
                                {row.studentName}
                              </span>
                              <span className="ml-1.5 font-mono text-slate-500">
                                ({row.nis || '-'})
                              </span>
                            </td>
                            <td className="py-2 px-3">
                              <span
                                className={`inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium rounded border ${
                                  row.assessmentType === 'sumatif'
                                    ? 'bg-indigo-50 dark:bg-indigo-950/50 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300'
                                    : 'bg-blue-50 dark:bg-blue-950/50 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300'
                                }`}
                              >
                                {row.assessmentType === 'sumatif'
                                  ? 'Sumatif'
                                  : 'Formatif'}
                              </span>
                            </td>
                            <td className="py-2 px-3 text-slate-600 dark:text-slate-300">
                              {row.className} · {row.subjectName}
                            </td>
                            <td className="py-2 px-3 text-slate-600 dark:text-slate-300">
                              {row.categoryName}
                              {row.chapter
                                ? ` · ${row.chapter} (P${row.assessmentOrder ?? 1})`
                                : ''}
                            </td>
                            <td className="py-2 px-3 text-right font-mono font-semibold text-slate-900 dark:text-slate-100">
                              {row.score !== null ? row.score : '-'}
                            </td>
                            <td className="py-2 px-3">
                              {row.error ? (
                                <span className="text-red-700 dark:text-red-400 font-medium">
                                  {row.error}
                                </span>
                              ) : row.existingId ? (
                                <span className="text-blue-700 dark:text-blue-400 font-medium">
                                  Perbarui
                                </span>
                              ) : (
                                <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                                  Tambah Baru
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setImportOpen(false)}
                className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
              >
                Tutup
              </button>
              <button
                type="button"
                disabled={importing || validImportRows.length === 0}
                onClick={handleConfirmImport}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-emerald-700 hover:bg-emerald-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 disabled:opacity-50 rounded-lg cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>
                  {importing
                    ? 'Mengimpor...'
                    : `Import ${validImportRows.length} Nilai Valid`}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Grade Modal */}
      {editingGrade && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 dark:bg-slate-950/70">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display font-semibold text-lg text-slate-900 dark:text-slate-100">
                Edit Nilai Siswa
              </h2>
              <button
                type="button"
                onClick={() => setEditingGrade(null)}
                className="p-1 text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 rounded-md cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">
              Siswa:{' '}
              <strong className="text-slate-900 dark:text-slate-100">
                {studentMap.get(editingGrade.studentId)?.fullName}
              </strong>{' '}
              · {categoryMap.get(editingGrade.categoryId)}
            </p>

            <form onSubmit={handleSaveSingleEdit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Jenis Penilaian
                </label>
                <select
                  value={editAssessmentType}
                  onChange={(e) =>
                    setEditAssessmentType(e.target.value as AssessmentType)
                  }
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                >
                  <option value="formatif">Penilaian Formatif</option>
                  <option value="sumatif">Penilaian Sumatif</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    required
                    value={editDate}
                    onChange={(e) => setEditDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Nilai (0 - 100)
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    max={100}
                    step="0.1"
                    value={editScore}
                    onChange={(e) => setEditScore(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Bab / Materi (Kosong = Umum)
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.GRADE_CHAPTER}
                    value={editChapter}
                    onChange={(e) => setEditChapter(e.target.value)}
                    placeholder="Contoh: Bab 1"
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Penilaian Ke
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    disabled={!editChapter.trim()}
                    value={editOrder}
                    onChange={(e) => setEditOrder(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg disabled:opacity-50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Catatan
                </label>
                <input
                  type="text"
                  maxLength={FIELD_LIMITS.GRADE_NOTES}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingGrade(null)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={savingSingle}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {savingSingle ? 'Menyimpan...' : 'Simpan Perubahan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Hapus Data Nilai"
        description="Apakah Anda yakin ingin menghapus catatan nilai akademik ini?"
        loading={savingSingle}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <ConfirmModal
        open={Boolean(bulkDeleteMode)}
        title="Hapus Data Penilaian Akademik"
        description={
          bulkDeleteMode === 'filtered'
            ? `Apakah Anda yakin ingin menghapus ${filteredHistory.length} data penilaian akademik yang ditampilkan saat ini? Tindakan ini tidak dapat dibatalkan.`
            : `Apakah Anda yakin ingin menghapus ${selectedIds.size} data penilaian akademik yang dipilih? Tindakan ini tidak dapat dibatalkan.`
        }
        confirmLabel="Ya, Hapus Data"
        loading={bulkDeleting}
        onConfirm={handleConfirmBulkDelete}
        onCancel={() => setBulkDeleteMode(null)}
      />
    </div>
  );
}
