import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Filter,
  Pencil,
  Plus,
  RotateCcw,
  Search,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { BulkStudentInput, useApp } from '../contexts/AppContext';
import { FIELD_LIMITS, Gender, Student } from '../types';
import { downloadStudentTemplateExcel } from '../utils/exportUtils';

interface ParsedImportRow {
  rowNumber: number;
  nis: string;
  fullName: string;
  genderRaw: string;
  gender: Gender | null;
  className: string;
  matchedClassId?: string;
  error?: string;
}

function normalizeHeader(key: string): string {
  return key
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

function parseGenderValue(raw: string): Gender | null {
  const val = raw.trim().toLowerCase();
  if (val === 'l' || val === 'laki-laki' || val === 'laki' || val === 'male') {
    return 'L';
  }
  if (val === 'p' || val === 'perempuan' || val === 'wanita' || val === 'female') {
    return 'P';
  }
  return null;
}

export function SiswaPage() {
  const {
    classes,
    students,
    addStudent,
    updateStudent,
    deleteStudent,
    deleteStudentsBulk,
    bulkImportStudents,
  } = useApp();

  const [search, setSearch] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('ALL');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Student | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleteTarget, setBulkDeleteTarget] = useState<{
    title: string;
    description: string;
    ids: string[];
  } | null>(null);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const [nis, setNis] = useState('');
  const [fullName, setFullName] = useState('');
  const [gender, setGender] = useState<Gender>('L');
  const [classId, setClassId] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  // Import Excel state
  const [importOpen, setImportOpen] = useState(false);
  const [importFileName, setImportFileName] = useState('');
  const [parsedRows, setParsedRows] = useState<ParsedImportRow[]>([]);
  const [createMissingClasses, setCreateMissingClasses] = useState(true);
  const [defaultAcademicYear, setDefaultAcademicYear] = useState('2026/2027');
  const [importFeedback, setImportFeedback] = useState<string | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const classMap = useMemo(
    () => new Map(classes.map((c) => [c.id, c])),
    [classes]
  );

  const sortedClasses = useMemo(
    () => [...classes].sort((a, b) => a.name.localeCompare(b.name, 'id')),
    [classes]
  );

  const classStudentCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const st of students) {
      counts.set(st.classId, (counts.get(st.classId) ?? 0) + 1);
    }
    return counts;
  }, [students]);

  useEffect(() => {
    if (selectedClassId !== 'ALL' && !classMap.has(selectedClassId)) {
      setSelectedClassId('ALL');
    }
  }, [selectedClassId, classMap]);

  useEffect(() => {
    const validIds = new Set(students.map((s) => s.id));
    setSelectedIds((prev) => {
      if (prev.size === 0) return prev;
      let changed = false;
      const next = new Set<string>();
      for (const id of prev) {
        if (validIds.has(id)) next.add(id);
        else changed = true;
      }
      return changed ? next : prev;
    });
  }, [students]);

  const classByNameLower = useMemo(
    () => new Map(classes.map((c) => [c.name.trim().toLowerCase(), c])),
    [classes]
  );

  const filteredStudents = useMemo(() => {
    const q = search.trim().toLowerCase();
    return students.filter((s) => {
      if (selectedClassId !== 'ALL' && s.classId !== selectedClassId) {
        return false;
      }
      if (!q) return true;
      return (
        s.nis.toLowerCase().includes(q) ||
        s.fullName.toLowerCase().includes(q)
      );
    });
  }, [students, search, selectedClassId]);

  const filteredSummary = useMemo(() => {
    let male = 0;
    let female = 0;
    for (const s of filteredStudents) {
      if (s.gender === 'L') male++;
      else female++;
    }
    return {
      total: filteredStudents.length,
      male,
      female,
    };
  }, [filteredStudents]);

  const groupedStudents = useMemo(() => {
    const groups = new Map<
      string,
      { className: string; academicYear: string; students: Student[] }
    >();

    for (const st of filteredStudents) {
      const cls = classMap.get(st.classId);
      const key = st.classId;
      if (!groups.has(key)) {
        groups.set(key, {
          className: cls?.name ?? 'Kelas Tidak Ditemukan',
          academicYear: cls?.academicYear ?? '-',
          students: [],
        });
      }
      groups.get(key)!.students.push(st);
    }

    return Array.from(groups.entries()).sort(([, a], [, b]) =>
      a.className.localeCompare(b.className, 'id')
    );
  }, [filteredStudents, classMap]);

  const hasActiveFilter = selectedClassId !== 'ALL' || search.trim() !== '';

  const resetFilters = () => {
    setSearch('');
    setSelectedClassId('ALL');
  };

  const openCreate = () => {
    setEditing(null);
    setNis('');
    setFullName('');
    setGender('L');
    setClassId(
      selectedClassId !== 'ALL' ? selectedClassId : sortedClasses[0]?.id ?? ''
    );
    setFormError('');
    setModalOpen(true);
  };

  const openEdit = (st: Student) => {
    setEditing(st);
    setNis(st.nis);
    setFullName(st.fullName);
    setGender(st.gender);
    setClassId(st.classId);
    setFormError('');
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nis.trim() || !fullName.trim() || !classId) {
      setFormError('NIS, nama lengkap, dan kelas wajib diisi.');
      return;
    }
    setSaving(true);
    setFormError('');
    try {
      if (editing) {
        await updateStudent(editing.id, { nis, fullName, gender, classId });
      } else {
        await addStudent({ nis, fullName, gender, classId });
      }
      setModalOpen(false);
    } catch (err) {
      setFormError(
        err instanceof Error ? err.message : 'Gagal menyimpan data siswa.'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      await deleteStudent(deleteTarget.id);
      setActionFeedback({
        type: 'success',
        text: `Siswa "${deleteTarget.fullName}" berhasil dihapus.`,
      });
      setDeleteTarget(null);
    } finally {
      setSaving(false);
    }
  };

  const toggleSelectStudent = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectClassGroup = (groupStudents: Student[]) => {
    const groupIds = groupStudents.map((s) => s.id);
    const allSelected =
      groupIds.length > 0 && groupIds.every((id) => selectedIds.has(id));
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allSelected) {
        for (const id of groupIds) next.delete(id);
      } else {
        for (const id of groupIds) next.add(id);
      }
      return next;
    });
  };

  const handleConfirmBulkDelete = async () => {
    if (!bulkDeleteTarget || bulkDeleteTarget.ids.length === 0) {
      setBulkDeleteTarget(null);
      return;
    }
    setBulkDeleting(true);
    setActionFeedback(null);
    try {
      const removed = await deleteStudentsBulk(bulkDeleteTarget.ids);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        for (const id of bulkDeleteTarget.ids) next.delete(id);
        return next;
      });
      setBulkDeleteTarget(null);
      setActionFeedback({
        type: 'success',
        text: `${removed} data siswa berhasil dihapus.`,
      });
    } catch (err) {
      setBulkDeleteTarget(null);
      setActionFeedback({
        type: 'error',
        text:
          err instanceof Error
            ? err.message
            : 'Gagal menghapus data siswa secara massal.',
      });
    } finally {
      setBulkDeleting(false);
    }
  };

  const handleOpenImport = () => {
    setImportOpen(true);
    setImportFileName('');
    setParsedRows([]);
    setImportError(null);
    setImportFeedback(null);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportError(null);
    setImportFeedback(null);
    setImportFileName(file.name);

    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      if (!firstSheetName) {
        setImportError('File tidak memiliki sheet data.');
        setParsedRows([]);
        return;
      }
      const sheet = workbook.Sheets[firstSheetName];
      const rawJson = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
        defval: '',
      });

      if (rawJson.length === 0) {
        setImportError(
          'File kosong atau tidak berisi baris data siswa. Pastikan menggunakan baris header.'
        );
        setParsedRows([]);
        return;
      }

      const mapped: ParsedImportRow[] = rawJson.map((rawObj, index) => {
        const normalizedObj: Record<string, string> = {};
        for (const [k, v] of Object.entries(rawObj)) {
          normalizedObj[normalizeHeader(k)] = String(v ?? '').trim();
        }

        const nisVal =
          normalizedObj['nis'] ||
          normalizedObj['nisn'] ||
          normalizedObj['nomorinduk'] ||
          '';
        const nameVal =
          normalizedObj['namalengkap'] ||
          normalizedObj['nama'] ||
          normalizedObj['namasiswa'] ||
          normalizedObj['fullname'] ||
          '';
        const genderRaw =
          normalizedObj['jeniskelamin'] ||
          normalizedObj['jk'] ||
          normalizedObj['gender'] ||
          normalizedObj['kelamin'] ||
          '';
        const classVal =
          normalizedObj['kelas'] ||
          normalizedObj['namakelas'] ||
          normalizedObj['class'] ||
          '';

        const parsedGender = parseGenderValue(genderRaw);
        const matchedClass = classByNameLower.get(classVal.toLowerCase());

        let errorMsg: string | undefined;
        if (!nisVal) errorMsg = 'NIS kosong';
        else if (!nameVal) errorMsg = 'Nama lengkap kosong';
        else if (!parsedGender)
          errorMsg = 'Jenis kelamin harus L atau P';
        else if (!classVal) errorMsg = 'Kolom Kelas kosong';
        else if (!matchedClass && !createMissingClasses)
          errorMsg = 'Kelas belum terdaftar';

        return {
          rowNumber: index + 2,
          nis: nisVal,
          fullName: nameVal,
          genderRaw,
          gender: parsedGender,
          className: classVal,
          matchedClassId: matchedClass?.id,
          error: errorMsg,
        };
      });

      setParsedRows(mapped);
    } catch {
      setImportError(
        'Gagal membaca file. Pastikan format file adalah .xlsx, .xls, atau .csv yang valid.'
      );
      setParsedRows([]);
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const evaluatedRows = useMemo(() => {
    return parsedRows.map((row) => {
      if (!row.nis) return { ...row, error: 'NIS kosong' };
      if (!row.fullName) return { ...row, error: 'Nama lengkap kosong' };
      if (!row.gender)
        return { ...row, error: 'Jenis kelamin harus L atau P' };
      if (!row.className) return { ...row, error: 'Kolom Kelas kosong' };
      const matched = classByNameLower.get(row.className.toLowerCase());
      if (!matched && !createMissingClasses) {
        return { ...row, matchedClassId: undefined, error: 'Kelas belum terdaftar' };
      }
      return { ...row, matchedClassId: matched?.id, error: undefined };
    });
  }, [parsedRows, classByNameLower, createMissingClasses]);

  const validImportRows = useMemo(
    () => evaluatedRows.filter((r) => !r.error && r.gender !== null),
    [evaluatedRows]
  );

  const invalidImportCount = evaluatedRows.length - validImportRows.length;

  const handleConfirmImport = async () => {
    if (validImportRows.length === 0) return;
    setImporting(true);
    setImportError(null);
    try {
      const payload: BulkStudentInput[] = validImportRows.map((r) => ({
        nis: r.nis,
        fullName: r.fullName,
        gender: r.gender!,
        className: r.className,
        classId: r.matchedClassId,
      }));
      const res = await bulkImportStudents(
        payload,
        createMissingClasses,
        defaultAcademicYear
      );
      setImportFeedback(
        `Berhasil mengimpor ${res.importedCount} siswa${
          res.createdClassesCount > 0
            ? ` dan membuat ${res.createdClassesCount} kelas baru`
            : ''
        }.`
      );
      setParsedRows([]);
      setImportFileName('');
    } catch (err) {
      setImportError(
        err instanceof Error ? err.message : 'Gagal menyimpan data import.'
      );
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Data Siswa
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Kelola data siswa per kelas atau unggah massal dari file Excel / CSV.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={downloadStudentTemplateExcel}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
            <span>Unduh Template Excel</span>
          </button>

          <button
            type="button"
            onClick={handleOpenImport}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-blue-800 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-950 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Upload className="w-4 h-4 shrink-0" />
            <span>Import Excel / CSV</span>
          </button>

          <button
            type="button"
            onClick={openCreate}
            disabled={classes.length === 0}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4 shrink-0" />
            <span>Tambah Siswa</span>
          </button>
        </div>
      </div>

      {classes.length === 0 && (
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-xl p-4 text-sm text-amber-900 dark:text-amber-200">
          Belum ada data kelas. Anda tetap dapat menggunakan fitur{' '}
          <strong>Import Excel / CSV</strong> dengan opsi buat kelas otomatis,
          atau tambahkan kelas terlebih dahulu di menu <strong>Kelas</strong>.
        </div>
      )}

      {actionFeedback && (
        <div
          className={`p-3.5 text-sm rounded-xl border flex items-center justify-between gap-2 ${
            actionFeedback.type === 'success'
              ? 'text-emerald-900 dark:text-emerald-200 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900/60'
              : 'text-red-900 dark:text-red-200 bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-900/60'
          }`}
        >
          <div className="flex items-center gap-2">
            {actionFeedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-700 dark:text-red-400 shrink-0" />
            )}
            <span>{actionFeedback.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setActionFeedback(null)}
            className="p-1 hover:opacity-70 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Search & Class Filter */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari NIS atau nama lengkap siswa..."
              aria-label="Cari NIS atau nama lengkap siswa"
              className="w-full pl-9 pr-8 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch('')}
                title="Hapus pencarian"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Filter className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <select
                value={selectedClassId}
                onChange={(e) => setSelectedClassId(e.target.value)}
                aria-label="Filter berdasarkan kelas"
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 cursor-pointer"
              >
                <option value="ALL">
                  Semua Kelas ({students.length} Siswa)
                </option>
                {sortedClasses.map((c) => {
                  const count = classStudentCounts.get(c.id) ?? 0;
                  return (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.academicYear}) — {count} Siswa
                    </option>
                  );
                })}
              </select>
            </div>

            {hasActiveFilter && (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                title="Reset filter kelas dan pencarian"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        {sortedClasses.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2.5 border-t border-slate-100 dark:border-slate-800">
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => setSelectedClassId('ALL')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                  selectedClassId === 'ALL'
                    ? 'bg-blue-700 text-white border-blue-700 dark:bg-blue-600 dark:border-blue-600'
                    : 'bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                Semua ({students.length})
              </button>
              {sortedClasses.map((c) => {
                const count = classStudentCounts.get(c.id) ?? 0;
                const active = selectedClassId === c.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setSelectedClassId(c.id)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-colors cursor-pointer tabular-nums ${
                      active
                        ? 'bg-blue-700 text-white border-blue-700 dark:bg-blue-600 dark:border-blue-600'
                        : 'bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    {c.name} ({count})
                  </button>
                );
              })}
            </div>

            <div className="text-xs text-slate-500 dark:text-slate-400 tabular-nums whitespace-nowrap">
              Menampilkan{' '}
              <strong className="font-semibold text-slate-700 dark:text-slate-200">
                {filteredSummary.total}
              </strong>{' '}
              dari {students.length} siswa · L: {filteredSummary.male} · P:{' '}
              {filteredSummary.female}
            </div>
          </div>
        )}
      </div>

      {/* Grouped Students */}
      {groupedStudents.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center">
          <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
            {students.length === 0
              ? 'Belum ada data siswa tersimpan'
              : 'Tidak ada siswa sesuai filter'}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">
            {students.length === 0
              ? 'Tambahkan siswa satu per satu atau unggah file Excel sekaligus.'
              : 'Ubah kata kunci pencarian atau pilihan kelas untuk melihat siswa lainnya.'}
          </p>
          {students.length === 0 ? (
            <button
              type="button"
              onClick={handleOpenImport}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Import Data Siswa (Excel)</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Tampilkan Semua Siswa</span>
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-5">
          {groupedStudents.map(([clsId, group]) => {
            const allGroupSelected =
              group.students.length > 0 &&
              group.students.every((s) => selectedIds.has(s.id));
            const selectedInGroupIds = group.students
              .filter((s) => selectedIds.has(s.id))
              .map((s) => s.id);
            const allClassStudentIds = students
              .filter((s) => s.classId === clsId)
              .map((s) => s.id);

            return (
              <div
                key={clsId}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden"
              >
                <div className="px-5 py-3.5 bg-slate-50/70 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-baseline gap-2.5">
                    <h2 className="font-display font-semibold text-base text-slate-900 dark:text-slate-100">
                      {group.className}
                    </h2>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      {group.academicYear} ·{' '}
                      <span className="tabular-nums">
                        {group.students.length} siswa
                      </span>
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {selectedInGroupIds.length > 0 && (
                      <button
                        type="button"
                        onClick={() =>
                          setBulkDeleteTarget({
                            title: `Hapus Siswa Terpilih (${group.className})`,
                            description: `Apakah Anda yakin ingin menghapus ${selectedInGroupIds.length} siswa yang dipilih dari kelas "${group.className}"? Tindakan ini tidak dapat dibatalkan.`,
                            ids: selectedInGroupIds,
                          })
                        }
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>
                          Hapus Terpilih ({selectedInGroupIds.length})
                        </span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() =>
                        setBulkDeleteTarget({
                          title: `Hapus Semua Siswa Kelas ${group.className}`,
                          description: `Apakah Anda yakin ingin menghapus seluruh ${allClassStudentIds.length} siswa di kelas "${group.className}"? Tindakan ini tidak dapat dibatalkan.`,
                          ids: allClassStudentIds,
                        })
                      }
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>
                        Hapus Siswa Kelas Ini ({allClassStudentIds.length})
                      </span>
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-100 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                        <th className="py-2.5 px-4 w-10 text-center">
                          <input
                            type="checkbox"
                            checked={allGroupSelected}
                            onChange={() =>
                              toggleSelectClassGroup(group.students)
                            }
                            aria-label={`Pilih semua siswa di kelas ${group.className}`}
                            className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700 cursor-pointer"
                          />
                        </th>
                        <th className="py-2.5 px-3 w-12">No</th>
                        <th className="py-2.5 px-4 w-36">NIS</th>
                        <th className="py-2.5 px-4">Nama Lengkap</th>
                        <th className="py-2.5 px-4 w-36">Jenis Kelamin</th>
                        <th className="py-2.5 px-5 text-right w-28">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                      {group.students.map((st, idx) => {
                        const checked = selectedIds.has(st.id);
                        return (
                          <tr
                            key={st.id}
                            className={`transition-colors ${
                              checked
                                ? 'bg-blue-50/50 dark:bg-blue-950/20'
                                : 'hover:bg-slate-50/80 dark:hover:bg-slate-800/50'
                            }`}
                          >
                            <td className="py-2.5 px-4 text-center">
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={() => toggleSelectStudent(st.id)}
                                aria-label={`Pilih siswa ${st.fullName}`}
                                className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700 cursor-pointer"
                              />
                            </td>
                            <td className="py-2.5 px-3 font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                              {idx + 1}
                            </td>
                            <td className="py-2.5 px-4 font-mono text-xs text-slate-700 dark:text-slate-300 tabular-nums">
                              {st.nis}
                            </td>
                            <td className="py-2.5 px-4 font-medium text-slate-900 dark:text-slate-100">
                              {st.fullName}
                            </td>
                            <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300">
                              {st.gender === 'L'
                                ? 'Laki-laki (L)'
                                : 'Perempuan (P)'}
                            </td>
                            <td className="py-2.5 px-5 text-right">
                              <div className="inline-flex items-center justify-end gap-1">
                                <button
                                  type="button"
                                  onClick={() => openEdit(st)}
                                  className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-blue-700 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 rounded-md transition-colors cursor-pointer"
                                  title="Edit Siswa"
                                >
                                  <Pencil className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setDeleteTarget(st)}
                                  className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-red-700 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-md transition-colors cursor-pointer"
                                  title="Hapus Siswa"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Manual Add/Edit Student Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 dark:bg-slate-950/70">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display font-semibold text-lg text-slate-900 dark:text-slate-100">
                {editing ? 'Edit Data Siswa' : 'Tambah Siswa Baru'}
              </h2>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1 text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 rounded-md cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 p-3 text-xs text-red-800 dark:text-red-200 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 rounded-lg">
                {formError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  NIS
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.STUDENT_NIS}
                  value={nis}
                  onChange={(e) => setNis(e.target.value)}
                  placeholder="Contoh: 2026001"
                  className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Nama Lengkap
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.STUDENT_NAME}
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Nama lengkap siswa"
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Jenis Kelamin
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as Gender)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                  >
                    <option value="L">Laki-laki (L)</option>
                    <option value="P">Perempuan (P)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Kelas
                  </label>
                  <select
                    required
                    value={classId}
                    onChange={(e) => setClassId(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                  >
                    <option value="">Pilih Kelas</option>
                    {sortedClasses.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {saving ? 'Menyimpan...' : 'Simpan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Excel/CSV Bulk Import Modal */}
      {importOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 dark:bg-slate-950/70">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-4xl w-full max-h-[90vh] flex flex-col">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <FileSpreadsheet className="w-5 h-5 text-blue-700 dark:text-blue-400 shrink-0" />
                <h2 className="font-display font-semibold text-lg text-slate-900 dark:text-slate-100">
                  Import Data Siswa dari Excel / CSV
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setImportOpen(false)}
                className="p-1 text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 rounded-md cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              {/* Step 1: Download Template & Upload */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                    Format Kolom: NIS, Nama Lengkap, Jenis Kelamin (L/P), Kelas
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Mendukung file .xlsx, .xls, dan .csv. Unduh template resmi
                    untuk menghindari kesalahan format.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={downloadStudentTemplateExcel}
                  className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh Template</span>
                </button>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                <label className="flex items-center gap-2.5 text-sm text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={createMissingClasses}
                    onChange={(e) => setCreateMissingClasses(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700 focus:ring-blue-600"
                  />
                  <span>
                    Buat kelas baru otomatis jika nama kelas belum terdaftar
                  </span>
                </label>

                {createMissingClasses && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 dark:text-slate-400 whitespace-nowrap">
                      Tahun Ajaran Default:
                    </span>
                    <input
                      type="text"
                      value={defaultAcademicYear}
                      onChange={(e) => setDefaultAcademicYear(e.target.value)}
                      maxLength={FIELD_LIMITS.ACADEMIC_YEAR}
                      className="w-28 px-2.5 py-1.5 text-xs font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-md"
                    />
                  </div>
                )}
              </div>

              <div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  onChange={handleFileChange}
                  className="hidden"
                  id="excel-upload-input"
                />
                <label
                  htmlFor="excel-upload-input"
                  className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-500 hover:bg-blue-50/40 dark:hover:bg-blue-950/30 rounded-xl p-8 text-center cursor-pointer transition-colors"
                >
                  <Upload className="w-7 h-7 text-blue-700 dark:text-blue-400 mb-2" />
                  <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
                    {importFileName
                      ? `File terpilih: ${importFileName}`
                      : 'Klik untuk memilih file Excel (.xlsx / .xls) atau CSV'}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Data akan ditampilkan sebagai pratinjau sebelum disimpan ke
                    database
                  </p>
                </label>
              </div>

              {importError && (
                <div className="p-3 text-sm text-red-800 dark:text-red-200 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 rounded-lg">
                  {importError}
                </div>
              )}

              {importFeedback && (
                <div className="p-3.5 text-sm text-emerald-900 dark:text-emerald-200 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 rounded-lg flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                  <span>{importFeedback}</span>
                </div>
              )}

              {/* Preview Table */}
              {evaluatedRows.length > 0 && (
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="font-medium text-slate-800 dark:text-slate-200">
                      Pratinjau Data Import ({evaluatedRows.length} baris)
                    </span>
                    <div className="flex items-center gap-3 tabular-nums">
                      <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                        Siap impor: {validImportRows.length}
                      </span>
                      {invalidImportCount > 0 && (
                        <span className="text-red-700 dark:text-red-400 font-medium">
                          Perlu diperbaiki: {invalidImportCount}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden max-h-64 overflow-y-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 sticky top-0 text-slate-500 dark:text-slate-400">
                        <tr>
                          <th className="py-2 px-3">Baris</th>
                          <th className="py-2 px-3">NIS</th>
                          <th className="py-2 px-3">Nama Lengkap</th>
                          <th className="py-2 px-3">JK</th>
                          <th className="py-2 px-3">Kelas</th>
                          <th className="py-2 px-3">Status Validasi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {evaluatedRows.map((row) => (
                          <tr
                            key={`${row.rowNumber}-${row.nis}`}
                            className={
                              row.error ? 'bg-red-50/50 dark:bg-red-950/30' : ''
                            }
                          >
                            <td className="py-2 px-3 font-mono tabular-nums text-slate-500 dark:text-slate-400">
                              {row.rowNumber}
                            </td>
                            <td className="py-2 px-3 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                              {row.nis || '-'}
                            </td>
                            <td className="py-2 px-3 font-medium text-slate-900 dark:text-slate-100">
                              {row.fullName || '-'}
                            </td>
                            <td className="py-2 px-3 text-slate-700 dark:text-slate-300">
                              {row.gender || row.genderRaw || '-'}
                            </td>
                            <td className="py-2 px-3 text-slate-700 dark:text-slate-300">
                              {row.className || '-'}
                              {!row.matchedClassId &&
                                row.className &&
                                createMissingClasses && (
                                  <span className="text-blue-700 dark:text-blue-400 ml-1">
                                    (Kelas baru)
                                  </span>
                                )}
                            </td>
                            <td className="py-2 px-3">
                              {row.error ? (
                                <span className="text-red-700 dark:text-red-400 font-medium">
                                  Gagal: {row.error}
                                </span>
                              ) : (
                                <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                                  Valid
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setImportOpen(false)}
                className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
              >
                Tutup
              </button>
              <button
                type="button"
                onClick={handleConfirmImport}
                disabled={importing || validImportRows.length === 0}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-50 rounded-lg cursor-pointer"
              >
                {importing
                  ? 'Menyimpan ke Database...'
                  : `Simpan ${validImportRows.length} Siswa ke Database`}
              </button>
            </div>
          </div>
        </div>
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Hapus Data Siswa"
        description={`Apakah Anda yakin ingin menghapus siswa "${deleteTarget?.fullName}" (NIS: ${deleteTarget?.nis})?`}
        loading={saving}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <ConfirmModal
        open={Boolean(bulkDeleteTarget)}
        title={bulkDeleteTarget?.title ?? 'Hapus Siswa per Kelas'}
        description={bulkDeleteTarget?.description ?? ''}
        confirmLabel="Ya, Hapus Siswa"
        loading={bulkDeleting}
        onConfirm={handleConfirmBulkDelete}
        onCancel={() => setBulkDeleteTarget(null)}
      />
    </div>
  );
}
