import React, { useEffect, useMemo, useState } from 'react';
import {
  BookOpen,
  CalendarDays,
  CheckCircle2,
  ClipboardCheck,
  Download,
  FileSpreadsheet,
  GraduationCap,
  Pencil,
  Printer,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { SchoolLogo } from '../components/SchoolLogo';
import { useApp } from '../contexts/AppContext';
import {
  ATTENDANCE_STATUSES,
  ATTITUDE_ASPECTS,
  ATTITUDE_PREDICATES,
  AcademicGrade,
  AssessmentType,
  AttendanceStatus,
  AttitudeAssessment,
  AttitudePredicate,
  FIELD_LIMITS,
  TeachingJournal,
  resolveGradeAssessmentType,
} from '../types';
import {
  exportToCsv,
  exportToExcel,
  formatIndonesianDate,
  getCurrentMonthIso,
  getIndonesianDayName,
  getTodayIso,
} from '../utils/exportUtils';

type ReportTab = 'harian' | 'akademik' | 'sikap' | 'jurnal' | 'kehadiran';
type AcademicScope = 'kelas' | 'siswa' | 'harian' | 'bulanan';
type SimpleScope = 'bulanan' | 'harian';
type JournalPeriodType = 'harian' | 'bulanan' | 'ganjil' | 'genap' | 'semua';

const ATTENDANCE_SHORT_LABEL: Record<AttendanceStatus, string> = {
  Hadir: 'H',
  Sakit: 'S',
  Izin: 'I',
  Alfa: 'A',
};

const ATTENDANCE_BADGE_CLASS: Record<AttendanceStatus, string> = {
  Hadir:
    'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800',
  Sakit:
    'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800',
  Izin: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800',
  Alfa: 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950/60 dark:text-red-300 dark:border-red-800',
};

type DeleteRequest =
  | { type: 'journal'; item: TeachingJournal }
  | { type: 'grade'; item: AcademicGrade }
  | { type: 'attitude'; item: AttitudeAssessment };

export function LaporanPage() {
  const {
    user,
    classes,
    subjects,
    students,
    categories,
    grades,
    attitudes,
    journals,
    attendances,
    updateGrade,
    deleteGrade,
    updateAttitude,
    deleteAttitude,
    saveJournalWithAttendance,
    deleteJournal,
  } = useApp();

  const [activeTab, setActiveTab] = useState<ReportTab>('harian');

  // Shared filters
  const [selectedClassId, setSelectedClassId] = useState('ALL');
  const [selectedSubjectId, setSelectedSubjectId] = useState('ALL');
  const [monthFilter, setMonthFilter] = useState(getCurrentMonthIso());
  const [dateFilter, setDateFilter] = useState(getTodayIso());

  // Tab-specific scopes
  const [academicScope, setAcademicScope] = useState<AcademicScope>('kelas');
  const [academicAssessmentFilter, setAcademicAssessmentFilter] = useState<
    'ALL' | AssessmentType
  >('ALL');
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [attitudeScope, setAttitudeScope] = useState<SimpleScope>('bulanan');
  const [attendanceScope, setAttendanceScope] =
    useState<SimpleScope>('bulanan');
  const [journalPeriod, setJournalPeriod] =
    useState<JournalPeriodType>('bulanan');

  // Feedback banner
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // Edit Grade Modal state
  const [editingGrade, setEditingGrade] = useState<AcademicGrade | null>(null);
  const [editGradeAssessmentType, setEditGradeAssessmentType] =
    useState<AssessmentType>('formatif');
  const [editGradeDate, setEditGradeDate] = useState('');
  const [editGradeCategoryId, setEditGradeCategoryId] = useState('');
  const [editGradeScore, setEditGradeScore] = useState('');
  const [editGradeChapter, setEditGradeChapter] = useState('');
  const [editGradeOrder, setEditGradeOrder] = useState('1');
  const [editGradeNotes, setEditGradeNotes] = useState('');

  // Edit Attitude Modal state
  const [editingAttitude, setEditingAttitude] =
    useState<AttitudeAssessment | null>(null);
  const [editAttDate, setEditAttDate] = useState('');
  const [editAttAspect, setEditAttAspect] = useState('');
  const [editAttPredicate, setEditAttPredicate] =
    useState<AttitudePredicate>('Baik');
  const [editAttNotes, setEditAttNotes] = useState('');

  // Edit Journal + Attendance Modal state
  const [editingJournal, setEditingJournal] =
    useState<TeachingJournal | null>(null);
  const [editJrnDate, setEditJrnDate] = useState('');
  const [editJrnHours, setEditJrnHours] = useState('');
  const [editJrnClassId, setEditJrnClassId] = useState('');
  const [editJrnSubjectId, setEditJrnSubjectId] = useState('');
  const [editJrnTopic, setEditJrnTopic] = useState('');
  const [editJrnReflection, setEditJrnReflection] = useState('');
  const [editJrnStatuses, setEditJrnStatuses] = useState<
    Record<string, AttendanceStatus>
  >({});

  // Delete confirmation & saving state
  const [deleteTarget, setDeleteTarget] = useState<DeleteRequest | null>(null);
  const [savingEdit, setSavingEdit] = useState(false);
  const [modalError, setModalError] = useState('');

  useEffect(() => {
    const classStudents =
      selectedClassId === 'ALL'
        ? students
        : students.filter((s) => s.classId === selectedClassId);
    if (
      classStudents.length > 0 &&
      !classStudents.some((s) => s.id === selectedStudentId)
    ) {
      setSelectedStudentId(classStudents[0].id);
    }
  }, [students, selectedClassId, selectedStudentId]);

  const classMap = useMemo(
    () => new Map(classes.map((c) => [c.id, c.name])),
    [classes]
  );
  const subjectMap = useMemo(
    () => new Map(subjects.map((s) => [s.id, s.name])),
    [subjects]
  );
  const subjectCodeMap = useMemo(
    () => new Map(subjects.map((s) => [s.id, s.code])),
    [subjects]
  );
  const categoryMap = useMemo(
    () => new Map(categories.map((c) => [c.id, c])),
    [categories]
  );
  const studentMap = useMemo(
    () => new Map(students.map((s) => [s.id, s])),
    [students]
  );
  const journalMap = useMemo(
    () => new Map(journals.map((j) => [j.id, j])),
    [journals]
  );

  // =========================================================================
  // 1. Unified Daily Report Data (Laporan Harian)
  // =========================================================================
  const dailyJournals = useMemo(() => {
    return journals
      .filter((j) => {
        if (j.date !== dateFilter) return false;
        if (selectedClassId !== 'ALL' && j.classId !== selectedClassId)
          return false;
        if (selectedSubjectId !== 'ALL' && j.subjectId !== selectedSubjectId)
          return false;
        return true;
      })
      .sort((a, b) => a.lessonHours.localeCompare(b.lessonHours));
  }, [journals, dateFilter, selectedClassId, selectedSubjectId]);

  const dailyGrades = useMemo(() => {
    return grades.filter((g) => {
      if (g.date !== dateFilter) return false;
      if (selectedClassId !== 'ALL' && g.classId !== selectedClassId)
        return false;
      if (selectedSubjectId !== 'ALL' && g.subjectId !== selectedSubjectId)
        return false;
      return true;
    });
  }, [grades, dateFilter, selectedClassId, selectedSubjectId]);

  const dailyAttitudes = useMemo(() => {
    return attitudes.filter((a) => {
      if (a.date !== dateFilter) return false;
      if (selectedClassId !== 'ALL' && a.classId !== selectedClassId)
        return false;
      if (selectedSubjectId !== 'ALL' && a.subjectId !== selectedSubjectId)
        return false;
      return true;
    });
  }, [attitudes, dateFilter, selectedClassId, selectedSubjectId]);

  const dailyAttendanceRows = useMemo(() => {
    return attendances
      .filter((a) => {
        if (a.date !== dateFilter) return false;
        if (selectedClassId !== 'ALL' && a.classId !== selectedClassId)
          return false;
        if (selectedSubjectId !== 'ALL' && a.subjectId !== selectedSubjectId)
          return false;
        return true;
      })
      .sort((a, b) => {
        const clsA = classMap.get(a.classId) ?? '';
        const clsB = classMap.get(b.classId) ?? '';
        if (clsA !== clsB) return clsA.localeCompare(clsB);
        const stA = studentMap.get(a.studentId)?.fullName ?? '';
        const stB = studentMap.get(b.studentId)?.fullName ?? '';
        return stA.localeCompare(stB);
      });
  }, [
    attendances,
    dateFilter,
    selectedClassId,
    selectedSubjectId,
    classMap,
    studentMap,
  ]);

  const dailyAttendanceSummary = useMemo(() => {
    let h = 0;
    let s = 0;
    let i = 0;
    let a = 0;
    if (dailyAttendanceRows.length > 0) {
      for (const rec of dailyAttendanceRows) {
        if (rec.status === 'Hadir') h += 1;
        else if (rec.status === 'Sakit') s += 1;
        else if (rec.status === 'Izin') i += 1;
        else a += 1;
      }
    } else {
      for (const j of dailyJournals) {
        h += j.presentCount;
        s += j.sickCount;
        i += j.permissionCount;
        a += j.absentCount;
      }
    }
    return { h, s, i, a };
  }, [dailyAttendanceRows, dailyJournals]);

  // =========================================================================
  // 2. Academic Report Data
  // =========================================================================
  const academicCategories = useMemo(() => {
    return categories.filter((c) => {
      if (
        selectedClassId !== 'ALL' &&
        c.classId &&
        c.classId !== selectedClassId
      )
        return false;
      if (selectedSubjectId !== 'ALL' && c.subjectId !== selectedSubjectId)
        return false;
      return true;
    });
  }, [categories, selectedClassId, selectedSubjectId]);

  const academicClassStudents = useMemo(() => {
    if (selectedClassId === 'ALL') return students;
    return students.filter((s) => s.classId === selectedClassId);
  }, [students, selectedClassId]);

  const academicClassRows = useMemo(() => {
    return academicClassStudents.map((st, index) => {
      const stGrades = grades.filter((g) => {
        if (g.studentId !== st.id) return false;
        if (selectedClassId !== 'ALL' && g.classId !== selectedClassId)
          return false;
        if (selectedSubjectId !== 'ALL' && g.subjectId !== selectedSubjectId)
          return false;
        if (academicScope === 'bulanan' && !g.date.startsWith(monthFilter))
          return false;
        if (
          academicAssessmentFilter !== 'ALL' &&
          resolveGradeAssessmentType(g, categoryMap.get(g.categoryId)?.name) !==
            academicAssessmentFilter
        )
          return false;
        return true;
      });

      const formatifGrades = stGrades.filter(
        (g) =>
          resolveGradeAssessmentType(g, categoryMap.get(g.categoryId)?.name) ===
          'formatif'
      );
      const sumatifGrades = stGrades.filter(
        (g) =>
          resolveGradeAssessmentType(g, categoryMap.get(g.categoryId)?.name) ===
          'sumatif'
      );
      const formatifAvg =
        formatifGrades.length > 0
          ? Number(
              (
                formatifGrades.reduce((sum, x) => sum + x.score, 0) /
                formatifGrades.length
              ).toFixed(1)
            )
          : null;
      const sumatifAvg =
        sumatifGrades.length > 0
          ? Number(
              (
                sumatifGrades.reduce((sum, x) => sum + x.score, 0) /
                sumatifGrades.length
              ).toFixed(1)
            )
          : null;

      const catAverages: Record<string, number | null> = {};
      let weightedSum = 0;
      let usedWeight = 0;

      for (const cat of academicCategories) {
        const catGrades = stGrades.filter((g) => g.categoryId === cat.id);
        if (catGrades.length > 0) {
          const avg =
            catGrades.reduce((sum, x) => sum + x.score, 0) / catGrades.length;
          catAverages[cat.id] = Number(avg.toFixed(1));
          weightedSum += avg * cat.weight;
          usedWeight += cat.weight;
        } else {
          catAverages[cat.id] = null;
        }
      }

      const finalScore =
        usedWeight > 0
          ? Number((weightedSum / usedWeight).toFixed(1))
          : stGrades.length > 0
          ? Number(
              (
                stGrades.reduce((sum, x) => sum + x.score, 0) / stGrades.length
              ).toFixed(1)
            )
          : null;

      return {
        no: index + 1,
        student: st,
        className: classMap.get(st.classId) ?? '-',
        catAverages,
        formatifAvg,
        sumatifAvg,
        finalScore,
        status:
          finalScore === null
            ? 'Belum Dinilai'
            : finalScore >= 75
            ? 'Tuntas'
            : 'Perlu Remedial',
      };
    });
  }, [
    academicClassStudents,
    grades,
    selectedClassId,
    selectedSubjectId,
    academicScope,
    academicAssessmentFilter,
    monthFilter,
    academicCategories,
    categoryMap,
    classMap,
  ]);

  const academicDailyOrStudentEntries = useMemo(() => {
    return grades.filter((g) => {
      if (selectedClassId !== 'ALL' && g.classId !== selectedClassId)
        return false;
      if (selectedSubjectId !== 'ALL' && g.subjectId !== selectedSubjectId)
        return false;
      if (academicScope === 'harian' && g.date !== dateFilter) return false;
      if (academicScope === 'siswa' && g.studentId !== selectedStudentId)
        return false;
      if (
        academicAssessmentFilter !== 'ALL' &&
        resolveGradeAssessmentType(g, categoryMap.get(g.categoryId)?.name) !==
          academicAssessmentFilter
      )
        return false;
      return true;
    });
  }, [
    grades,
    selectedClassId,
    selectedSubjectId,
    academicScope,
    academicAssessmentFilter,
    dateFilter,
    selectedStudentId,
    categoryMap,
  ]);

  // =========================================================================
  // 3. Attitude Report Data (Bulanan & Harian)
  // =========================================================================
  const attitudeReportRows = useMemo(() => {
    const targetStudents =
      selectedClassId === 'ALL'
        ? students
        : students.filter((s) => s.classId === selectedClassId);

    return targetStudents.map((st, idx) => {
      const records = attitudes.filter((a) => {
        if (a.studentId !== st.id) return false;
        if (selectedSubjectId !== 'ALL' && a.subjectId !== selectedSubjectId)
          return false;
        if (monthFilter && !a.date.startsWith(monthFilter)) return false;
        return true;
      });

      const counts = {
        sb: records.filter((r) => r.predicate === 'Sangat Baik').length,
        b: records.filter((r) => r.predicate === 'Baik').length,
        c: records.filter((r) => r.predicate === 'Cukup').length,
        pb: records.filter((r) => r.predicate === 'Perlu Bimbingan').length,
      };

      let dominant = '-';
      if (records.length > 0) {
        const entries: [string, number][] = [
          ['Sangat Baik', counts.sb],
          ['Baik', counts.b],
          ['Cukup', counts.c],
          ['Perlu Bimbingan', counts.pb],
        ];
        entries.sort((a, b) => b[1] - a[1]);
        dominant = entries[0][0];
      }

      const specialNotes = records
        .filter((r) => r.notes && r.notes.trim() !== '')
        .map((r) => `${r.aspect}: ${r.notes}`)
        .join('; ');

      return {
        no: idx + 1,
        student: st,
        className: classMap.get(st.classId) ?? '-',
        totalRecords: records.length,
        ...counts,
        dominant,
        specialNotes: specialNotes || '-',
      };
    });
  }, [
    students,
    selectedClassId,
    selectedSubjectId,
    attitudes,
    monthFilter,
    classMap,
  ]);

  // =========================================================================
  // 4. Teaching Journal Report Data
  // =========================================================================
  const journalReportRows = useMemo(() => {
    return journals
      .filter((j) => {
        if (selectedClassId !== 'ALL' && j.classId !== selectedClassId)
          return false;
        if (selectedSubjectId !== 'ALL' && j.subjectId !== selectedSubjectId)
          return false;
        if (journalPeriod === 'harian') {
          return j.date === dateFilter;
        }
        if (journalPeriod === 'bulanan') {
          return j.date.startsWith(monthFilter);
        }
        if (journalPeriod === 'ganjil') {
          const m = Number(j.date.slice(5, 7));
          return m >= 7 && m <= 12;
        }
        if (journalPeriod === 'genap') {
          const m = Number(j.date.slice(5, 7));
          return m >= 1 && m <= 6;
        }
        return true;
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [
    journals,
    selectedClassId,
    selectedSubjectId,
    journalPeriod,
    dateFilter,
    monthFilter,
  ]);

  // =========================================================================
  // 5. Student Attendance Report Data (Bulanan & Harian)
  // =========================================================================
  const attendanceReportRows = useMemo(() => {
    const targetStudents =
      selectedClassId === 'ALL'
        ? students
        : students.filter((s) => s.classId === selectedClassId);

    return targetStudents.map((st, idx) => {
      const recs = attendances.filter((a) => {
        if (a.studentId !== st.id) return false;
        if (selectedSubjectId !== 'ALL' && a.subjectId !== selectedSubjectId)
          return false;
        if (!a.date.startsWith(monthFilter)) return false;
        return true;
      });
      const hadir = recs.filter((r) => r.status === 'Hadir').length;
      const sakit = recs.filter((r) => r.status === 'Sakit').length;
      const izin = recs.filter((r) => r.status === 'Izin').length;
      const alfa = recs.filter((r) => r.status === 'Alfa').length;
      const total = recs.length;
      const pct = total > 0 ? Math.round((hadir / total) * 100) : 0;

      const evaluation =
        total === 0
          ? 'Belum Ada Data'
          : pct >= 90
          ? 'Disiplin Baik'
          : pct >= 75
          ? 'Perlu Pemantauan'
          : 'Peringatan Kedisiplinan';

      return {
        no: idx + 1,
        student: st,
        className: classMap.get(st.classId) ?? '-',
        total,
        hadir,
        sakit,
        izin,
        alfa,
        pct,
        evaluation,
      };
    });
  }, [
    students,
    selectedClassId,
    selectedSubjectId,
    attendances,
    monthFilter,
    classMap,
  ]);

  // =========================================================================
  // Edit & Delete Modal Handlers
  // =========================================================================
  const openEditGradeModal = (g: AcademicGrade) => {
    setEditingGrade(g);
    setEditGradeAssessmentType(
      resolveGradeAssessmentType(g, categoryMap.get(g.categoryId)?.name)
    );
    setEditGradeDate(g.date);
    setEditGradeCategoryId(g.categoryId);
    setEditGradeScore(String(g.score));
    setEditGradeChapter(g.chapter ?? '');
    setEditGradeOrder(String(g.assessmentOrder ?? 1));
    setEditGradeNotes(g.notes ?? '');
    setModalError('');
  };

  const handleSaveEditGrade = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingGrade) return;
    const scoreNum = Number(editGradeScore);
    if (!Number.isFinite(scoreNum) || scoreNum < 0 || scoreNum > 100) {
      setModalError('Nilai harus berupa angka 0 sampai 100.');
      return;
    }
    const ch = editGradeChapter.trim();
    const ord = Math.max(
      1,
      Math.min(20, Math.round(Number(editGradeOrder) || 1))
    );
    setSavingEdit(true);
    setModalError('');
    try {
      await updateGrade(editingGrade.id, {
        date: editGradeDate,
        classId: editingGrade.classId,
        subjectId: editingGrade.subjectId,
        categoryId: editGradeCategoryId || editingGrade.categoryId,
        studentId: editingGrade.studentId,
        score: scoreNum,
        assessmentType: editGradeAssessmentType,
        chapter: ch || undefined,
        assessmentOrder: ch ? ord : undefined,
        assessmentLabel: ch ? `Penilaian ${ord}` : undefined,
        notes: editGradeNotes,
      });
      setEditingGrade(null);
      setActionMessage('Nilai akademik berhasil diperbarui.');
    } catch (err) {
      setModalError(
        err instanceof Error ? err.message : 'Gagal memperbarui nilai.'
      );
    } finally {
      setSavingEdit(false);
    }
  };

  const openEditAttitudeModal = (a: AttitudeAssessment) => {
    setEditingAttitude(a);
    setEditAttDate(a.date);
    setEditAttAspect(a.aspect);
    setEditAttPredicate(a.predicate);
    setEditAttNotes(a.notes ?? '');
    setModalError('');
  };

  const handleSaveEditAttitude = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAttitude || !editAttAspect.trim()) {
      setModalError('Aspek penilaian sikap wajib diisi.');
      return;
    }
    setSavingEdit(true);
    setModalError('');
    try {
      await updateAttitude(editingAttitude.id, {
        date: editAttDate,
        classId: editingAttitude.classId,
        subjectId: editingAttitude.subjectId,
        studentId: editingAttitude.studentId,
        aspect: editAttAspect,
        predicate: editAttPredicate,
        notes: editAttNotes,
      });
      setEditingAttitude(null);
      setActionMessage('Penilaian sikap berhasil diperbarui.');
    } catch (err) {
      setModalError(
        err instanceof Error ? err.message : 'Gagal memperbarui penilaian sikap.'
      );
    } finally {
      setSavingEdit(false);
    }
  };

  const openEditJournalModal = (j: TeachingJournal) => {
    setEditingJournal(j);
    setEditJrnDate(j.date);
    setEditJrnHours(j.lessonHours);
    setEditJrnClassId(j.classId);
    setEditJrnSubjectId(j.subjectId);
    setEditJrnTopic(j.topic);
    setEditJrnReflection(j.reflection ?? '');

    const targetStudents = students.filter((s) => s.classId === j.classId);
    const attForJournal = attendances.filter((a) => a.journalId === j.id);
    const existingAttMap = new Map(
      attForJournal.map((a) => [a.studentId, a.status])
    );
    const nextStatuses: Record<string, AttendanceStatus> = {};
    for (const st of targetStudents) {
      nextStatuses[st.id] = existingAttMap.get(st.id) ?? 'Hadir';
    }
    setEditJrnStatuses(nextStatuses);
    setModalError('');
  };

  const editJrnStudents = useMemo(
    () => students.filter((s) => s.classId === editJrnClassId),
    [students, editJrnClassId]
  );

  const editJrnCounts = useMemo(() => {
    let h = 0;
    let s = 0;
    let i = 0;
    let a = 0;
    for (const st of editJrnStudents) {
      const val = editJrnStatuses[st.id] ?? 'Hadir';
      if (val === 'Hadir') h += 1;
      else if (val === 'Sakit') s += 1;
      else if (val === 'Izin') i += 1;
      else a += 1;
    }
    return { h, s, i, a };
  }, [editJrnStudents, editJrnStatuses]);

  const handleEditJrnClassChange = (nextClassId: string) => {
    setEditJrnClassId(nextClassId);
    const targetStudents = students.filter((s) => s.classId === nextClassId);
    const attForJournal = editingJournal
      ? attendances.filter((a) => a.journalId === editingJournal.id)
      : [];
    const existingAttMap = new Map(
      attForJournal.map((a) => [a.studentId, a.status])
    );
    const nextStatuses: Record<string, AttendanceStatus> = {};
    for (const st of targetStudents) {
      nextStatuses[st.id] = existingAttMap.get(st.id) ?? 'Hadir';
    }
    setEditJrnStatuses(nextStatuses);
  };

  const handleSaveEditJournal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !editingJournal ||
      !editJrnDate ||
      !editJrnHours.trim() ||
      !editJrnClassId ||
      !editJrnSubjectId ||
      !editJrnTopic.trim()
    ) {
      setModalError(
        'Tanggal, jam pelajaran, kelas, mata pelajaran, dan materi pokok wajib diisi.'
      );
      return;
    }
    setSavingEdit(true);
    setModalError('');
    try {
      const perStudentPayload = editJrnStudents.map((st) => ({
        studentId: st.id,
        status: editJrnStatuses[st.id] ?? 'Hadir',
      }));
      await saveJournalWithAttendance(
        {
          id: editingJournal.id,
          date: editJrnDate,
          lessonHours: editJrnHours,
          classId: editJrnClassId,
          subjectId: editJrnSubjectId,
          topic: editJrnTopic,
          presentCount:
            editJrnStudents.length > 0
              ? editJrnCounts.h
              : editingJournal.presentCount,
          sickCount:
            editJrnStudents.length > 0
              ? editJrnCounts.s
              : editingJournal.sickCount,
          permissionCount:
            editJrnStudents.length > 0
              ? editJrnCounts.i
              : editingJournal.permissionCount,
          absentCount:
            editJrnStudents.length > 0
              ? editJrnCounts.a
              : editingJournal.absentCount,
          reflection: editJrnReflection,
        },
        perStudentPayload
      );
      setEditingJournal(null);
      setActionMessage('Jurnal mengajar dan kehadiran siswa berhasil diperbarui.');
    } catch (err) {
      setModalError(
        err instanceof Error ? err.message : 'Gagal memperbarui jurnal.'
      );
    } finally {
      setSavingEdit(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setSavingEdit(true);
    try {
      if (deleteTarget.type === 'journal') {
        await deleteJournal(deleteTarget.item.id);
        setActionMessage('Jurnal mengajar berhasil dihapus.');
      } else if (deleteTarget.type === 'grade') {
        await deleteGrade(deleteTarget.item.id);
        setActionMessage('Data nilai akademik berhasil dihapus.');
      } else {
        await deleteAttitude(deleteTarget.item.id);
        setActionMessage('Data penilaian sikap berhasil dihapus.');
      }
      setDeleteTarget(null);
    } finally {
      setSavingEdit(false);
    }
  };

  // =========================================================================
  // Export Handlers (Excel & CSV)
  // =========================================================================
  const buildExportRows = (): {
    rows: Record<string, string | number>[];
    sheetName: string;
    fileName: string;
  } => {
    if (activeTab === 'harian') {
      const rows: Record<string, string | number>[] = [];

      dailyJournals.forEach((j, idx) => {
        rows.push({
          No: rows.length + 1,
          Bagian: `Jurnal KBM #${idx + 1}`,
          Tanggal: j.date,
          'Jam / Kategori / Aspek': j.lessonHours,
          Kelas: classMap.get(j.classId) ?? '-',
          'Mata Pelajaran': subjectMap.get(j.subjectId) ?? '-',
          NIS: '-',
          'Nama Siswa / Materi': j.topic,
          'Hasil / Status': `H:${j.presentCount} S:${j.sickCount} I:${j.permissionCount} A:${j.absentCount}`,
          Catatan: j.reflection || '-',
        });
      });

      dailyAttendanceRows.forEach((a) => {
        const st = studentMap.get(a.studentId);
        const jrn = journalMap.get(a.journalId);
        rows.push({
          No: rows.length + 1,
          Bagian: 'Kehadiran Siswa',
          Tanggal: a.date,
          'Jam / Kategori / Aspek': jrn?.lessonHours ?? '-',
          Kelas: classMap.get(a.classId) ?? '-',
          'Mata Pelajaran': subjectMap.get(a.subjectId) ?? '-',
          NIS: st?.nis ?? '-',
          'Nama Siswa / Materi': st?.fullName ?? '-',
          'Hasil / Status': ATTENDANCE_SHORT_LABEL[a.status],
          Catatan: a.status,
        });
      });

      dailyGrades.forEach((g) => {
        const st = studentMap.get(g.studentId);
        const catName = categoryMap.get(g.categoryId)?.name ?? '-';
        const gType = resolveGradeAssessmentType(g, catName);
        const typeLabel = gType === 'sumatif' ? 'Sumatif' : 'Formatif';
        const babTag = g.chapter
          ? ` (${g.chapter}${g.assessmentOrder ? ` · P${g.assessmentOrder}` : ''})`
          : '';
        rows.push({
          No: rows.length + 1,
          Bagian: `Nilai Akademik (${typeLabel})`,
          Tanggal: g.date,
          'Jam / Kategori / Aspek': `${catName}${babTag}`,
          Kelas: classMap.get(g.classId) ?? '-',
          'Mata Pelajaran': subjectMap.get(g.subjectId) ?? '-',
          NIS: st?.nis ?? '-',
          'Nama Siswa / Materi': st?.fullName ?? '-',
          'Hasil / Status': g.score,
          Catatan: g.notes || '-',
        });
      });

      dailyAttitudes.forEach((att) => {
        const st = studentMap.get(att.studentId);
        rows.push({
          No: rows.length + 1,
          Bagian: 'Penilaian Sikap',
          Tanggal: att.date,
          'Jam / Kategori / Aspek': att.aspect,
          Kelas: classMap.get(att.classId) ?? '-',
          'Mata Pelajaran': subjectMap.get(att.subjectId) ?? '-',
          NIS: st?.nis ?? '-',
          'Nama Siswa / Materi': st?.fullName ?? '-',
          'Hasil / Status': att.predicate,
          Catatan: att.notes || '-',
        });
      });

      return {
        rows,
        sheetName: 'Laporan Harian',
        fileName: `laporan_harian_${dateFilter}`,
      };
    }

    if (activeTab === 'akademik') {
      if (academicScope === 'harian' || academicScope === 'siswa') {
        const rows = academicDailyOrStudentEntries.map((g, i) => {
          const st = studentMap.get(g.studentId);
          const catName = categoryMap.get(g.categoryId)?.name ?? '-';
          const gType = resolveGradeAssessmentType(g, catName);
          return {
            No: i + 1,
            Tanggal: g.date,
            NIS: st?.nis ?? '-',
            'Nama Siswa': st?.fullName ?? '-',
            Kelas: classMap.get(g.classId) ?? '-',
            'Mata Pelajaran': subjectMap.get(g.subjectId) ?? '-',
            'Jenis Penilaian': gType === 'sumatif' ? 'Sumatif' : 'Formatif',
            Kategori: catName,
            Bab: g.chapter || '-',
            'Penilaian Ke': g.chapter ? g.assessmentOrder ?? 1 : '-',
            Nilai: g.score,
            Catatan: g.notes || '-',
          };
        });
        return {
          rows,
          sheetName: 'Nilai Akademik',
          fileName: `laporan_nilai_${academicScope}`,
        };
      }

      const rows = academicClassRows.map((r) => {
        const base: Record<string, string | number> = {
          No: r.no,
          NIS: r.student.nis,
          'Nama Siswa': r.student.fullName,
          Kelas: r.className,
        };
        for (const cat of academicCategories) {
          const catLabel =
            selectedSubjectId === 'ALL' && subjects.length > 1
              ? `${cat.name} [${subjectCodeMap.get(cat.subjectId) ?? 'Mapel'}] (${cat.weight}%)`
              : `${cat.name} (${cat.weight}%)`;
          base[catLabel] = r.catAverages[cat.id] ?? '-';
        }
        if (academicAssessmentFilter === 'ALL') {
          base['Rata Formatif'] = r.formatifAvg ?? '-';
          base['Rata Sumatif'] = r.sumatifAvg ?? '-';
        }
        base['Nilai Akhir'] = r.finalScore ?? '-';
        base['Keterangan'] = r.status;
        return base;
      });
      return {
        rows,
        sheetName: 'Rekap Nilai',
        fileName: `laporan_nilai_${academicScope}`,
      };
    }

    if (activeTab === 'sikap') {
      if (attitudeScope === 'harian') {
        const rows = dailyAttitudes.map((a, i) => {
          const st = studentMap.get(a.studentId);
          return {
            No: i + 1,
            Tanggal: a.date,
            NIS: st?.nis ?? '-',
            'Nama Siswa': st?.fullName ?? '-',
            Kelas: classMap.get(a.classId) ?? '-',
            'Mata Pelajaran': subjectMap.get(a.subjectId) ?? '-',
            Aspek: a.aspect,
            Predikat: a.predicate,
            Catatan: a.notes || '-',
          };
        });
        return {
          rows,
          sheetName: 'Sikap Harian',
          fileName: `laporan_sikap_harian_${dateFilter}`,
        };
      }

      const rows = attitudeReportRows.map((r) => ({
        No: r.no,
        NIS: r.student.nis,
        'Nama Siswa': r.student.fullName,
        Kelas: r.className,
        'Jumlah Catatan': r.totalRecords,
        'Sangat Baik': r.sb,
        Baik: r.b,
        Cukup: r.c,
        'Perlu Bimbingan': r.pb,
        'Predikat Dominan': r.dominant,
        'Catatan Kejadian': r.specialNotes,
      }));
      return {
        rows,
        sheetName: 'Laporan Sikap',
        fileName: `laporan_sikap_${monthFilter || 'semua'}`,
      };
    }

    if (activeTab === 'jurnal') {
      const rows = journalReportRows.map((j, i) => ({
        No: i + 1,
        Tanggal: j.date,
        'Jam Pelajaran': j.lessonHours,
        Kelas: classMap.get(j.classId) ?? '-',
        'Mata Pelajaran': subjectMap.get(j.subjectId) ?? '-',
        'Materi Pokok': j.topic,
        H: j.presentCount,
        S: j.sickCount,
        I: j.permissionCount,
        A: j.absentCount,
        Refleksi: j.reflection || '-',
      }));
      return {
        rows,
        sheetName: 'Jurnal Mengajar',
        fileName: `laporan_jurnal_${journalPeriod}`,
      };
    }

    if (attendanceScope === 'harian') {
      const rows = dailyAttendanceRows.map((a, i) => {
        const st = studentMap.get(a.studentId);
        const jrn = journalMap.get(a.journalId);
        return {
          No: i + 1,
          Tanggal: a.date,
          'Jam Pelajaran': jrn?.lessonHours ?? '-',
          NIS: st?.nis ?? '-',
          'Nama Siswa': st?.fullName ?? '-',
          Kelas: classMap.get(a.classId) ?? '-',
          'Mata Pelajaran': subjectMap.get(a.subjectId) ?? '-',
          Status: ATTENDANCE_SHORT_LABEL[a.status],
          Keterangan: a.status,
        };
      });
      return {
        rows,
        sheetName: 'Kehadiran Harian',
        fileName: `laporan_kehadiran_harian_${dateFilter}`,
      };
    }

    const rows = attendanceReportRows.map((r) => ({
      No: r.no,
      NIS: r.student.nis,
      'Nama Siswa': r.student.fullName,
      Kelas: r.className,
      'Total Pertemuan': r.total,
      Hadir: r.hadir,
      Sakit: r.sakit,
      Izin: r.izin,
      Alfa: r.alfa,
      'Persentase Kehadiran (%)': r.pct,
      'Evaluasi Kedisiplinan': r.evaluation,
    }));
    return {
      rows,
      sheetName: 'Kehadiran Siswa',
      fileName: `laporan_kehadiran_${monthFilter}`,
    };
  };

  const handleExportExcel = () => {
    const { rows, sheetName, fileName } = buildExportRows();
    if (rows.length === 0) return;
    exportToExcel(rows, sheetName, fileName);
  };

  const handleExportCsv = () => {
    const { rows, fileName } = buildExportRows();
    if (rows.length === 0) return;
    exportToCsv(rows, fileName);
  };

  const reportTitles: Record<ReportTab, string> = {
    harian: `Laporan Harian KBM & Penilaian (${getIndonesianDayName(dateFilter)}, ${formatIndonesianDate(dateFilter)})`,
    akademik:
      academicAssessmentFilter === 'formatif'
        ? 'Laporan Rekapitulasi Penilaian Formatif Siswa'
        : academicAssessmentFilter === 'sumatif'
        ? 'Laporan Rekapitulasi Penilaian Sumatif Siswa'
        : 'Laporan Rekapitulasi Nilai Akademik Siswa (Formatif & Sumatif)',
    sikap:
      attitudeScope === 'harian'
        ? `Laporan Harian Penilaian Sikap Siswa (${formatIndonesianDate(dateFilter)})`
        : 'Laporan Rekapitulasi Penilaian Sikap Siswa',
    jurnal:
      journalPeriod === 'harian'
        ? `Laporan Harian Jurnal Mengajar (${formatIndonesianDate(dateFilter)})`
        : 'Laporan Jurnal Harian Mengajar Guru',
    kehadiran:
      attendanceScope === 'harian'
        ? `Laporan Harian Kehadiran Siswa (${formatIndonesianDate(dateFilter)})`
        : 'Laporan Kehadiran & Evaluasi Kedisiplinan Siswa',
  };

  const showDateFilter =
    activeTab === 'harian' ||
    (activeTab === 'akademik' && academicScope === 'harian') ||
    (activeTab === 'sikap' && attitudeScope === 'harian') ||
    (activeTab === 'jurnal' && journalPeriod === 'harian') ||
    (activeTab === 'kehadiran' && attendanceScope === 'harian');

  const showMonthFilter =
    (activeTab === 'akademik' && academicScope === 'bulanan') ||
    (activeTab === 'sikap' && attitudeScope === 'bulanan') ||
    (activeTab === 'kehadiran' && attendanceScope === 'bulanan') ||
    (activeTab === 'jurnal' && journalPeriod === 'bulanan');

  const editGradeCategories = useMemo(() => {
    if (!editingGrade) return [];
    return categories.filter(
      (c) =>
        c.subjectId === editingGrade.subjectId &&
        (!c.classId || c.classId === editingGrade.classId)
    );
  }, [categories, editingGrade]);

  return (
    <div className="space-y-6">
      {/* Header & Export Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 no-print">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Laporan Terpadu
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Laporan harian terpadu, nilai akademik, sikap, jurnal mengajar, dan
            kehadiran siswa — lengkap dengan menu edit dan ekspor.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
            <span>Cetak Laporan</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
            <span>Ekspor CSV</span>
          </button>

          <button
            type="button"
            onClick={handleExportExcel}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 shrink-0" />
            <span>Ekspor Excel (.xlsx)</span>
          </button>
        </div>
      </div>

      {/* Action Confirmation Banner */}
      {actionMessage && (
        <div className="flex items-center justify-between gap-3 px-4 py-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-sm text-emerald-800 dark:text-emerald-200 no-print">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{actionMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setActionMessage(null)}
            className="p-1 text-emerald-700 dark:text-emerald-300 hover:opacity-75 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Report Type Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-800/80 rounded-lg w-fit no-print">
        {(
          [
            ['harian', 'Laporan Harian'],
            ['akademik', 'Nilai Akademik'],
            ['sikap', 'Penilaian Sikap'],
            ['jurnal', 'Jurnal Mengajar'],
            ['kehadiran', 'Kehadiran Siswa'],
          ] as [ReportTab, string][]
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setActiveTab(key)}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === key
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 no-print">
        {activeTab === 'akademik' && (
          <>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
                Mode Laporan
              </label>
              <select
                value={academicScope}
                onChange={(e) =>
                  setAcademicScope(e.target.value as AcademicScope)
                }
                className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              >
                <option value="kelas">Rekap Per Kelas (Terbobot)</option>
                <option value="siswa">Detail Per Siswa</option>
                <option value="harian">Laporan Harian</option>
                <option value="bulanan">Rekap Bulanan</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
                Jenis Penilaian
              </label>
              <select
                value={academicAssessmentFilter}
                onChange={(e) =>
                  setAcademicAssessmentFilter(
                    e.target.value as 'ALL' | AssessmentType
                  )
                }
                className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              >
                <option value="ALL">Semua (Formatif & Sumatif)</option>
                <option value="formatif">Penilaian Formatif</option>
                <option value="sumatif">Penilaian Sumatif</option>
              </select>
            </div>
          </>
        )}

        {activeTab === 'sikap' && (
          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
              Mode Laporan
            </label>
            <select
              value={attitudeScope}
              onChange={(e) => setAttitudeScope(e.target.value as SimpleScope)}
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            >
              <option value="bulanan">Rekap Bulanan</option>
              <option value="harian">Laporan Harian</option>
            </select>
          </div>
        )}

        {activeTab === 'kehadiran' && (
          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
              Mode Laporan
            </label>
            <select
              value={attendanceScope}
              onChange={(e) =>
                setAttendanceScope(e.target.value as SimpleScope)
              }
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            >
              <option value="bulanan">Rekap Bulanan</option>
              <option value="harian">Laporan Harian</option>
            </select>
          </div>
        )}

        {activeTab === 'jurnal' && (
          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
              Periode Laporan
            </label>
            <select
              value={journalPeriod}
              onChange={(e) =>
                setJournalPeriod(e.target.value as JournalPeriodType)
              }
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            >
              <option value="harian">Laporan Harian</option>
              <option value="bulanan">Per Bulan</option>
              <option value="ganjil">Semester Ganjil (Jul - Des)</option>
              <option value="genap">Semester Genap (Jan - Jun)</option>
              <option value="semua">Semua Periode</option>
            </select>
          </div>
        )}

        {showDateFilter && (
          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
              Tanggal Laporan
            </label>
            <div className="flex items-center gap-1.5">
              <input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
              {dateFilter !== getTodayIso() && (
                <button
                  type="button"
                  onClick={() => setDateFilter(getTodayIso())}
                  className="px-2.5 py-2 text-xs font-medium text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Hari Ini
                </button>
              )}
            </div>
          </div>
        )}

        {showMonthFilter && (
          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
              Bulan
            </label>
            <input
              type="month"
              value={monthFilter}
              onChange={(e) => setMonthFilter(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
          </div>
        )}

        <div>
          <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
            Kelas
          </label>
          <select
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
            className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
          >
            <option value="ALL">Semua Kelas</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.academicYear})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
            Mata Pelajaran
          </label>
          <select
            value={selectedSubjectId}
            onChange={(e) => setSelectedSubjectId(e.target.value)}
            className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
          >
            <option value="ALL">Semua Mapel</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code} · {s.name}
              </option>
            ))}
          </select>
        </div>

        {activeTab === 'akademik' && academicScope === 'siswa' && (
          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
              Pilih Siswa
            </label>
            <select
              value={selectedStudentId}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            >
              {academicClassStudents.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.nis} · {st.fullName}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Printable Report Canvas */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 print-container print:bg-white print:text-slate-900">
        {/* Official Print Header */}
        <div className="hidden print-only border-b-2 border-slate-900 pb-4 mb-6">
          <div className="flex items-center gap-4 mb-3">
            <div className="w-14 h-14 rounded-lg shrink-0 overflow-hidden">
              <SchoolLogo className="w-full h-full object-contain" />
            </div>
            <div>
              <p className="font-display text-base font-bold uppercase tracking-wide text-slate-900">
                Sekolah Menengah Pertama Zainul Hasan (SMP ZAHA)
              </p>
              <p className="text-xs text-slate-700">
                Genggong, Probolinggo — Jawa Timur
              </p>
            </div>
          </div>
          <h2 className="font-display text-lg font-bold text-slate-900 pt-2 border-t border-slate-300">
            {reportTitles[activeTab]}
          </h2>
          <div className="mt-1.5 flex flex-wrap items-center gap-4 text-xs text-slate-700">
            <span>Guru: {user?.displayName || user?.email}</span>
            <span>·</span>
            <span>
              Kelas:{' '}
              {selectedClassId === 'ALL'
                ? 'Semua Kelas'
                : classMap.get(selectedClassId) ?? '-'}
            </span>
            <span>·</span>
            <span>Tanggal Cetak: {formatIndonesianDate(getTodayIso())}</span>
          </div>
        </div>

        {/* =============================================================== */}
        {/* TAB 1: LAPORAN HARIAN TERPADU                                   */}
        {/* =============================================================== */}
        {activeTab === 'harian' && (
          <div className="space-y-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <CalendarDays className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" />
                <div>
                  <h2 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
                    Rekap Harian — {getIndonesianDayName(dateFilter)},{' '}
                    {formatIndonesianDate(dateFilter)}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Seluruh aktivitas KBM, kehadiran siswa, nilai akademik, dan
                    penilaian sikap pada tanggal terpilih.
                  </p>
                </div>
              </div>
            </div>

            {/* Summary KPI Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60">
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span>Jurnal Mengajar</span>
                  <BookOpen className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                </div>
                <p className="font-mono text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1 tabular-nums">
                  {dailyJournals.length}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Sesi KBM tercatat
                </p>
              </div>

              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60">
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span>Rekap H / S / I / A</span>
                  <Users className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                </div>
                <p className="font-mono text-lg font-bold text-slate-900 dark:text-slate-100 mt-1.5 tabular-nums">
                  {dailyAttendanceSummary.h} / {dailyAttendanceSummary.s} /{' '}
                  {dailyAttendanceSummary.i} / {dailyAttendanceSummary.a}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  Total kehadiran harian
                </p>
              </div>

              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60">
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span>Nilai Akademik</span>
                  <GraduationCap className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                </div>
                <p className="font-mono text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1 tabular-nums">
                  {dailyGrades.length}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Entri nilai siswa
                </p>
              </div>

              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60">
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span>Penilaian Sikap</span>
                  <ClipboardCheck className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                </div>
                <p className="font-mono text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1 tabular-nums">
                  {dailyAttitudes.length}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Catatan observasi sikap
                </p>
              </div>
            </div>

            {/* Section A: Jurnal Harian Mengajar */}
            <div className="space-y-3">
              <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                1. Jurnal Harian Mengajar ({dailyJournals.length})
              </h3>
              {dailyJournals.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400 py-4 px-4 rounded-lg border border-dashed border-slate-200 dark:border-slate-800">
                  Belum ada jurnal mengajar pada tanggal ini.
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                        <th className="py-2.5 px-3 w-10">No</th>
                        <th className="py-2.5 px-3">Jam Pelajaran</th>
                        <th className="py-2.5 px-3">Kelas · Mapel</th>
                        <th className="py-2.5 px-3">Materi Pokok</th>
                        <th className="py-2.5 px-3 text-right">H / S / I / A</th>
                        <th className="py-2.5 px-3">Refleksi</th>
                        <th className="py-2.5 px-3 text-right no-print">
                          Aksi
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {dailyJournals.map((j, idx) => (
                        <tr key={j.id}>
                          <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400 align-top">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-3 text-xs font-mono text-slate-700 dark:text-slate-300 align-top whitespace-nowrap">
                            {j.lessonHours}
                          </td>
                          <td className="py-2.5 px-3 text-xs align-top">
                            <p className="font-medium text-slate-900 dark:text-slate-100">
                              {classMap.get(j.classId) ?? '-'}
                            </p>
                            <p className="text-slate-600 dark:text-slate-300">
                              {subjectMap.get(j.subjectId) ?? '-'}
                            </p>
                          </td>
                          <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-slate-100 align-top">
                            {j.topic}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300 align-top whitespace-nowrap">
                            {j.presentCount} / {j.sickCount} /{' '}
                            {j.permissionCount} / {j.absentCount}
                          </td>
                          <td className="py-2.5 px-3 text-xs text-slate-600 dark:text-slate-300 align-top max-w-xs">
                            {j.reflection || '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right align-top whitespace-nowrap no-print">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => openEditJournalModal(j)}
                                title="Edit Jurnal & Kehadiran"
                                className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded transition-colors cursor-pointer"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                                <span>Edit</span>
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  setDeleteTarget({ type: 'journal', item: j })
                                }
                                title="Hapus Jurnal"
                                className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/60 rounded transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Section B: Kehadiran Siswa Harian */}
            <div className="space-y-3">
              <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                2. Detail Kehadiran Siswa Harian ({dailyAttendanceRows.length})
              </h3>
              {dailyAttendanceRows.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400 py-4 px-4 rounded-lg border border-dashed border-slate-200 dark:border-slate-800">
                  Belum ada catatan kehadiran siswa per individu pada tanggal ini.
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                        <th className="py-2.5 px-3 w-10">No</th>
                        <th className="py-2.5 px-3">NIS</th>
                        <th className="py-2.5 px-3">Nama Siswa</th>
                        <th className="py-2.5 px-3">Kelas · Mapel</th>
                        <th className="py-2.5 px-3">Jam Sesi</th>
                        <th className="py-2.5 px-3 text-center">Status (H/S/I/A)</th>
                        <th className="py-2.5 px-3 text-right no-print">
                          Aksi
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {dailyAttendanceRows.map((att, idx) => {
                        const st = studentMap.get(att.studentId);
                        const jrn = journalMap.get(att.journalId);
                        return (
                          <tr key={att.id}>
                            <td className="py-2 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                              {idx + 1}
                            </td>
                            <td className="py-2 px-3 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                              {st?.nis ?? '-'}
                            </td>
                            <td className="py-2 px-3 font-medium text-slate-900 dark:text-slate-100">
                              {st?.fullName ?? '-'}
                            </td>
                            <td className="py-2 px-3 text-xs text-slate-600 dark:text-slate-300">
                              {classMap.get(att.classId) ?? '-'} ·{' '}
                              {subjectMap.get(att.subjectId) ?? '-'}
                            </td>
                            <td className="py-2 px-3 font-mono text-xs text-slate-600 dark:text-slate-400">
                              {jrn?.lessonHours ?? '-'}
                            </td>
                            <td className="py-2 px-3 text-center">
                              <span
                                className={`inline-flex items-center justify-center min-w-[2rem] px-2 py-0.5 text-xs font-semibold border rounded ${ATTENDANCE_BADGE_CLASS[att.status]}`}
                              >
                                {ATTENDANCE_SHORT_LABEL[att.status]}
                              </span>
                            </td>
                            <td className="py-2 px-3 text-right no-print">
                              {jrn && (
                                <button
                                  type="button"
                                  onClick={() => openEditJournalModal(jrn)}
                                  className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded transition-colors cursor-pointer"
                                >
                                  <Pencil className="w-3.5 h-3.5" />
                                  <span>Edit Sesi</span>
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Section C: Nilai Akademik Harian */}
            <div className="space-y-3">
              <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                3. Nilai Akademik Harian ({dailyGrades.length})
              </h3>
              {dailyGrades.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400 py-4 px-4 rounded-lg border border-dashed border-slate-200 dark:border-slate-800">
                  Belum ada nilai akademik yang dicatat pada tanggal ini.
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                        <th className="py-2.5 px-3 w-10">No</th>
                        <th className="py-2.5 px-3">NIS</th>
                        <th className="py-2.5 px-3">Nama Siswa</th>
                        <th className="py-2.5 px-3">Kelas · Mapel</th>
                        <th className="py-2.5 px-3">Kategori</th>
                        <th className="py-2.5 px-3 text-right">Nilai</th>
                        <th className="py-2.5 px-3">Catatan</th>
                        <th className="py-2.5 px-3 text-right no-print">
                          Aksi
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {dailyGrades.map((g, idx) => {
                        const st = studentMap.get(g.studentId);
                        const catName = categoryMap.get(g.categoryId)?.name ?? '-';
                        const gType = resolveGradeAssessmentType(g, catName);
                        return (
                          <tr key={g.id}>
                            <td className="py-2 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                              {idx + 1}
                            </td>
                            <td className="py-2 px-3 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                              {st?.nis ?? '-'}
                            </td>
                            <td className="py-2 px-3 font-medium text-slate-900 dark:text-slate-100">
                              {st?.fullName ?? '-'}
                            </td>
                            <td className="py-2 px-3 text-xs text-slate-600 dark:text-slate-300">
                              {classMap.get(g.classId) ?? '-'} ·{' '}
                              {subjectMap.get(g.subjectId) ?? '-'}
                            </td>
                            <td className="py-2 px-3 text-xs text-slate-600 dark:text-slate-300">
                              <span
                                className={`inline-flex items-center px-1.5 py-0.5 mr-1.5 text-[10px] font-medium rounded border ${
                                  gType === 'sumatif'
                                    ? 'bg-indigo-50 dark:bg-indigo-950/50 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300'
                                    : 'bg-blue-50 dark:bg-blue-950/50 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300'
                                }`}
                              >
                                {gType === 'sumatif' ? 'Sumatif' : 'Formatif'}
                              </span>
                              <span>{catName}</span>
                              {g.chapter && (
                                <span className="ml-1.5 text-blue-700 dark:text-blue-400 font-medium">
                                  · {g.chapter}
                                  {g.assessmentOrder
                                    ? ` (P${g.assessmentOrder})`
                                    : ''}
                                </span>
                              )}
                            </td>
                            <td className="py-2 px-3 text-right font-mono font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                              {g.score}
                            </td>
                            <td className="py-2 px-3 text-xs text-slate-600 dark:text-slate-300">
                              {g.notes || '-'}
                            </td>
                            <td className="py-2 px-3 text-right whitespace-nowrap no-print">
                              <div className="inline-flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => openEditGradeModal(g)}
                                  className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded transition-colors cursor-pointer"
                                >
                                  <Pencil className="w-3.5 h-3.5" />
                                  <span>Edit</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setDeleteTarget({ type: 'grade', item: g })
                                  }
                                  className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/60 rounded transition-colors cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Section D: Penilaian Sikap Harian */}
            <div className="space-y-3">
              <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                4. Penilaian Sikap Harian ({dailyAttitudes.length})
              </h3>
              {dailyAttitudes.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400 py-4 px-4 rounded-lg border border-dashed border-slate-200 dark:border-slate-800">
                  Belum ada penilaian sikap yang dicatat pada tanggal ini.
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                        <th className="py-2.5 px-3 w-10">No</th>
                        <th className="py-2.5 px-3">NIS</th>
                        <th className="py-2.5 px-3">Nama Siswa</th>
                        <th className="py-2.5 px-3">Kelas · Mapel</th>
                        <th className="py-2.5 px-3">Aspek</th>
                        <th className="py-2.5 px-3">Predikat</th>
                        <th className="py-2.5 px-3">Catatan</th>
                        <th className="py-2.5 px-3 text-right no-print">
                          Aksi
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {dailyAttitudes.map((a, idx) => {
                        const st = studentMap.get(a.studentId);
                        return (
                          <tr key={a.id}>
                            <td className="py-2 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                              {idx + 1}
                            </td>
                            <td className="py-2 px-3 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                              {st?.nis ?? '-'}
                            </td>
                            <td className="py-2 px-3 font-medium text-slate-900 dark:text-slate-100">
                              {st?.fullName ?? '-'}
                            </td>
                            <td className="py-2 px-3 text-xs text-slate-600 dark:text-slate-300">
                              {classMap.get(a.classId) ?? '-'} ·{' '}
                              {subjectMap.get(a.subjectId) ?? '-'}
                            </td>
                            <td className="py-2 px-3 text-xs text-slate-700 dark:text-slate-300">
                              {a.aspect}
                            </td>
                            <td className="py-2 px-3 text-xs font-semibold text-slate-900 dark:text-slate-100">
                              {a.predicate}
                            </td>
                            <td className="py-2 px-3 text-xs text-slate-600 dark:text-slate-300 max-w-xs">
                              {a.notes || '-'}
                            </td>
                            <td className="py-2 px-3 text-right whitespace-nowrap no-print">
                              <div className="inline-flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => openEditAttitudeModal(a)}
                                  className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded transition-colors cursor-pointer"
                                >
                                  <Pencil className="w-3.5 h-3.5" />
                                  <span>Edit</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setDeleteTarget({
                                      type: 'attitude',
                                      item: a,
                                    })
                                  }
                                  className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/60 rounded transition-colors cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* =============================================================== */}
        {/* TAB 2: ACADEMIC TABLE                                           */}
        {/* =============================================================== */}
        {activeTab === 'akademik' && (
          <div className="overflow-x-auto">
            {academicScope === 'harian' || academicScope === 'siswa' ? (
              academicDailyOrStudentEntries.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-400 py-8 text-center">
                  Tidak ada data nilai akademik untuk kriteria yang dipilih.
                </p>
              ) : (
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                      <th className="py-3 px-3 w-12">No</th>
                      <th className="py-3 px-3">Tanggal</th>
                      <th className="py-3 px-3">NIS</th>
                      <th className="py-3 px-3">Nama Siswa</th>
                      <th className="py-3 px-3">Mapel</th>
                      <th className="py-3 px-3">Jenis</th>
                      <th className="py-3 px-3">Kategori</th>
                      <th className="py-3 px-3 text-right">Nilai</th>
                      <th className="py-3 px-3">Catatan</th>
                      <th className="py-3 px-3 text-right no-print">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {academicDailyOrStudentEntries.map((g, idx) => {
                      const st = studentMap.get(g.studentId);
                      const catName = categoryMap.get(g.categoryId)?.name ?? '-';
                      const gType = resolveGradeAssessmentType(g, catName);
                      return (
                        <tr key={g.id}>
                          <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                            {formatIndonesianDate(g.date)}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                            {st?.nis ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-slate-100">
                            {st?.fullName ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                            {subjectMap.get(g.subjectId) ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 text-[11px] font-medium rounded-md border ${
                                gType === 'sumatif'
                                  ? 'bg-indigo-50 dark:bg-indigo-950/50 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300'
                                  : 'bg-blue-50 dark:bg-blue-950/50 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300'
                              }`}
                            >
                              {gType === 'sumatif' ? 'Sumatif' : 'Formatif'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                            <span>{catName}</span>
                            {g.chapter && (
                              <span className="ml-1.5 text-xs text-blue-700 dark:text-blue-400 font-medium">
                                · {g.chapter}
                                {g.assessmentOrder
                                  ? ` (P${g.assessmentOrder})`
                                  : ''}
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                            {g.score}
                          </td>
                          <td className="py-2.5 px-3 text-xs text-slate-600 dark:text-slate-300">
                            {g.notes || '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right whitespace-nowrap no-print">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => openEditGradeModal(g)}
                                className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded transition-colors cursor-pointer"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                                <span>Edit</span>
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  setDeleteTarget({ type: 'grade', item: g })
                                }
                                className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/60 rounded transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )
            ) : academicClassRows.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400 py-8 text-center">
                Belum ada data siswa untuk kelas yang dipilih.
              </p>
            ) : (
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <th className="py-3 px-3 w-12">No</th>
                    <th className="py-3 px-3 w-28">NIS</th>
                    <th className="py-3 px-3">Nama Siswa</th>
                    <th className="py-3 px-3">Kelas</th>
                    {academicCategories.map((cat) => (
                      <th key={cat.id} className="py-3 px-3 text-right">
                        {cat.name}
                        {selectedSubjectId === 'ALL' && subjects.length > 1
                          ? ` [${subjectCodeMap.get(cat.subjectId) ?? 'Mapel'}]`
                          : ''}{' '}
                        ({cat.weight}%)
                      </th>
                    ))}
                    {academicAssessmentFilter === 'ALL' && (
                      <>
                        <th className="py-3 px-3 text-right text-blue-700 dark:text-blue-400">
                          Formatif
                        </th>
                        <th className="py-3 px-3 text-right text-indigo-700 dark:text-indigo-400">
                          Sumatif
                        </th>
                      </>
                    )}
                    <th className="py-3 px-3 text-right">Nilai Akhir</th>
                    <th className="py-3 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {academicClassRows.map((row) => (
                    <tr key={row.student.id}>
                      <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                        {row.no}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                        {row.student.nis}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-slate-100">
                        {row.student.fullName}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                        {row.className}
                      </td>
                      {academicCategories.map((cat) => (
                        <td
                          key={cat.id}
                          className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300"
                        >
                          {row.catAverages[cat.id] ?? '-'}
                        </td>
                      ))}
                      {academicAssessmentFilter === 'ALL' && (
                        <>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-blue-700 dark:text-blue-400">
                            {row.formatifAvg ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-indigo-700 dark:text-indigo-400">
                            {row.sumatifAvg ?? '-'}
                          </td>
                        </>
                      )}
                      <td className="py-2.5 px-3 text-right font-mono font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                        {row.finalScore ?? '-'}
                      </td>
                      <td className="py-2.5 px-3 text-xs font-medium">
                        <span
                          className={
                            row.status === 'Tuntas'
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : row.status === 'Perlu Remedial'
                              ? 'text-red-700 dark:text-red-400'
                              : 'text-slate-500 dark:text-slate-400'
                          }
                        >
                          {row.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}

        {/* =============================================================== */}
        {/* TAB 3: ATTITUDE TABLE (Bulanan & Harian + Edit)                 */}
        {/* =============================================================== */}
        {activeTab === 'sikap' && (
          <div className="overflow-x-auto">
            {attitudeScope === 'harian' ? (
              dailyAttitudes.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-400 py-8 text-center">
                  Tidak ada catatan penilaian sikap pada tanggal{' '}
                  {formatIndonesianDate(dateFilter)}.
                </p>
              ) : (
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                      <th className="py-3 px-3 w-12">No</th>
                      <th className="py-3 px-3">NIS</th>
                      <th className="py-3 px-3">Nama Siswa</th>
                      <th className="py-3 px-3">Kelas · Mapel</th>
                      <th className="py-3 px-3">Aspek</th>
                      <th className="py-3 px-3">Predikat</th>
                      <th className="py-3 px-3">Catatan</th>
                      <th className="py-3 px-3 text-right no-print">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {dailyAttitudes.map((a, idx) => {
                      const st = studentMap.get(a.studentId);
                      return (
                        <tr key={a.id}>
                          <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                            {st?.nis ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-slate-100">
                            {st?.fullName ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 text-xs text-slate-600 dark:text-slate-300">
                            {classMap.get(a.classId) ?? '-'} ·{' '}
                            {subjectMap.get(a.subjectId) ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 text-xs text-slate-700 dark:text-slate-300">
                            {a.aspect}
                          </td>
                          <td className="py-2.5 px-3 text-xs font-semibold text-slate-900 dark:text-slate-100">
                            {a.predicate}
                          </td>
                          <td className="py-2.5 px-3 text-xs text-slate-600 dark:text-slate-300 max-w-xs">
                            {a.notes || '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right whitespace-nowrap no-print">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => openEditAttitudeModal(a)}
                                className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded transition-colors cursor-pointer"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                                <span>Edit</span>
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  setDeleteTarget({ type: 'attitude', item: a })
                                }
                                className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/60 rounded transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )
            ) : attitudeReportRows.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400 py-8 text-center">
                Belum ada data siswa pada kelas yang dipilih.
              </p>
            ) : (
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <th className="py-3 px-3 w-12">No</th>
                    <th className="py-3 px-3">Nama Siswa</th>
                    <th className="py-3 px-3">Kelas</th>
                    <th className="py-3 px-3 text-right">SB</th>
                    <th className="py-3 px-3 text-right">B</th>
                    <th className="py-3 px-3 text-right">C</th>
                    <th className="py-3 px-3 text-right">PB</th>
                    <th className="py-3 px-3">Predikat Dominan</th>
                    <th className="py-3 px-3">Catatan Kejadian Khusus</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {attitudeReportRows.map((row) => (
                    <tr key={row.student.id}>
                      <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                        {row.no}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-slate-100">
                        {row.student.fullName}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                        {row.className}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                        {row.sb}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-blue-700 dark:text-blue-400">
                        {row.b}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-amber-700 dark:text-amber-400">
                        {row.c}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-red-700 dark:text-red-400">
                        {row.pb}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-800 dark:text-slate-200">
                        {row.dominant}
                      </td>
                      <td className="py-2.5 px-3 text-xs text-slate-600 dark:text-slate-300 max-w-xs">
                        {row.specialNotes}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}

        {/* =============================================================== */}
        {/* TAB 4: TEACHING JOURNAL TABLE (Harian/Periode + Edit)           */}
        {/* =============================================================== */}
        {activeTab === 'jurnal' && (
          <div className="overflow-x-auto">
            {journalReportRows.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400 py-8 text-center">
                Tidak ada jurnal mengajar pada periode dan kelas yang dipilih.
              </p>
            ) : (
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <th className="py-3 px-3 w-12">No</th>
                    <th className="py-3 px-3">Tanggal & Jam</th>
                    <th className="py-3 px-3">Kelas · Mapel</th>
                    <th className="py-3 px-3">Materi Pokok</th>
                    <th className="py-3 px-3 text-right">H / S / I / A</th>
                    <th className="py-3 px-3">Refleksi</th>
                    <th className="py-3 px-3 text-right no-print">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {journalReportRows.map((j, idx) => (
                    <tr key={j.id}>
                      <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400 align-top">
                        {idx + 1}
                      </td>
                      <td className="py-2.5 px-3 align-top whitespace-nowrap">
                        <p className="font-mono text-xs text-slate-800 dark:text-slate-200 tabular-nums">
                          {formatIndonesianDate(j.date)}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {j.lessonHours}
                        </p>
                      </td>
                      <td className="py-2.5 px-3 align-top text-xs">
                        <p className="font-medium text-slate-900 dark:text-slate-100">
                          {classMap.get(j.classId) ?? '-'}
                        </p>
                        <p className="text-slate-600 dark:text-slate-300">
                          {subjectMap.get(j.subjectId) ?? '-'}
                        </p>
                      </td>
                      <td className="py-2.5 px-3 align-top font-medium text-slate-900 dark:text-slate-100">
                        {j.topic}
                      </td>
                      <td className="py-2.5 px-3 align-top text-right font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300 whitespace-nowrap">
                        {j.presentCount} / {j.sickCount} / {j.permissionCount} /{' '}
                        {j.absentCount}
                      </td>
                      <td className="py-2.5 px-3 align-top text-xs text-slate-600 dark:text-slate-300 max-w-xs">
                        {j.reflection || '-'}
                      </td>
                      <td className="py-2.5 px-3 align-top text-right whitespace-nowrap no-print">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openEditJournalModal(j)}
                            className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded transition-colors cursor-pointer"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                            <span>Edit</span>
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setDeleteTarget({ type: 'journal', item: j })
                            }
                            className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/60 rounded transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}

        {/* =============================================================== */}
        {/* TAB 5: ATTENDANCE TABLE (Bulanan & Harian + Edit)               */}
        {/* =============================================================== */}
        {activeTab === 'kehadiran' && (
          <div className="overflow-x-auto">
            {attendanceScope === 'harian' ? (
              dailyAttendanceRows.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-400 py-8 text-center">
                  Belum ada catatan kehadiran siswa pada tanggal{' '}
                  {formatIndonesianDate(dateFilter)}.
                </p>
              ) : (
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                      <th className="py-3 px-3 w-12">No</th>
                      <th className="py-3 px-3 w-28">NIS</th>
                      <th className="py-3 px-3">Nama Siswa</th>
                      <th className="py-3 px-3">Kelas · Mapel</th>
                      <th className="py-3 px-3">Jam Sesi</th>
                      <th className="py-3 px-3 text-center">Status (H/S/I/A)</th>
                      <th className="py-3 px-3 text-right no-print">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {dailyAttendanceRows.map((att, idx) => {
                      const st = studentMap.get(att.studentId);
                      const jrn = journalMap.get(att.journalId);
                      return (
                        <tr key={att.id}>
                          <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                            {st?.nis ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-slate-100">
                            {st?.fullName ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 text-xs text-slate-600 dark:text-slate-300">
                            {classMap.get(att.classId) ?? '-'} ·{' '}
                            {subjectMap.get(att.subjectId) ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-xs text-slate-600 dark:text-slate-400">
                            {jrn?.lessonHours ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <span
                              className={`inline-flex items-center justify-center min-w-[2rem] px-2 py-0.5 text-xs font-semibold border rounded ${ATTENDANCE_BADGE_CLASS[att.status]}`}
                            >
                              {ATTENDANCE_SHORT_LABEL[att.status]}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right no-print">
                            {jrn && (
                              <button
                                type="button"
                                onClick={() => openEditJournalModal(jrn)}
                                className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded transition-colors cursor-pointer"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                                <span>Edit</span>
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )
            ) : attendanceReportRows.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400 py-8 text-center">
                Belum ada siswa untuk ditampilkan pada laporan kehadiran.
              </p>
            ) : (
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <th className="py-3 px-3 w-12">No</th>
                    <th className="py-3 px-3 w-28">NIS</th>
                    <th className="py-3 px-3">Nama Siswa</th>
                    <th className="py-3 px-3">Kelas</th>
                    <th className="py-3 px-3 text-right">Pertemuan</th>
                    <th className="py-3 px-3 text-right">H</th>
                    <th className="py-3 px-3 text-right">S</th>
                    <th className="py-3 px-3 text-right">I</th>
                    <th className="py-3 px-3 text-right">A</th>
                    <th className="py-3 px-3 text-right">Kehadiran</th>
                    <th className="py-3 px-3">Evaluasi Kedisiplinan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {attendanceReportRows.map((row) => (
                    <tr key={row.student.id}>
                      <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                        {row.no}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                        {row.student.nis}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-slate-100">
                        {row.student.fullName}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                        {row.className}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                        {row.total}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                        {row.hadir}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-amber-700 dark:text-amber-400">
                        {row.sakit}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-blue-700 dark:text-blue-400">
                        {row.izin}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-red-700 dark:text-red-400">
                        {row.alfa}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                        {row.pct}%
                      </td>
                      <td className="py-2.5 px-3 text-xs font-medium">
                        <span
                          className={
                            row.evaluation === 'Disiplin Baik'
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : row.evaluation === 'Perlu Pemantauan'
                              ? 'text-amber-700 dark:text-amber-400'
                              : row.evaluation === 'Peringatan Kedisiplinan'
                              ? 'text-red-700 dark:text-red-400'
                              : 'text-slate-500 dark:text-slate-400'
                          }
                        >
                          {row.evaluation}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}

        {/* Official Print Signature Footer */}
        <div className="hidden print-only mt-12 pt-6">
          <div className="flex justify-end">
            <div className="text-xs text-slate-800 w-64">
              <p>Mengetahui, {formatIndonesianDate(getTodayIso())}</p>
              <p className="mt-1">Guru Mata Pelajaran</p>
              <div className="h-16" />
              <p className="font-semibold underline">
                {user?.displayName || 'Guru Pengajar'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* ================================================================= */}
      {/* MODAL: EDIT NILAI AKADEMIK                                        */}
      {/* ================================================================= */}
      {editingGrade && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 no-print">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
                Edit Nilai Akademik
              </h2>
              <button
                type="button"
                onClick={() => setEditingGrade(null)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditGrade} className="space-y-4">
              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                <p className="font-semibold text-slate-900 dark:text-slate-100">
                  {studentMap.get(editingGrade.studentId)?.fullName ?? '-'}
                </p>
                <p className="text-slate-500 dark:text-slate-400">
                  {classMap.get(editingGrade.classId) ?? '-'} ·{' '}
                  {subjectMap.get(editingGrade.subjectId) ?? '-'}
                </p>
              </div>

              {modalError && (
                <p className="text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 px-3 py-2 rounded-lg">
                  {modalError}
                </p>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Jenis Penilaian
                </label>
                <select
                  value={editGradeAssessmentType}
                  onChange={(e) =>
                    setEditGradeAssessmentType(e.target.value as AssessmentType)
                  }
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                >
                  <option value="formatif">Penilaian Formatif</option>
                  <option value="sumatif">Penilaian Sumatif</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    required
                    value={editGradeDate}
                    onChange={(e) => setEditGradeDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Nilai (0 - 100)
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    max={100}
                    step="0.1"
                    value={editGradeScore}
                    onChange={(e) => setEditGradeScore(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                </div>
              </div>

              {editGradeCategories.length > 0 && (
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Kategori Penilaian
                  </label>
                  <select
                    value={editGradeCategoryId}
                    onChange={(e) => setEditGradeCategoryId(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    {editGradeCategories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.weight}%)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Bab / Materi (Opsional)
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.GRADE_CHAPTER}
                    value={editGradeChapter}
                    onChange={(e) => setEditGradeChapter(e.target.value)}
                    placeholder="Contoh: Bab 1"
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Penilaian Ke
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    disabled={!editGradeChapter.trim()}
                    value={editGradeOrder}
                    onChange={(e) => setEditGradeOrder(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg disabled:opacity-50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Catatan
                </label>
                <textarea
                  rows={2}
                  maxLength={FIELD_LIMITS.GRADE_NOTES}
                  value={editGradeNotes}
                  onChange={(e) => setEditGradeNotes(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingGrade(null)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={savingEdit}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg disabled:opacity-50 cursor-pointer"
                >
                  {savingEdit ? 'Menyimpan...' : 'Simpan Perubahan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL: EDIT PENILAIAN SIKAP                                       */}
      {/* ================================================================= */}
      {editingAttitude && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 no-print">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
                Edit Penilaian Sikap
              </h2>
              <button
                type="button"
                onClick={() => setEditingAttitude(null)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditAttitude} className="space-y-4">
              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                <p className="font-semibold text-slate-900 dark:text-slate-100">
                  {studentMap.get(editingAttitude.studentId)?.fullName ?? '-'}
                </p>
                <p className="text-slate-500 dark:text-slate-400">
                  {classMap.get(editingAttitude.classId) ?? '-'} ·{' '}
                  {subjectMap.get(editingAttitude.subjectId) ?? '-'}
                </p>
              </div>

              {modalError && (
                <p className="text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 px-3 py-2 rounded-lg">
                  {modalError}
                </p>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    required
                    value={editAttDate}
                    onChange={(e) => setEditAttDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Predikat
                  </label>
                  <select
                    value={editAttPredicate}
                    onChange={(e) =>
                      setEditAttPredicate(e.target.value as AttitudePredicate)
                    }
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    {ATTITUDE_PREDICATES.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Aspek Sikap
                </label>
                <input
                  type="text"
                  required
                  list="laporan-attitude-aspects"
                  maxLength={FIELD_LIMITS.ATTITUDE_ASPECT}
                  value={editAttAspect}
                  onChange={(e) => setEditAttAspect(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
                <datalist id="laporan-attitude-aspects">
                  {ATTITUDE_ASPECTS.map((asp) => (
                    <option key={asp} value={asp} />
                  ))}
                </datalist>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Catatan Observasi
                </label>
                <textarea
                  rows={3}
                  maxLength={FIELD_LIMITS.ATTITUDE_NOTES}
                  value={editAttNotes}
                  onChange={(e) => setEditAttNotes(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingAttitude(null)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={savingEdit}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg disabled:opacity-50 cursor-pointer"
                >
                  {savingEdit ? 'Menyimpan...' : 'Simpan Perubahan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL: EDIT JURNAL MENGAJAR & KEHADIRAN SISWA                     */}
      {/* ================================================================= */}
      {editingJournal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 no-print">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
                Edit Jurnal Mengajar & Kehadiran Siswa
              </h2>
              <button
                type="button"
                onClick={() => setEditingJournal(null)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditJournal} className="space-y-4">
              {modalError && (
                <p className="text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 px-3 py-2 rounded-lg">
                  {modalError}
                </p>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    required
                    value={editJrnDate}
                    onChange={(e) => setEditJrnDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Jam Pelajaran
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={FIELD_LIMITS.LESSON_HOURS}
                    value={editJrnHours}
                    onChange={(e) => setEditJrnHours(e.target.value)}
                    placeholder="Contoh: Jam ke-1 - Jam ke-2 (07:00 - 08:30)"
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Kelas
                  </label>
                  <select
                    value={editJrnClassId}
                    onChange={(e) => handleEditJrnClassChange(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.academicYear})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Mata Pelajaran
                  </label>
                  <select
                    value={editJrnSubjectId}
                    onChange={(e) => setEditJrnSubjectId(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.code} · {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Materi Pokok / Topik Pembelajaran
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.JOURNAL_TOPIC}
                  value={editJrnTopic}
                  onChange={(e) => setEditJrnTopic(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>

              {/* Kehadiran Siswa H, S, I, A */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-lg p-3.5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Rekap Kehadiran Siswa
                  </span>
                  <div className="flex items-center gap-3 text-xs font-mono tabular-nums">
                    <span className="text-emerald-700 dark:text-emerald-400">
                      H: {editJrnCounts.h}
                    </span>
                    <span className="text-amber-700 dark:text-amber-400">
                      S: {editJrnCounts.s}
                    </span>
                    <span className="text-blue-700 dark:text-blue-400">
                      I: {editJrnCounts.i}
                    </span>
                    <span className="text-red-700 dark:text-red-400">
                      A: {editJrnCounts.a}
                    </span>
                  </div>
                </div>

                {editJrnStudents.length === 0 ? (
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Belum ada daftar siswa di kelas ini.
                  </p>
                ) : (
                  <div className="max-h-56 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                    {editJrnStudents.map((st, idx) => {
                      const currentStatus = editJrnStatuses[st.id] ?? 'Hadir';
                      return (
                        <div
                          key={st.id}
                          className="py-2 flex items-center justify-between gap-3"
                        >
                          <div className="min-w-0">
                            <p className="text-xs font-medium text-slate-900 dark:text-slate-100 truncate">
                              {idx + 1}. {st.fullName}
                            </p>
                            <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                              {st.nis}
                            </p>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            {ATTENDANCE_STATUSES.map((statusOpt) => {
                              const active = currentStatus === statusOpt;
                              return (
                                <button
                                  key={statusOpt}
                                  type="button"
                                  onClick={() =>
                                    setEditJrnStatuses((prev) => ({
                                      ...prev,
                                      [st.id]: statusOpt,
                                    }))
                                  }
                                  className={`w-8 h-7 text-xs font-semibold rounded border transition-colors cursor-pointer ${
                                    active
                                      ? ATTENDANCE_BADGE_CLASS[statusOpt]
                                      : 'bg-white dark:bg-slate-950 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                                  }`}
                                >
                                  {ATTENDANCE_SHORT_LABEL[statusOpt]}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Catatan / Refleksi Pembelajaran
                </label>
                <textarea
                  rows={3}
                  maxLength={FIELD_LIMITS.JOURNAL_REFLECTION}
                  value={editJrnReflection}
                  onChange={(e) => setEditJrnReflection(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingJournal(null)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={savingEdit}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg disabled:opacity-50 cursor-pointer"
                >
                  {savingEdit ? 'Menyimpan...' : 'Simpan Perubahan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL: KONFIRMASI HAPUS                                           */}
      {/* ================================================================= */}
      <ConfirmModal
        open={deleteTarget !== null}
        title={
          deleteTarget?.type === 'journal'
            ? 'Hapus Jurnal Mengajar'
            : deleteTarget?.type === 'grade'
            ? 'Hapus Nilai Akademik'
            : 'Hapus Penilaian Sikap'
        }
        description={
          deleteTarget?.type === 'journal'
            ? `Hapus jurnal "${deleteTarget.item.topic}" beserta seluruh catatan kehadiran siswa pada sesi ini?`
            : deleteTarget?.type === 'grade'
            ? `Hapus nilai ${deleteTarget.item.score} untuk ${studentMap.get(deleteTarget.item.studentId)?.fullName ?? 'siswa ini'}?`
            : deleteTarget?.type === 'attitude'
            ? `Hapus catatan sikap (${deleteTarget.item.aspect}) untuk ${studentMap.get(deleteTarget.item.studentId)?.fullName ?? 'siswa ini'}?`
            : ''
        }
        loading={savingEdit}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}
