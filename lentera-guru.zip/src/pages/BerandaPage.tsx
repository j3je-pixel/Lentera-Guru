import { useMemo, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  Award,
  BookOpen,
  CalendarCheck,
  Database,
  NotebookPen,
  Plus,
  School,
  TrendingDown,
  TrendingUp,
  Users,
} from 'lucide-react';
import { SchoolLogo } from '../components/SchoolLogo';
import { useApp } from '../contexts/AppContext';
import { MenuKey } from '../types';
import {
  formatIndonesianDate,
  getCurrentMonthIso,
} from '../utils/exportUtils';

interface BerandaPageProps {
  onNavigate: (key: MenuKey) => void;
}

export function BerandaPage({ onNavigate }: BerandaPageProps) {
  const {
    classes,
    subjects,
    students,
    grades,
    journals,
    attitudes,
    dataLoading,
    seedSampleData,
    theme,
  } = useApp();

  const isDark = theme === 'dark';
  const gridColor = isDark ? '#1e293b' : '#e2e8f0';
  const tickColor = isDark ? '#94a3b8' : '#64748b';
  const tooltipStyle = {
    borderRadius: '8px',
    border: isDark ? '1px solid #334155' : '1px solid #e2e8f0',
    backgroundColor: isDark ? '#0f172a' : '#ffffff',
    color: isDark ? '#f1f5f9' : '#0f172a',
    fontSize: '12px',
  };

  const [seeding, setSeeding] = useState(false);

  const avgScore = useMemo(() => {
    if (grades.length === 0) return 0;
    const sum = grades.reduce((acc, g) => acc + g.score, 0);
    return Number((sum / grades.length).toFixed(1));
  }, [grades]);

  const currentMonthIso = getCurrentMonthIso();

  const currentMonthLabel = useMemo(() => {
    const [y, m] = currentMonthIso.split('-').map(Number);
    const months = [
      'Januari',
      'Februari',
      'Maret',
      'April',
      'Mei',
      'Juni',
      'Juli',
      'Agustus',
      'September',
      'Oktober',
      'November',
      'Desember',
    ];
    return `${months[(m || 1) - 1] ?? m} ${y}`;
  }, [currentMonthIso]);

  const studentGenderSummary = useMemo(() => {
    const male = students.filter((s) => s.gender === 'L').length;
    const female = students.filter((s) => s.gender === 'P').length;
    return { total: students.length, male, female };
  }, [students]);

  const monthlyJournalSummary = useMemo(() => {
    const monthJournals = journals.filter((j) =>
      j.date.startsWith(currentMonthIso)
    );
    const totalPresent = monthJournals.reduce((a, j) => a + j.presentCount, 0);
    const totalAll = monthJournals.reduce(
      (a, j) =>
        a + j.presentCount + j.sickCount + j.permissionCount + j.absentCount,
      0
    );
    const attendanceRate =
      totalAll > 0 ? Math.round((totalPresent / totalAll) * 100) : 0;
    return { count: monthJournals.length, attendanceRate };
  }, [journals, currentMonthIso]);

  const latestGradeSummary = useMemo(() => {
    if (grades.length === 0) {
      return {
        hasGrades: false,
        latestAvg: 0,
        latestDate: '',
        count: 0,
        delta: null as number | null,
      };
    }
    const byDate = new Map<string, { sum: number; count: number }>();
    for (const g of grades) {
      const curr = byDate.get(g.date) ?? { sum: 0, count: 0 };
      curr.sum += g.score;
      curr.count += 1;
      byDate.set(g.date, curr);
    }
    const sortedDates = Array.from(byDate.keys()).sort((a, b) =>
      b.localeCompare(a)
    );
    const latestDate = sortedDates[0];
    const latestBucket = byDate.get(latestDate)!;
    const latestAvg = Number((latestBucket.sum / latestBucket.count).toFixed(1));

    let delta: number | null = null;
    if (sortedDates.length > 1) {
      const prevBucket = byDate.get(sortedDates[1])!;
      const prevAvg = prevBucket.sum / prevBucket.count;
      delta = Number((latestAvg - prevAvg).toFixed(1));
    }

    return {
      hasGrades: true,
      latestAvg,
      latestDate,
      count: latestBucket.count,
      delta,
    };
  }, [grades]);

  const journalSummary = useMemo(() => {
    const totalSessions = journals.length;
    const totalPresent = journals.reduce((a, j) => a + j.presentCount, 0);
    const totalSick = journals.reduce((a, j) => a + j.sickCount, 0);
    const totalPerm = journals.reduce((a, j) => a + j.permissionCount, 0);
    const totalAbsent = journals.reduce((a, j) => a + j.absentCount, 0);
    const totalAll = totalPresent + totalSick + totalPerm + totalAbsent;
    const attendanceRate =
      totalAll > 0 ? Math.round((totalPresent / totalAll) * 100) : 0;
    return { totalSessions, attendanceRate };
  }, [journals]);

  const distributionData = useMemo(() => {
    const buckets = [
      { range: '< 60', count: 0 },
      { range: '60 - 69', count: 0 },
      { range: '70 - 79', count: 0 },
      { range: '80 - 89', count: 0 },
      { range: '90 - 100', count: 0 },
    ];
    for (const g of grades) {
      if (g.score < 60) buckets[0].count += 1;
      else if (g.score < 70) buckets[1].count += 1;
      else if (g.score < 80) buckets[2].count += 1;
      else if (g.score < 90) buckets[3].count += 1;
      else buckets[4].count += 1;
    }
    return buckets;
  }, [grades]);

  const trendData = useMemo(() => {
    const byDate = new Map<string, { total: number; count: number }>();
    for (const g of grades) {
      const curr = byDate.get(g.date) ?? { total: 0, count: 0 };
      curr.total += g.score;
      curr.count += 1;
      byDate.set(g.date, curr);
    }
    return Array.from(byDate.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-12)
      .map(([date, val]) => ({
        dateLabel: date.slice(5),
        fullDate: formatIndonesianDate(date),
        rataRata: Number((val.total / val.count).toFixed(1)),
      }));
  }, [grades]);

  const classMap = useMemo(
    () => new Map(classes.map((c) => [c.id, c.name])),
    [classes]
  );
  const subjectMap = useMemo(
    () => new Map(subjects.map((s) => [s.id, s.name])),
    [subjects]
  );
  const studentMap = useMemo(
    () => new Map(students.map((s) => [s.id, s.fullName])),
    [students]
  );

  const handleSeed = async () => {
    setSeeding(true);
    try {
      await seedSampleData();
    } finally {
      setSeeding(false);
    }
  };

  if (dataLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <div
              key={i}
              className="h-28 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl animate-pulse"
            />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-80 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl animate-pulse" />
          <div className="h-80 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-slate-950 p-1 border border-slate-800/80 dark:border-slate-700/70 shrink-0 flex items-center justify-center overflow-hidden">
            <SchoolLogo className="w-full h-full object-contain" />
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-blue-700 dark:text-blue-400">
              SMP Zainul Hasan Genggong · Probolinggo
            </p>
            <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
              Ringkasan Administrasi & Penilaian
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
              Ikhtisar data kelas, siswa, capaian nilai akademik, dan aktivitas
              jurnal mengajar harian.
            </p>
          </div>
        </div>

        {classes.length === 0 && subjects.length === 0 && (
          <button
            type="button"
            onClick={handleSeed}
            disabled={seeding}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Database className="w-4 h-4 shrink-0" />
            <span>
              {seeding ? 'Memuat Data Contoh...' : 'Muat Data Contoh'}
            </span>
          </button>
        )}
      </div>

      {/* Primary Performance Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          type="button"
          onClick={() => onNavigate('siswa')}
          className="text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700 rounded-xl p-5 transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Jumlah Total Siswa
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/70 border border-blue-200 dark:border-blue-800 flex items-center justify-center shrink-0">
              <Users className="w-4 h-4 text-blue-700 dark:text-blue-400" />
            </div>
          </div>
          <p className="font-mono text-3xl font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-2">
            {studentGenderSummary.total}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 tabular-nums">
            {studentGenderSummary.male} L · {studentGenderSummary.female} P di{' '}
            {classes.length} kelas aktif
          </p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('jurnal')}
          className="text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700 rounded-xl p-5 transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Total Jurnal Bulan Ini
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center shrink-0">
              <CalendarCheck className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
            </div>
          </div>
          <p className="font-mono text-3xl font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-2">
            {monthlyJournalSummary.count}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 tabular-nums">
            {currentMonthLabel} · Kehadiran {monthlyJournalSummary.attendanceRate}%
          </p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('nilai')}
          className="text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 rounded-xl p-5 transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Rata-rata Nilai Akademik Terbaru
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200 dark:border-indigo-800 flex items-center justify-center shrink-0">
              {latestGradeSummary.delta !== null &&
              latestGradeSummary.delta < 0 ? (
                <TrendingDown className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              ) : (
                <TrendingUp className="w-4 h-4 text-indigo-700 dark:text-indigo-400" />
              )}
            </div>
          </div>
          <div className="flex items-baseline gap-2.5 mt-2">
            <p className="font-mono text-3xl font-bold text-blue-700 dark:text-blue-400 tabular-nums">
              {latestGradeSummary.hasGrades ? latestGradeSummary.latestAvg : '-'}
            </p>
            {latestGradeSummary.delta !== null && (
              <span
                className={`text-xs font-mono font-semibold tabular-nums ${
                  latestGradeSummary.delta >= 0
                    ? 'text-emerald-700 dark:text-emerald-400'
                    : 'text-amber-700 dark:text-amber-400'
                }`}
              >
                {latestGradeSummary.delta >= 0 ? '+' : ''}
                {latestGradeSummary.delta} vs sesi lalu
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 tabular-nums">
            {latestGradeSummary.hasGrades
              ? `${formatIndonesianDate(latestGradeSummary.latestDate)} (${latestGradeSummary.count} nilai) · Total: ${avgScore}`
              : 'Belum ada data penilaian akademik'}
          </p>
        </button>
      </div>

      {/* Secondary Quick Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <button
          type="button"
          onClick={() => onNavigate('kelas')}
          className="text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 rounded-xl p-4 transition-colors cursor-pointer flex items-center justify-between gap-3"
        >
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Total Kelas
            </p>
            <p className="font-mono text-xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
              {classes.length}
            </p>
          </div>
          <School className="w-4 h-4 text-slate-400 dark:text-slate-500 shrink-0" />
        </button>

        <button
          type="button"
          onClick={() => onNavigate('mapel')}
          className="text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 rounded-xl p-4 transition-colors cursor-pointer flex items-center justify-between gap-3"
        >
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Mata Pelajaran
            </p>
            <p className="font-mono text-xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
              {subjects.length}
            </p>
          </div>
          <BookOpen className="w-4 h-4 text-slate-400 dark:text-slate-500 shrink-0" />
        </button>

        <button
          type="button"
          onClick={() => onNavigate('jurnal')}
          className="text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 rounded-xl p-4 transition-colors cursor-pointer flex items-center justify-between gap-3"
        >
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Total Jurnal Keseluruhan
            </p>
            <p className="font-mono text-xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
              {journalSummary.totalSessions}
            </p>
          </div>
          <NotebookPen className="w-4 h-4 text-slate-400 dark:text-slate-500 shrink-0" />
        </button>

        <button
          type="button"
          onClick={() => onNavigate('sikap')}
          className="text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 rounded-xl p-4 transition-colors cursor-pointer flex items-center justify-between gap-3"
        >
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Catatan Sikap
            </p>
            <p className="font-mono text-xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
              {attitudes.length}
            </p>
          </div>
          <Award className="w-4 h-4 text-slate-400 dark:text-slate-500 shrink-0" />
        </button>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <div className="mb-5">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Distribusi Nilai Akademik
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Sebaran jumlah entri nilai siswa berdasarkan rentang skor
            </p>
          </div>
          {grades.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center border border-dashed border-slate-200 dark:border-slate-700 rounded-lg p-6">
              <p className="text-sm font-medium text-slate-700 dark:text-slate-200">
                Belum ada data nilai akademik
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">
                Mulai input nilai untuk menampilkan grafik distribusi skor.
              </p>
              <button
                type="button"
                onClick={() => onNavigate('nilai')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-950 rounded-lg cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Input Nilai Sekarang
              </button>
            </div>
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={distributionData}
                  margin={{ top: 8, right: 12, left: -16, bottom: 0 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke={gridColor}
                    vertical={false}
                  />
                  <XAxis
                    dataKey="range"
                    tick={{ fontSize: 12, fill: tickColor }}
                    axisLine={{ stroke: gridColor }}
                    tickLine={false}
                  />
                  <YAxis
                    allowDecimals={false}
                    tick={{ fontSize: 12, fill: tickColor }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    formatter={(val) => [`${val ?? 0} nilai`, 'Jumlah']}
                    contentStyle={tooltipStyle}
                  />
                  <Bar
                    dataKey="count"
                    fill={isDark ? '#3b82f6' : '#1d4ed8'}
                    radius={[6, 6, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <div className="mb-5">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Tren Rata-rata Nilai Siswa
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Perkembangan rata-rata nilai akademik berdasarkan tanggal penilaian
            </p>
          </div>
          {trendData.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center border border-dashed border-slate-200 dark:border-slate-700 rounded-lg p-6">
              <p className="text-sm font-medium text-slate-700 dark:text-slate-200">
                Belum ada riwayat tren nilai
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Grafik tren otomatis muncul setelah minimal satu tanggal
                penilaian tersimpan.
              </p>
            </div>
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={trendData}
                  margin={{ top: 8, right: 12, left: -16, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="scoreGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop
                        offset="5%"
                        stopColor={isDark ? '#3b82f6' : '#1d4ed8'}
                        stopOpacity={isDark ? 0.35 : 0.2}
                      />
                      <stop
                        offset="95%"
                        stopColor={isDark ? '#3b82f6' : '#1d4ed8'}
                        stopOpacity={0}
                      />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke={gridColor}
                    vertical={false}
                  />
                  <XAxis
                    dataKey="dateLabel"
                    tick={{ fontSize: 12, fill: tickColor }}
                    axisLine={{ stroke: gridColor }}
                    tickLine={false}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tick={{ fontSize: 12, fill: tickColor }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    labelFormatter={(_, payload) =>
                      payload?.[0]?.payload?.fullDate || ''
                    }
                    formatter={(val) => [`${val ?? 0}`, 'Rata-rata']}
                    contentStyle={tooltipStyle}
                  />
                  <Area
                    type="monotone"
                    dataKey="rataRata"
                    stroke={isDark ? '#60a5fa' : '#1d4ed8'}
                    strokeWidth={2}
                    fill="url(#scoreGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Jurnal Mengajar Terbaru
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('jurnal')}
              className="text-xs font-medium text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
            >
              Lihat Semua
            </button>
          </div>
          {journals.length === 0 ? (
            <p className="text-sm text-slate-500 dark:text-slate-400 py-6">
              Belum ada catatan jurnal mengajar yang disimpan.
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {journals.slice(0, 5).map((j) => (
                <div key={j.id} className="py-3 first:pt-0 last:pb-0">
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                    {j.topic}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
                    <span className="tabular-nums">
                      {formatIndonesianDate(j.date)}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{classMap.get(j.classId) || '-'}</span>
                    <span aria-hidden="true">·</span>
                    <span>{subjectMap.get(j.subjectId) || '-'}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">
                      Hadir {j.presentCount} / Tidak Hadir{' '}
                      {j.sickCount + j.permissionCount + j.absentCount}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Catatan Sikap & Kejadian Terbaru
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('sikap')}
              className="text-xs font-medium text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
            >
              Lihat Semua
            </button>
          </div>
          {attitudes.length === 0 ? (
            <p className="text-sm text-slate-500 dark:text-slate-400 py-6">
              Belum ada catatan penilaian sikap siswa.
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {attitudes.slice(0, 5).map((a) => (
                <div key={a.id} className="py-3 first:pt-0 last:pb-0">
                  <div className="flex items-baseline justify-between gap-3">
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                      {studentMap.get(a.studentId) || 'Siswa'}
                    </p>
                    <span
                      className={`text-xs font-medium whitespace-nowrap ${
                        a.predicate === 'Sangat Baik'
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : a.predicate === 'Baik'
                          ? 'text-blue-700 dark:text-blue-400'
                          : a.predicate === 'Cukup'
                          ? 'text-amber-700 dark:text-amber-400'
                          : 'text-red-700 dark:text-red-400'
                      }`}
                    >
                      {a.predicate}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
                    <span className="tabular-nums">
                      {formatIndonesianDate(a.date)}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{a.aspect}</span>
                  </div>
                  {a.notes && (
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-2">
                      {a.notes}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
