import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Edit3,
  Eye,
  EyeOff,
  Search,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  UserCheck,
  UserPlus,
  UserX,
  Users,
  X,
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useApp } from '../contexts/AppContext';
import { parseFirestoreErrorMessage } from '../firebase';
import { FIELD_LIMITS, UserProfile, UserRole, UserStatus } from '../types';

export function PenggunaPage() {
  const {
    user,
    userProfiles,
    storageMode,
    createUserAccount,
    updateManagedUser,
    deleteManagedUserProfile,
  } = useApp();

  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | UserStatus>('all');
  const [banner, setBanner] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Create modal
  const [createOpen, setCreateOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [newRole, setNewRole] = useState<UserRole>('guru');
  const [newNip, setNewNip] = useState('');
  const [newSpecialty, setNewSpecialty] = useState('');
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // Edit modal
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('guru');
  const [editStatus, setEditStatus] = useState<UserStatus>('active');
  const [editNip, setEditNip] = useState('');
  const [editSpecialty, setEditSpecialty] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  // Delete confirm
  const [deletingUser, setDeletingUser] = useState<UserProfile | null>(null);
  const [deleting, setDeleting] = useState(false);

  const stats = useMemo(() => {
    const total = userProfiles.length;
    const admins = userProfiles.filter((u) => u.role === 'admin').length;
    const activeTeachers = userProfiles.filter(
      (u) => u.role === 'guru' && u.status === 'active'
    ).length;
    const inactive = userProfiles.filter((u) => u.status === 'inactive').length;
    return { total, admins, activeTeachers, inactive };
  }, [userProfiles]);

  const filteredUsers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return userProfiles.filter((u) => {
      if (roleFilter !== 'all' && u.role !== roleFilter) return false;
      if (statusFilter !== 'all' && u.status !== statusFilter) return false;
      if (!q) return true;
      return (
        u.displayName.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        (u.nip || '').toLowerCase().includes(q) ||
        (u.subjectSpecialty || '').toLowerCase().includes(q)
      );
    });
  }, [userProfiles, search, roleFilter, statusFilter]);

  const resetCreateForm = () => {
    setNewName('');
    setNewEmail('');
    setNewPassword('');
    setShowNewPassword(false);
    setNewRole('guru');
    setNewNip('');
    setNewSpecialty('');
    setCreateError(null);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBanner(null);
    setCreateError(null);

    const trimmedName = newName.trim();
    const trimmedEmail = newEmail.trim();
    const selectedRole = newRole;

    if (!trimmedName) {
      setCreateError('Nama lengkap pengguna wajib diisi.');
      return;
    }
    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setCreateError('Format alamat email login tidak valid.');
      return;
    }
    if (storageMode === 'firebase' && newPassword.length < 6) {
      setCreateError('Kata sandi awal minimal harus 6 karakter.');
      return;
    }

    setCreating(true);
    try {
      await createUserAccount({
        displayName: trimmedName,
        email: trimmedEmail,
        password: newPassword,
        role: selectedRole,
        nip: newNip,
        subjectSpecialty: newSpecialty,
      });
      setCreateOpen(false);
      resetCreateForm();
      setBanner({
        type: 'success',
        text: `Akun ${selectedRole === 'admin' ? 'Administrator' : 'Guru'} untuk "${trimmedName}" berhasil dibuat.`,
      });
    } catch (err) {
      setCreateError(
        parseFirestoreErrorMessage(err, 'Gagal menambahkan akun pengguna.')
      );
    } finally {
      setCreating(false);
    }
  };

  const openEditModal = (target: UserProfile) => {
    setEditingUser(target);
    setEditName(target.displayName);
    setEditRole(target.role);
    setEditStatus(target.status);
    setEditNip(target.nip || '');
    setEditSpecialty(target.subjectSpecialty || '');
    setEditError(null);
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setBanner(null);
    setEditError(null);

    const trimmedName = editName.trim();
    if (!trimmedName) {
      setEditError('Nama lengkap pengguna wajib diisi.');
      return;
    }

    setSavingEdit(true);
    try {
      await updateManagedUser(editingUser.uid, {
        displayName: trimmedName,
        role: editRole,
        status: editStatus,
        nip: editNip,
        subjectSpecialty: editSpecialty,
      });
      setEditingUser(null);
      setBanner({
        type: 'success',
        text: `Data pengguna "${trimmedName}" berhasil diperbarui.`,
      });
    } catch (err) {
      setEditError(
        parseFirestoreErrorMessage(err, 'Gagal memperbarui pengguna.')
      );
    } finally {
      setSavingEdit(false);
    }
  };

  const handleQuickToggleStatus = async (target: UserProfile) => {
    setBanner(null);
    const nextStatus: UserStatus =
      target.status === 'active' ? 'inactive' : 'active';
    try {
      await updateManagedUser(target.uid, {
        displayName: target.displayName,
        role: target.role,
        status: nextStatus,
        nip: target.nip,
        subjectSpecialty: target.subjectSpecialty,
      });
      setBanner({
        type: 'success',
        text: `Akun "${target.displayName}" sekarang ${
          nextStatus === 'active' ? 'Aktif' : 'Dinonaktifkan'
        }.`,
      });
    } catch (err) {
      setBanner({
        type: 'error',
        text:
          err instanceof Error
            ? err.message
            : 'Gagal mengubah status pengguna.',
      });
    }
  };

  const handleConfirmDelete = async () => {
    if (!deletingUser) return;
    setDeleting(true);
    setBanner(null);
    try {
      await deleteManagedUserProfile(deletingUser.uid);
      setBanner({
        type: 'success',
        text: `Profil pengguna "${deletingUser.displayName}" berhasil dihapus dari daftar pengguna.`,
      });
      setDeletingUser(null);
    } catch (err) {
      setDeletingUser(null);
      setBanner({
        type: 'error',
        text:
          err instanceof Error
            ? err.message
            : 'Gagal menghapus profil pengguna.',
      });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Manajemen Pengguna Multi-User
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Kelola akun Guru dan Administrator, atur hak akses peran, serta
            aktifkan atau nonaktifkan akun pengguna sekolah.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            resetCreateForm();
            setCreateOpen(true);
          }}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <UserPlus className="w-4 h-4 shrink-0" />
          <span>Tambah Pengguna Baru</span>
        </button>
      </div>

      {banner && (
        <div
          className={`flex items-center justify-between gap-3 px-4 py-3 rounded-xl border text-sm ${
            banner.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : 'bg-red-50 dark:bg-red-950/60 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {banner.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{banner.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setBanner(null)}
            className="p-1 hover:opacity-75 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Total Pengguna
            </span>
            <Users className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          </div>
          <p className="font-mono text-2xl font-bold text-slate-900 dark:text-slate-100 mt-2 tabular-nums">
            {stats.total}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Administrator
            </span>
            <ShieldCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          </div>
          <p className="font-mono text-2xl font-bold text-slate-900 dark:text-slate-100 mt-2 tabular-nums">
            {stats.admins}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Guru Aktif
            </span>
            <UserCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <p className="font-mono text-2xl font-bold text-slate-900 dark:text-slate-100 mt-2 tabular-nums">
            {stats.activeTeachers}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Akun Nonaktif
            </span>
            <UserX className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          </div>
          <p className="font-mono text-2xl font-bold text-slate-900 dark:text-slate-100 mt-2 tabular-nums">
            {stats.inactive}
          </p>
        </div>
      </div>

      {/* Isolation Info Banner */}
      <div className="p-4 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/70 flex items-start gap-3 text-xs text-blue-900 dark:text-blue-200">
        <ShieldAlert className="w-4 h-4 text-blue-700 dark:text-blue-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          Setiap pengguna memiliki ruang data kelas, siswa, nilai, sikap, dan
          jurnal KBM terpisah agar pekerjaan antar guru tetap aman dan tidak
          saling menimpa. Guru juga dapat mendaftar mandiri di halaman login,
          atau didaftarkan langsung oleh Administrator di sini.
        </p>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari nama, email, NIP, atau mata pelajaran..."
            className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
          />
        </div>

        <div className="flex flex-wrap sm:flex-nowrap gap-2">
          <select
            value={roleFilter}
            onChange={(e) =>
              setRoleFilter(e.target.value as 'all' | UserRole)
            }
            className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
          >
            <option value="all">Semua Peran</option>
            <option value="admin">Administrator</option>
            <option value="guru">Guru</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) =>
              setStatusFilter(e.target.value as 'all' | UserStatus)
            }
            className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
          >
            <option value="all">Semua Status</option>
            <option value="active">Aktif</option>
            <option value="inactive">Nonaktif</option>
          </select>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-xs font-semibold text-slate-500 dark:text-slate-400">
                <th className="py-3 px-4">Pengguna</th>
                <th className="py-3 px-4">NIP / Mapel</th>
                <th className="py-3 px-4">Peran</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-sm">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td
                    colSpan={5}
                    className="py-10 px-4 text-center text-slate-500 dark:text-slate-400"
                  >
                    Tidak ada data pengguna yang sesuai filter.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((u) => {
                  const isSelf = u.uid === user?.uid;
                  return (
                    <tr
                      key={u.uid}
                      className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 flex items-center justify-center font-display font-semibold text-sm shrink-0">
                            {u.displayName.charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-slate-900 dark:text-slate-100 truncate">
                                {u.displayName}
                              </span>
                              {isSelf && (
                                <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold text-slate-600 dark:text-slate-300">
                                  Anda
                                </span>
                              )}
                            </div>
                            <p className="text-xs font-mono text-slate-500 dark:text-slate-400 truncate">
                              {u.email}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="text-xs text-slate-700 dark:text-slate-300">
                          {u.subjectSpecialty || '-'}
                        </div>
                        {u.nip && (
                          <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400 mt-0.5">
                            NIP: {u.nip}
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold border ${
                            u.role === 'admin'
                              ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300'
                              : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                          }`}
                        >
                          {u.role === 'admin' && (
                            <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                          )}
                          <span>
                            {u.role === 'admin' ? 'Administrator' : 'Guru'}
                          </span>
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold border ${
                            u.status === 'active'
                              ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                              : 'bg-red-50 dark:bg-red-950/50 border-red-200 dark:border-red-800 text-red-700 dark:text-red-300'
                          }`}
                        >
                          {u.status === 'active' ? 'Aktif' : 'Nonaktif'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => openEditModal(u)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
                            title="Edit profil dan peran"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Edit</span>
                          </button>

                          {!isSelf && (
                            <>
                              <button
                                type="button"
                                onClick={() => void handleQuickToggleStatus(u)}
                                className={`inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                                  u.status === 'active'
                                    ? 'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 dark:hover:bg-amber-950'
                                    : 'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 dark:hover:bg-emerald-950'
                                }`}
                                title={
                                  u.status === 'active'
                                    ? 'Nonaktifkan akun'
                                    : 'Aktifkan kembali akun'
                                }
                              >
                                {u.status === 'active' ? (
                                  <>
                                    <UserX className="w-3.5 h-3.5" />
                                    <span>Nonaktifkan</span>
                                  </>
                                ) : (
                                  <>
                                    <UserCheck className="w-3.5 h-3.5" />
                                    <span>Aktifkan</span>
                                  </>
                                )}
                              </button>

                              <button
                                type="button"
                                onClick={() => setDeletingUser(u)}
                                className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer"
                                title="Hapus profil pengguna"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create User Modal */}
      {createOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60">
          <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between sticky top-0 bg-white dark:bg-slate-900 z-10">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
                Tambah Akun Pengguna Baru
              </h2>
              <button
                type="button"
                onClick={() => {
                  setCreateError(null);
                  setCreateOpen(false);
                }}
                disabled={creating}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4">
              {createError && (
                <div
                  role="alert"
                  className="flex items-start gap-2.5 p-3.5 rounded-lg border border-red-200 dark:border-red-900/70 bg-red-50 dark:bg-red-950/60 text-xs leading-relaxed text-red-800 dark:text-red-200"
                >
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600 dark:text-red-400" />
                  <span>{createError}</span>
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Nama Lengkap &amp; Gelar
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.USER_DISPLAY_NAME}
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Contoh: Siti Nurhaliza, S.Pd."
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Email Login
                  </label>
                  <input
                    type="email"
                    required
                    maxLength={FIELD_LIMITS.USER_EMAIL}
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    placeholder="guru@smpzaha.sch.id"
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Peran Hak Akses
                  </label>
                  <select
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                  >
                    <option value="guru">Guru</option>
                    <option value="admin">Administrator</option>
                  </select>
                </div>
              </div>

              {storageMode === 'firebase' ? (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Kata Sandi Awal (Min. 6 Karakter)
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      required
                      minLength={6}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Masukkan kata sandi sementara"
                      className="w-full pl-3 pr-10 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword((p) => !p)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 cursor-pointer"
                    >
                      {showNewPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-950/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
                  Pada mode Google Apps Script, autentikasi dikelola langsung
                  oleh Akun Google pengguna sesuai email yang didaftarkan.
                </p>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    NIP / NIY (Opsional)
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.USER_NIP}
                    value={newNip}
                    onChange={(e) => setNewNip(e.target.value)}
                    placeholder="Opsional"
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Mata Pelajaran Diampu
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.USER_SPECIALTY}
                    value={newSpecialty}
                    onChange={(e) => setNewSpecialty(e.target.value)}
                    placeholder="Contoh: Matematika"
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setCreateOpen(false)}
                  disabled={creating}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{creating ? 'Membuat Akun...' : 'Buat Akun'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60">
          <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between sticky top-0 bg-white dark:bg-slate-900 z-10">
              <div>
                <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
                  Edit Data Pengguna
                </h2>
                <p className="text-xs font-mono text-slate-500 dark:text-slate-400">
                  {editingUser.email}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setEditError(null);
                  setEditingUser(null);
                }}
                disabled={savingEdit}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="p-6 space-y-4">
              {editError && (
                <div
                  role="alert"
                  className="flex items-start gap-2.5 p-3.5 rounded-lg border border-red-200 dark:border-red-900/70 bg-red-50 dark:bg-red-950/60 text-xs leading-relaxed text-red-800 dark:text-red-200"
                >
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600 dark:text-red-400" />
                  <span>{editError}</span>
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Nama Lengkap
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.USER_DISPLAY_NAME}
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Peran
                  </label>
                  <select
                    value={editRole}
                    disabled={editingUser.uid === user?.uid}
                    onChange={(e) => setEditRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg disabled:opacity-60 focus:outline-none focus:border-blue-600"
                  >
                    <option value="guru">Guru</option>
                    <option value="admin">Administrator</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Status Akun
                  </label>
                  <select
                    value={editStatus}
                    disabled={editingUser.uid === user?.uid}
                    onChange={(e) =>
                      setEditStatus(e.target.value as UserStatus)
                    }
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg disabled:opacity-60 focus:outline-none focus:border-blue-600"
                  >
                    <option value="active">Aktif</option>
                    <option value="inactive">Nonaktif</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    NIP / NIY
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.USER_NIP}
                    value={editNip}
                    onChange={(e) => setEditNip(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Mata Pelajaran Diampu
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.USER_SPECIALTY}
                    value={editSpecialty}
                    onChange={(e) => setEditSpecialty(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  disabled={savingEdit}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={savingEdit}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {savingEdit ? 'Menyimpan...' : 'Simpan Perubahan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        open={Boolean(deletingUser)}
        title="Hapus Profil Pengguna?"
        description={`Profil pengguna "${deletingUser?.displayName ?? ''}" (${deletingUser?.email ?? ''}) akan dihapus dari daftar pengguna aplikasi. Lanjutkan?`}
        confirmLabel="Ya, Hapus Profil"
        loading={deleting}
        onCancel={() => setDeletingUser(null)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}
