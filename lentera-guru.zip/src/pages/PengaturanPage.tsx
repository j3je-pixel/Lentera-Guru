import React, { useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Code2,
  Copy,
  Database,
  Download,
  Edit3,
  ExternalLink,
  FileCode2,
  FileJson,
  FileSpreadsheet,
  Moon,
  RotateCcw,
  Save,
  ShieldCheck,
  Sun,
  Trash2,
  Upload,
  UserCheck,
  X,
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import {
  BackupDataPayload,
  RestoreMode,
  useApp,
} from '../contexts/AppContext';
import { FIELD_LIMITS } from '../types';
import {
  exportToJson,
  formatIndonesianDate,
  getCurrentTimeHHMM,
  getTodayIso,
} from '../utils/exportUtils';

const LAST_BACKUP_STORAGE_KEY = 'lentera_last_backup_at';

interface ParsedBackupPreview {
  fileName: string;
  payload: BackupDataPayload;
  totalRecords: number;
  counts: { label: string; count: number }[];
  exportedAtLabel: string;
  sourceEmail: string;
}

export function PengaturanPage() {
  const {
    user,
    currentUserProfile,
    isAdmin,
    storageMode,
    spreadsheetUrl,
    theme,
    toggleTheme,
    classes,
    subjects,
    students,
    categories,
    grades,
    attitudes,
    journals,
    attendances,
    lessonSlots,
    teachingSchedules,
    restoreBackupData,
    updateOwnProfile,
    deleteClassesBulk,
    deleteSubjectsBulk,
    deleteGradesBulk,
    deleteAttitudesBulk,
    deleteJournalsBulk,
  } = useApp();

  const [lastBackupAt, setLastBackupAt] = useState<string | null>(() => {
    try {
      return localStorage.getItem(LAST_BACKUP_STORAGE_KEY);
    } catch {
      return null;
    }
  });
  const [statusBanner, setStatusBanner] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Restore state
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [restorePreview, setRestorePreview] =
    useState<ParsedBackupPreview | null>(null);
  const [restoreParseError, setRestoreParseError] = useState<string | null>(
    null
  );
  const [restoreMode, setRestoreMode] = useState<RestoreMode>('merge');
  const [confirmRestoreOpen, setConfirmRestoreOpen] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [gasDownloading, setGasDownloading] = useState<string | null>(null);
  const [gasCopied, setGasCopied] = useState(false);

  // Own profile editor state
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileName, setProfileName] = useState('');
  const [profileNip, setProfileNip] = useState('');
  const [profileSpecialty, setProfileSpecialty] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  // Category-level delete state
  type DeleteCategoryKey =
    | 'classes'
    | 'subjects'
    | 'grades'
    | 'attitudes'
    | 'journals';
  const [deleteCatTarget, setDeleteCatTarget] = useState<{
    key: DeleteCategoryKey;
    label: string;
    count: number;
    note?: string;
  } | null>(null);
  const [deletingCategory, setDeletingCategory] = useState(false);

  const openProfileEditor = () => {
    setProfileName(
      currentUserProfile?.displayName ||
        user?.displayName ||
        (isAdmin ? 'Administrator' : 'Guru Pengajar')
    );
    setProfileNip(currentUserProfile?.nip || '');
    setProfileSpecialty(currentUserProfile?.subjectSpecialty || '');
    setEditingProfile(true);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    setStatusBanner(null);
    try {
      await updateOwnProfile({
        displayName: profileName,
        nip: profileNip,
        subjectSpecialty: profileSpecialty,
      });
      setEditingProfile(false);
      setStatusBanner({
        type: 'success',
        text: 'Profil akun Anda berhasil diperbarui.',
      });
    } catch (err) {
      setStatusBanner({
        type: 'error',
        text:
          err instanceof Error
            ? `Gagal memperbarui profil: ${err.message}`
            : 'Gagal memperbarui profil.',
      });
    } finally {
      setSavingProfile(false);
    }
  };

  const collectionStats = useMemo(
    () => [
      { label: 'Kelas', count: classes.length },
      { label: 'Mata Pelajaran', count: subjects.length },
      { label: 'Siswa', count: students.length },
      { label: 'Kategori Penilaian', count: categories.length },
      { label: 'Nilai Akademik', count: grades.length },
      { label: 'Penilaian Sikap', count: attitudes.length },
      { label: 'Jurnal Mengajar', count: journals.length },
      { label: 'Kehadiran Siswa', count: attendances.length },
      { label: 'Slot Jam Pelajaran', count: lessonSlots.length },
      { label: 'Jadwal Mengajar', count: teachingSchedules.length },
    ],
    [
      classes.length,
      subjects.length,
      students.length,
      categories.length,
      grades.length,
      attitudes.length,
      journals.length,
      attendances.length,
      lessonSlots.length,
      teachingSchedules.length,
    ]
  );

  const totalRecords = useMemo(
    () => collectionStats.reduce((sum, item) => sum + item.count, 0),
    [collectionStats]
  );

  const handleDownloadBackup = () => {
    const today = getTodayIso();
    const timeCompact = getCurrentTimeHHMM().replace(':', '');
    const exportedAtIso = new Date().toISOString();

    const backupPayload = {
      metadata: {
        appName: 'Lentera Guru',
        school: 'SMP Zainul Hasan Genggong',
        backupVersion: '1.0',
        exportedAt: exportedAtIso,
        exportedBy: {
          uid: user?.uid ?? null,
          displayName: user?.displayName ?? null,
          email: user?.email ?? null,
        },
        totalRecords,
        counts: {
          classes: classes.length,
          subjects: subjects.length,
          students: students.length,
          gradingCategories: categories.length,
          academicGrades: grades.length,
          attitudeAssessments: attitudes.length,
          teachingJournals: journals.length,
          studentAttendance: attendances.length,
          lessonSlots: lessonSlots.length,
          teachingSchedules: teachingSchedules.length,
        },
      },
      data: {
        classes,
        subjects,
        students,
        gradingCategories: categories,
        academicGrades: grades,
        attitudeAssessments: attitudes,
        teachingJournals: journals,
        studentAttendance: attendances,
        lessonSlots,
        teachingSchedules,
      },
    };

    const fileName = `backup_smp_zaha_${today}_${timeCompact}`;
    exportToJson(backupPayload, fileName);

    const formattedStamp = `${formatIndonesianDate(today)}, pukul ${getCurrentTimeHHMM()}`;
    setLastBackupAt(formattedStamp);
    try {
      localStorage.setItem(LAST_BACKUP_STORAGE_KEY, formattedStamp);
    } catch {
      // ignore storage quota errors
    }
    setStatusBanner({
      type: 'success',
      text: `Cadangan lengkap (${totalRecords} data) berhasil diunduh sebagai ${fileName}.json.`,
    });
  };

  const resetFileSelection = () => {
    setRestorePreview(null);
    setRestoreParseError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSelectBackupFile = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setRestoreParseError(null);
    setStatusBanner(null);

    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as BackupDataPayload;

      if (!parsed || typeof parsed !== 'object' || !parsed.data || typeof parsed.data !== 'object') {
        setRestoreParseError(
          'Format file JSON tidak valid. Pastikan file berasal dari hasil Backup Data aplikasi ini.'
        );
        setRestorePreview(null);
        return;
      }

      const d = parsed.data;
      const collectionKeys = [
        'classes',
        'subjects',
        'students',
        'gradingCategories',
        'academicGrades',
        'attitudeAssessments',
        'teachingJournals',
        'studentAttendance',
        'lessonSlots',
        'teachingSchedules',
      ] as const;

      const hasKnownArray = collectionKeys.some((k) => Array.isArray(d[k]));
      if (!hasKnownArray) {
        setRestoreParseError(
          'File JSON tidak memiliki data koleksi aplikasi yang dikenali.'
        );
        setRestorePreview(null);
        return;
      }

      const counts = [
        { label: 'Kelas', count: Array.isArray(d.classes) ? d.classes.length : 0 },
        { label: 'Mapel', count: Array.isArray(d.subjects) ? d.subjects.length : 0 },
        { label: 'Siswa', count: Array.isArray(d.students) ? d.students.length : 0 },
        {
          label: 'Kategori',
          count: Array.isArray(d.gradingCategories)
            ? d.gradingCategories.length
            : 0,
        },
        {
          label: 'Nilai',
          count: Array.isArray(d.academicGrades) ? d.academicGrades.length : 0,
        },
        {
          label: 'Sikap',
          count: Array.isArray(d.attitudeAssessments)
            ? d.attitudeAssessments.length
            : 0,
        },
        {
          label: 'Jurnal',
          count: Array.isArray(d.teachingJournals)
            ? d.teachingJournals.length
            : 0,
        },
        {
          label: 'Kehadiran',
          count: Array.isArray(d.studentAttendance)
            ? d.studentAttendance.length
            : 0,
        },
        {
          label: 'Slot Jam',
          count: Array.isArray(d.lessonSlots) ? d.lessonSlots.length : 0,
        },
        {
          label: 'Jadwal',
          count: Array.isArray(d.teachingSchedules)
            ? d.teachingSchedules.length
            : 0,
        },
      ];

      const totalInFile = counts.reduce((sum, item) => sum + item.count, 0);
      const rawExportedAt = parsed.metadata?.exportedAt;
      let exportedAtLabel = '-';
      if (rawExportedAt) {
        const dt = new Date(rawExportedAt);
        exportedAtLabel = Number.isNaN(dt.getTime())
          ? rawExportedAt
          : dt.toLocaleString('id-ID', {
              dateStyle: 'medium',
              timeStyle: 'short',
            });
      }

      setRestorePreview({
        fileName: file.name,
        payload: parsed,
        totalRecords: totalInFile,
        counts,
        exportedAtLabel,
        sourceEmail: parsed.metadata?.exportedBy?.email || '-',
      });
    } catch {
      setRestoreParseError(
        'Gagal membaca file JSON. Pastikan file tidak rusak dan berformat JSON yang valid.'
      );
      setRestorePreview(null);
    }
  };

  const handleConfirmRestore = async () => {
    if (!restorePreview) return;
    setRestoring(true);
    setRestoreParseError(null);
    try {
      const result = await restoreBackupData(
        restorePreview.payload,
        restoreMode
      );
      setConfirmRestoreOpen(false);
      resetFileSelection();
      const orphanNote =
        result.skippedOrphans > 0
          ? ` (${result.skippedOrphans} entri yatim dilewati)`
          : '';
      setStatusBanner({
        type: 'success',
        text: `Pemulihan data selesai: ${result.totalRestored} entri berhasil dipulihkan${orphanNote}.`,
      });
    } catch (err) {
      setConfirmRestoreOpen(false);
      setStatusBanner({
        type: 'error',
        text:
          err instanceof Error
            ? `Gagal memulihkan data: ${err.message}`
            : 'Terjadi kesalahan saat memulihkan data.',
      });
    } finally {
      setRestoring(false);
    }
  };

  const handleConfirmDeleteCategory = async () => {
    if (!deleteCatTarget) return;
    setDeletingCategory(true);
    setStatusBanner(null);
    try {
      let deletedCount = 0;
      if (deleteCatTarget.key === 'classes') {
        deletedCount = await deleteClassesBulk(classes.map((c) => c.id));
      } else if (deleteCatTarget.key === 'subjects') {
        deletedCount = await deleteSubjectsBulk(subjects.map((s) => s.id));
      } else if (deleteCatTarget.key === 'grades') {
        deletedCount = await deleteGradesBulk(grades.map((g) => g.id));
      } else if (deleteCatTarget.key === 'attitudes') {
        deletedCount = await deleteAttitudesBulk(attitudes.map((a) => a.id));
      } else if (deleteCatTarget.key === 'journals') {
        deletedCount = await deleteJournalsBulk(journals.map((j) => j.id));
      }
      setStatusBanner({
        type: 'success',
        text: `${deletedCount} data kategori "${deleteCatTarget.label}" berhasil dihapus.`,
      });
      setDeleteCatTarget(null);
    } catch (err) {
      setDeleteCatTarget(null);
      setStatusBanner({
        type: 'error',
        text:
          err instanceof Error
            ? `Gagal menghapus data ${deleteCatTarget.label}: ${err.message}`
            : `Terjadi kesalahan saat menghapus data ${deleteCatTarget.label}.`,
      });
    } finally {
      setDeletingCategory(false);
    }
  };

  const handleDownloadGasAsset = async (
    assetPath: string,
    downloadFileName: string
  ) => {
    setGasDownloading(downloadFileName);
    setStatusBanner(null);
    try {
      const response = await fetch(assetPath);
      if (!response.ok) {
        throw new Error(`File ${downloadFileName} belum tersedia.`);
      }
      const text = await response.text();
      const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = downloadFileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setStatusBanner({
        type: 'success',
        text: `File ${downloadFileName} berhasil diunduh untuk Google Apps Script.`,
      });
    } catch (err) {
      setStatusBanner({
        type: 'error',
        text:
          err instanceof Error
            ? err.message
            : `Gagal mengunduh ${downloadFileName}.`,
      });
    } finally {
      setGasDownloading(null);
    }
  };

  const handleCopyCodeGs = async () => {
    setStatusBanner(null);
    try {
      const response = await fetch('/gas/Code.gs');
      if (!response.ok) {
        throw new Error('Gagal membaca file Code.gs.');
      }
      const text = await response.text();
      await navigator.clipboard.writeText(text);
      setGasCopied(true);
      setTimeout(() => setGasCopied(false), 2500);
      setStatusBanner({
        type: 'success',
        text: 'Seluruh kode Code.gs berhasil disalin ke clipboard.',
      });
    } catch (err) {
      setStatusBanner({
        type: 'error',
        text:
          err instanceof Error
            ? err.message
            : 'Gagal menyalin kode Code.gs ke clipboard.',
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
          Pengaturan Aplikasi
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Kelola preferensi tampilan, informasi akun guru, serta fitur Backup &
          Restore data lokal (JSON).
        </p>
      </div>

      {statusBanner && (
        <div
          className={`flex items-center justify-between gap-3 px-4 py-3 rounded-xl border text-sm ${
            statusBanner.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : 'bg-red-50 dark:bg-red-950/60 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {statusBanner.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{statusBanner.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatusBanner(null)}
            className="p-1 hover:opacity-75 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Backup Data Section */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-950/70 border border-blue-200 dark:border-blue-800 flex items-center justify-center shrink-0">
              <Database className="w-5 h-5 text-blue-700 dark:text-blue-400" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
                Backup Data Lokal (File JSON)
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
                Unduh seluruh data kelas, mata pelajaran, siswa, kategori, nilai
                akademik, penilaian sikap, jurnal mengajar, kehadiran, slot jam,
                dan jadwal mengajar ke perangkat Anda sebagai salinan cadangan
                keamanan tambahan.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleDownloadBackup}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>Unduh Cadangan Data (.json)</span>
          </button>
        </div>

        {/* Summary Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {collectionStats.map((item) => (
            <div
              key={item.label}
              className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60"
            >
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {item.label}
              </p>
              <p className="font-mono text-xl font-bold text-slate-900 dark:text-slate-100 mt-1 tabular-nums">
                {item.count}
              </p>
            </div>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-3 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>
              Total{' '}
              <strong className="font-mono text-slate-800 dark:text-slate-200">
                {totalRecords}
              </strong>{' '}
              entri siap dicadangkan dalam format JSON terstruktur.
            </span>
          </div>
          {lastBackupAt && (
            <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
              Cadangan terakhir: {lastBackupAt}
            </span>
          )}
        </div>
      </section>

      {/* Restore Data Section */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-amber-50 dark:bg-amber-950/70 border border-amber-200 dark:border-amber-800 flex items-center justify-center shrink-0">
            <RotateCcw className="w-5 h-5 text-amber-700 dark:text-amber-400" />
          </div>
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
              Restore Data (Pulihkan dari File JSON)
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
              Unggah file cadangan <code>.json</code> yang pernah diunduh untuk
              memulihkan data aplikasi secara aman ke database akun Anda.
            </p>
          </div>
        </div>

        {/* File Picker */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            onChange={handleSelectBackupFile}
            className="hidden"
            id="restore-json-input"
          />
          <label
            htmlFor="restore-json-input"
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Upload className="w-4 h-4 shrink-0" />
            <span>Pilih File Backup (.json)</span>
          </label>
          {restorePreview && (
            <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
              <FileJson className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
              <span className="font-mono font-medium truncate max-w-xs">
                {restorePreview.fileName}
              </span>
              <button
                type="button"
                onClick={resetFileSelection}
                className="p-1 text-slate-400 hover:text-red-600 dark:hover:text-red-400 cursor-pointer"
                title="Batalkan pilihan file"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {restoreParseError && (
          <div className="flex items-center gap-2 px-3.5 py-2.5 rounded-lg bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{restoreParseError}</span>
          </div>
        )}

        {/* Preview & Mode Selection */}
        {restorePreview && (
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-4 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-300 pb-3 border-b border-slate-200 dark:border-slate-800">
              <span>
                Total entri dalam file:{' '}
                <strong className="font-mono text-slate-900 dark:text-slate-100">
                  {restorePreview.totalRecords}
                </strong>
              </span>
              <span>
                Diekspor: <strong>{restorePreview.exportedAtLabel}</strong> ·
                Akun: <span className="font-mono">{restorePreview.sourceEmail}</span>
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {restorePreview.counts.map((c) => (
                <div
                  key={c.label}
                  className="px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
                >
                  <span className="text-slate-500 dark:text-slate-400">
                    {c.label}
                  </span>
                  <span className="font-mono font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
                    {c.count}
                  </span>
                </div>
              ))}
            </div>

            {/* Restore Mode Options */}
            <div className="space-y-2">
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Pilih Mode Pemulihan:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <label
                  className={`flex items-start gap-2.5 p-3 rounded-lg border cursor-pointer transition-colors ${
                    restoreMode === 'merge'
                      ? 'bg-blue-50/70 dark:bg-blue-950/40 border-blue-300 dark:border-blue-700'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <input
                    type="radio"
                    name="restoreMode"
                    value="merge"
                    checked={restoreMode === 'merge'}
                    onChange={() => setRestoreMode('merge')}
                    className="mt-0.5"
                  />
                  <div>
                    <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                      Gabung & Perbarui (Disarankan)
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Menambahkan data yang belum ada dan memperbarui data yang
                      cocok tanpa menghapus data lain saat ini.
                    </p>
                  </div>
                </label>

                <label
                  className={`flex items-start gap-2.5 p-3 rounded-lg border cursor-pointer transition-colors ${
                    restoreMode === 'replace'
                      ? 'bg-red-50/70 dark:bg-red-950/40 border-red-300 dark:border-red-700'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <input
                    type="radio"
                    name="restoreMode"
                    value="replace"
                    checked={restoreMode === 'replace'}
                    onChange={() => setRestoreMode('replace')}
                    className="mt-0.5"
                  />
                  <div>
                    <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                      Ganti Semua Data (Reset & Pulihkan)
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Menghapus seluruh data saat ini terlebih dahulu lalu
                      menggantinya persis seperti isi file cadangan.
                    </p>
                  </div>
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={resetFileSelection}
                disabled={restoring}
                className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={restoring || restorePreview.totalRecords === 0}
                onClick={() => setConfirmRestoreOpen(true)}
                className={`inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white rounded-lg transition-colors disabled:opacity-50 cursor-pointer ${
                  restoreMode === 'replace'
                    ? 'bg-red-600 hover:bg-red-700'
                    : 'bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500'
                }`}
              >
                <RotateCcw className="w-4 h-4 shrink-0" />
                <span>
                  {restoring ? 'Memulihkan Data...' : 'Pulihkan Data Sekarang'}
                </span>
              </button>
            </div>
          </div>
        )}
      </section>

      {/* Category Data Cleanup Section */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-red-50 dark:bg-red-950/70 border border-red-200 dark:border-red-800 flex items-center justify-center shrink-0">
            <Trash2 className="w-5 h-5 text-red-700 dark:text-red-400" />
          </div>
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
              Hapus Data Berdasarkan Kategori
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
              Bersihkan seluruh data pada kategori tertentu secara sekaligus
              (disarankan mengunduh Backup JSON terlebih dahulu sebelum
              menghapus).
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            {
              key: 'classes' as const,
              label: 'Kelas',
              count: classes.length,
              desc: 'Menghapus seluruh daftar rombongan belajar.',
            },
            {
              key: 'subjects' as const,
              label: 'Mata Pelajaran',
              count: subjects.length,
              desc: 'Menghapus seluruh daftar mata pelajaran.',
            },
            {
              key: 'grades' as const,
              label: 'Penilaian Akademik',
              count: grades.length,
              desc: 'Menghapus seluruh riwayat nilai harian & per Bab.',
            },
            {
              key: 'attitudes' as const,
              label: 'Penilaian Sikap',
              count: attitudes.length,
              desc: 'Menghapus seluruh catatan predikat sikap siswa.',
            },
            {
              key: 'journals' as const,
              label: 'Jurnal Mengajar',
              count: journals.length,
              desc: 'Menghapus seluruh jurnal KBM beserta absensi terkait.',
              note: 'Catatan kehadiran siswa yang tertaut pada jurnal juga akan ikut terhapus.',
            },
          ].map((cat) => (
            <div
              key={cat.key}
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 flex flex-col justify-between gap-3"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                    {cat.label}
                  </h3>
                  <span className="font-mono text-xs font-semibold text-slate-700 dark:text-slate-300 tabular-nums">
                    {cat.count} data
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  {cat.desc}
                </p>
              </div>

              <button
                type="button"
                disabled={cat.count === 0}
                onClick={() =>
                  setDeleteCatTarget({
                    key: cat.key,
                    label: cat.label,
                    count: cat.count,
                    note: cat.note,
                  })
                }
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/60 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus Semua {cat.label}</span>
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Google Apps Script & Google Spreadsheet Publish Section */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-emerald-50 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
                Publish ke Google Apps Script &amp; Google Spreadsheet
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
                {storageMode === 'gas'
                  ? 'Aplikasi ini sedang berjalan di Google Apps Script dan seluruh data tersimpan otomatis di Google Spreadsheet Anda.'
                  : 'Jalankan aplikasi ini sebagai Web App mandiri di Google Apps Script agar seluruh data kelas, siswa, nilai, sikap, jurnal, dan kehadiran tersimpan langsung di Google Spreadsheet pribadi Anda.'}
              </p>
            </div>
          </div>

          {storageMode === 'gas' && spreadsheetUrl && (
            <a
              href={spreadsheetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-emerald-700 hover:bg-emerald-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <ExternalLink className="w-4 h-4 shrink-0" />
              <span>Buka Google Spreadsheet</span>
            </a>
          )}
        </div>

        {storageMode === 'gas' ? (
          <div className="p-4 rounded-lg bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/70 text-xs text-emerald-900 dark:text-emerald-200 space-y-1.5">
            <p className="font-semibold">
              Terhubung Langsung ke Google Spreadsheet (11 Tab Database Multi-User)
            </p>
            <p className="text-emerald-800/90 dark:text-emerald-300/90">
              Tab aktif: <code>Users</code>, <code>Classes</code>,{' '}
              <code>Subjects</code>, <code>Students</code>,{' '}
              <code>GradingCategories</code>, <code>AcademicGrades</code>,{' '}
              <code>AttitudeAssessments</code>, <code>TeachingJournals</code>,{' '}
              <code>StudentAttendance</code>, <code>LessonSlots</code>, dan{' '}
              <code>TeachingSchedules</code>. Anda juga tetap dapat menggunakan
              fitur Backup &amp; Restore JSON di atas kapan saja.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() =>
                  void handleDownloadGasAsset('/gas/Code.gs', 'Code.gs')
                }
                disabled={gasDownloading !== null}
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-emerald-700 hover:bg-emerald-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
              >
                <Code2 className="w-4 h-4 shrink-0" />
                <span>
                  {gasDownloading === 'Code.gs'
                    ? 'Mengunduh...'
                    : 'Unduh Code.gs'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => void handleCopyCodeGs()}
                className="inline-flex items-center gap-2 px-3.5 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                <Copy className="w-4 h-4 shrink-0" />
                <span>{gasCopied ? 'Tersalin!' : 'Salin Code.gs'}</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  void handleDownloadGasAsset('/gas/Index.html', 'Index.html')
                }
                disabled={gasDownloading !== null}
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
              >
                <FileCode2 className="w-4 h-4 shrink-0" />
                <span>
                  {gasDownloading === 'Index.html'
                    ? 'Mengunduh...'
                    : 'Unduh Index.html (Aplikasi)'}
                </span>
              </button>

              <button
                type="button"
                onClick={() =>
                  void handleDownloadGasAsset(
                    '/gas/appsscript.json',
                    'appsscript.json'
                  )
                }
                disabled={gasDownloading !== null}
                className="inline-flex items-center gap-2 px-3.5 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4 shrink-0" />
                <span>appsscript.json</span>
              </button>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 space-y-2.5">
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Langkah Publish ke Google Apps Script (4 Langkah):
              </p>
              <ol className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400 list-decimal list-inside">
                <li>
                  Buat atau buka <strong>Google Spreadsheet</strong> baru untuk
                  database, lalu klik menu{' '}
                  <strong>Ekstensi &rarr; Apps Script</strong>.
                </li>
                <li>
                  Buka file <code>Code.gs</code> di editor Apps Script, hapus
                  isinya, lalu tempel isi file <code>Code.gs</code> yang sudah
                  diunduh/disalin.
                </li>
                <li>
                  Klik ikon <strong>+ (Tambah file) &rarr; HTML</strong>, beri
                  nama tepat <code>Index</code> (menjadi{' '}
                  <code>Index.html</code>), lalu tempel seluruh isi file{' '}
                  <code>Index.html</code> hasil unduhan dan simpan (
                  <code>Ctrl+S</code>).
                </li>
                <li>
                  Klik <strong>Terapkan &rarr; Deployment baru</strong>, pilih
                  jenis <strong>Aplikasi web</strong>, set{' '}
                  <em>Jalankan sebagai</em> ke <strong>Saya</strong> dan atur
                  akses sesuai kebutuhan, lalu klik <strong>Terapkan</strong>{' '}
                  untuk mendapatkan link Web App. Jika memindahkan data dari web
                  ini, gunakan file Backup JSON di atas lalu pilih{' '}
                  <strong>Restore Data</strong> di Web App baru Anda.
                </li>
              </ol>
            </div>
          </div>
        )}
      </section>

      {/* Account & Appearance Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <UserCheck className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" />
              <h2 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
                Identitas Akun &amp; Sekolah
              </h2>
            </div>

            {!editingProfile && (
              <button
                type="button"
                onClick={openProfileEditor}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit Profil</span>
              </button>
            )}
          </div>

          {editingProfile ? (
            <form onSubmit={handleSaveProfile} className="space-y-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nama Lengkap
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.USER_DISPLAY_NAME}
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    NIP / NIY
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.USER_NIP}
                    value={profileNip}
                    onChange={(e) => setProfileNip(e.target.value)}
                    placeholder="Opsional"
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Mapel Diampu
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.USER_SPECIALTY}
                    value={profileSpecialty}
                    onChange={(e) => setProfileSpecialty(e.target.value)}
                    placeholder="Contoh: Matematika"
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingProfile(false)}
                  disabled={savingProfile}
                  className="px-3.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={savingProfile}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{savingProfile ? 'Menyimpan...' : 'Simpan Profil'}</span>
                </button>
              </div>
            </form>
          ) : (
            <dl className="space-y-2.5 text-sm">
              <div className="flex justify-between gap-4 py-2 border-b border-slate-100 dark:border-slate-800">
                <dt className="text-slate-500 dark:text-slate-400">Nama Akun</dt>
                <dd className="font-medium text-slate-900 dark:text-slate-100 text-right">
                  {currentUserProfile?.displayName ||
                    user?.displayName ||
                    (isAdmin ? 'Administrator' : 'Guru Pengajar')}
                </dd>
              </div>
              <div className="flex justify-between gap-4 py-2 border-b border-slate-100 dark:border-slate-800">
                <dt className="text-slate-500 dark:text-slate-400">Peran</dt>
                <dd className="text-right">
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold border ${
                      isAdmin
                        ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300'
                        : 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                    }`}
                  >
                    {isAdmin ? 'Administrator' : 'Guru'}
                  </span>
                </dd>
              </div>
              <div className="flex justify-between gap-4 py-2 border-b border-slate-100 dark:border-slate-800">
                <dt className="text-slate-500 dark:text-slate-400">Email</dt>
                <dd className="font-mono text-xs text-slate-700 dark:text-slate-300 text-right">
                  {currentUserProfile?.email || user?.email || '-'}
                </dd>
              </div>
              <div className="flex justify-between gap-4 py-2 border-b border-slate-100 dark:border-slate-800">
                <dt className="text-slate-500 dark:text-slate-400">NIP / NIY</dt>
                <dd className="font-mono text-xs text-slate-700 dark:text-slate-300 text-right">
                  {currentUserProfile?.nip || '-'}
                </dd>
              </div>
              <div className="flex justify-between gap-4 py-2 border-b border-slate-100 dark:border-slate-800">
                <dt className="text-slate-500 dark:text-slate-400">
                  Mapel Diampu
                </dt>
                <dd className="font-medium text-slate-900 dark:text-slate-100 text-right">
                  {currentUserProfile?.subjectSpecialty || '-'}
                </dd>
              </div>
              <div className="flex justify-between gap-4 py-2">
                <dt className="text-slate-500 dark:text-slate-400">Sekolah</dt>
                <dd className="font-medium text-slate-900 dark:text-slate-100 text-right">
                  SMP Zainul Hasan Genggong
                </dd>
              </div>
            </dl>
          )}
        </section>

        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 flex flex-col justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              {theme === 'dark' ? (
                <Moon className="w-5 h-5 text-blue-400 shrink-0" />
              ) : (
                <Sun className="w-5 h-5 text-amber-500 shrink-0" />
              )}
              <h2 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
                Tampilan Antarmuka
              </h2>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Sesuaikan tema gelap atau terang sesuai kenyamanan pencahayaan saat
              mengisi jurnal dan penilaian.
            </p>
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
            <span className="text-xs font-medium text-slate-600 dark:text-slate-300">
              Tema aktif saat ini:{' '}
              <strong className="text-slate-900 dark:text-slate-100">
                {theme === 'dark' ? 'Mode Gelap' : 'Mode Terang'}
              </strong>
            </span>
            <button
              type="button"
              onClick={toggleTheme}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Ganti ke Mode Terang</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  <span>Ganti ke Mode Gelap</span>
                </>
              )}
            </button>
          </div>
        </section>
      </div>

      <ConfirmModal
        open={confirmRestoreOpen}
        title={
          restoreMode === 'replace'
            ? 'Ganti Semua Data dengan File Backup?'
            : 'Pulihkan & Gabung Data dari Backup?'
        }
        description={
          restoreMode === 'replace'
            ? `PERHATIAN: Seluruh ${totalRecords} data yang tersimpan saat ini akan dihapus dan diganti dengan ${restorePreview?.totalRecords ?? 0} data dari file "${restorePreview?.fileName ?? ''}". Lanjutkan?`
            : `Sebanyak ${restorePreview?.totalRecords ?? 0} data dari file "${restorePreview?.fileName ?? ''}" akan ditambahkan atau diperbarui ke akun Anda tanpa menghapus data lain. Lanjutkan?`
        }
        confirmLabel={
          restoreMode === 'replace' ? 'Ya, Ganti Semua' : 'Ya, Pulihkan Data'
        }
        loading={restoring}
        onCancel={() => setConfirmRestoreOpen(false)}
        onConfirm={handleConfirmRestore}
      />

      <ConfirmModal
        open={Boolean(deleteCatTarget)}
        title={`Hapus Semua Data ${deleteCatTarget?.label ?? ''}`}
        description={`PERHATIAN: Sebanyak ${deleteCatTarget?.count ?? 0} data pada kategori "${deleteCatTarget?.label ?? ''}" akan dihapus permanen. ${deleteCatTarget?.note ?? ''} Tindakan ini tidak dapat dibatalkan.`}
        confirmLabel="Ya, Hapus Kategori Ini"
        loading={deletingCategory}
        onCancel={() => setDeleteCatTarget(null)}
        onConfirm={handleConfirmDeleteCategory}
      />
    </div>
  );
}
