import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  CalendarClock,
  Clock,
  Pencil,
  Plus,
  Settings2,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useApp } from '../contexts/AppContext';
import {
  ATTENDANCE_STATUSES,
  AttendanceStatus,
  DEFAULT_LESSON_SLOTS,
  FIELD_LIMITS,
  INDONESIAN_DAYS,
  LessonSlot,
  TeachingJournal,
} from '../types';
import {
  formatIndonesianDate,
  getCurrentTimeHHMM,
  getDayOfWeekNumber,
  getIndonesianDayName,
  getTodayIso,
  timeToMinutes,
} from '../utils/exportUtils';

const ATTENDANCE_SHORT_LABEL: Record<AttendanceStatus, string> = {
  Hadir: 'H',
  Sakit: 'S',
  Izin: 'I',
  Alfa: 'A',
};

function formatSelectedSlotsText(slots: LessonSlot[]): string {
  if (slots.length === 0) return '';
  const sorted = [...slots].sort(
    (a, b) => a.order - b.order || a.startTime.localeCompare(b.startTime)
  );
  if (sorted.length === 1) {
    const s = sorted[0];
    return `${s.label} (${s.startTime} - ${s.endTime})`;
  }
  const first = sorted[0];
  const last = sorted[sorted.length - 1];
  return `${first.label} - ${last.label} (${first.startTime} - ${last.endTime})`;
}

export function JurnalPage() {
  const {
    classes,
    subjects,
    students,
    journals,
    attendances,
    lessonSlots,
    teachingSchedules,
    saveJournalWithAttendance,
    deleteJournal,
    deleteJournalsBulk,
    addLessonSlot,
    updateLessonSlot,
    deleteLessonSlot,
    seedDefaultLessonSlots,
    addSchedule,
    deleteSchedule,
  } = useApp();

  // Real-time clock for auto-detect display
  const [nowHHMM, setNowHHMM] = useState(getCurrentTimeHHMM());
  const [todayIso, setTodayIso] = useState(getTodayIso());

  useEffect(() => {
    const timer = window.setInterval(() => {
      setNowHHMM(getCurrentTimeHHMM());
      setTodayIso(getTodayIso());
    }, 30000);
    return () => window.clearInterval(timer);
  }, []);

  // Auto-seed default lesson slots once if user has 0 slots yet
  const autoSeedAttempted = useRef(false);
  useEffect(() => {
    if (lessonSlots.length === 0 && !autoSeedAttempted.current) {
      autoSeedAttempted.current = true;
      void seedDefaultLessonSlots();
    }
  }, [lessonSlots.length, seedDefaultLessonSlots]);

  // Filters
  const [filterClassId, setFilterClassId] = useState('ALL');
  const [filterDate, setFilterDate] = useState('');

  // Journal form modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<TeachingJournal | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<TeachingJournal | null>(
    null
  );
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleteMode, setBulkDeleteMode] = useState<
    'selected' | 'filtered' | null
  >(null);
  const [bulkDeleting, setBulkDeleting] = useState(false);

  // Journal form fields
  const [date, setDate] = useState(getTodayIso());
  const [lessonHours, setLessonHours] = useState('');
  const [selectedSlotIds, setSelectedSlotIds] = useState<string[]>([]);
  const [autoDetectHint, setAutoDetectHint] = useState<string>('');
  const [classId, setClassId] = useState('');
  const [subjectId, setSubjectId] = useState('');
  const [topic, setTopic] = useState('');
  const [presentCount, setPresentCount] = useState(0);
  const [sickCount, setSickCount] = useState(0);
  const [permissionCount, setPermissionCount] = useState(0);
  const [absentCount, setAbsentCount] = useState(0);
  const [reflection, setReflection] = useState('');
  const [studentStatuses, setStudentStatuses] = useState<
    Record<string, AttendanceStatus>
  >({});

  // Inline custom slot creator inside journal modal
  const [inlineSlotOpen, setInlineSlotOpen] = useState(false);
  const [inlineLabel, setInlineLabel] = useState('');
  const [inlineStart, setInlineStart] = useState('14:00');
  const [inlineEnd, setInlineEnd] = useState('15:00');

  // Slot & Weekly Schedule Manager Modal
  const [managerOpen, setManagerOpen] = useState(false);
  const [managerTab, setManagerTab] = useState<'slots' | 'schedules'>('slots');
  const [editingSlot, setEditingSlot] = useState<LessonSlot | null>(null);
  const [slotLabel, setSlotLabel] = useState('');
  const [slotStart, setSlotStart] = useState('07:00');
  const [slotEnd, setSlotEnd] = useState('07:45');
  const [slotOrder, setSlotOrder] = useState('1');

  const [schDay, setSchDay] = useState<number>(new Date().getDay());
  const [schSlotId, setSchSlotId] = useState('');
  const [schClassId, setSchClassId] = useState('');
  const [schSubjectId, setSchSubjectId] = useState('');

  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  const classMap = useMemo(
    () => new Map(classes.map((c) => [c.id, c.name])),
    [classes]
  );
  const subjectMap = useMemo(
    () => new Map(subjects.map((s) => [s.id, `${s.code} · ${s.name}`])),
    [subjects]
  );
  const slotMap = useMemo(
    () => new Map(lessonSlots.map((s) => [s.id, s])),
    [lessonSlots]
  );

  const effectiveSlots: LessonSlot[] = useMemo(() => {
    if (lessonSlots.length > 0) return lessonSlots;
    return DEFAULT_LESSON_SLOTS.map((s, idx) => ({
      id: `default-${idx}`,
      ownerId: '',
      ...s,
    }));
  }, [lessonSlots]);

  const modalClassStudents = useMemo(
    () => students.filter((s) => s.classId === classId),
    [students, classId]
  );

  const selectedDayOfWeek = useMemo(() => getDayOfWeekNumber(date), [date]);
  const selectedDayName = useMemo(() => getIndonesianDayName(date), [date]);

  const schedulesForSelectedDay = useMemo(() => {
    return teachingSchedules
      .filter((s) => s.dayOfWeek === selectedDayOfWeek)
      .sort((a, b) => {
        const sa = slotMap.get(a.slotId);
        const sb = slotMap.get(b.slotId);
        return (sa?.order ?? 99) - (sb?.order ?? 99);
      });
  }, [teachingSchedules, selectedDayOfWeek, slotMap]);

  const filteredJournals = useMemo(() => {
    return journals.filter((j) => {
      if (filterClassId !== 'ALL' && j.classId !== filterClassId) return false;
      if (filterDate && j.date !== filterDate) return false;
      return true;
    });
  }, [journals, filterClassId, filterDate]);

  const recalcCountsFromMap = (
    sts: Record<string, AttendanceStatus>,
    targetClassId: string
  ) => {
    const list = students.filter((s) => s.classId === targetClassId);
    let h = 0;
    let s = 0;
    let i = 0;
    let a = 0;
    for (const st of list) {
      const val = sts[st.id] ?? 'Hadir';
      if (val === 'Hadir') h += 1;
      else if (val === 'Sakit') s += 1;
      else if (val === 'Izin') i += 1;
      else a += 1;
    }
    setPresentCount(h);
    setSickCount(s);
    setPermissionCount(i);
    setAbsentCount(a);
  };

  const initStatusesForClass = (targetClassId: string, journalId?: string) => {
    const list = students.filter((s) => s.classId === targetClassId);
    const existingForJournal = journalId
      ? attendances.filter((a) => a.journalId === journalId)
      : [];
    const existingMap = new Map(
      existingForJournal.map((a) => [a.studentId, a.status])
    );
    const next: Record<string, AttendanceStatus> = {};
    for (const st of list) {
      next[st.id] = existingMap.get(st.id) ?? 'Hadir';
    }
    setStudentStatuses(next);
    if (list.length > 0 && !journalId) {
      recalcCountsFromMap(next, targetClassId);
    }
  };

  // Smart detection algorithm for date + time + schedule
  const runSmartSessionDetection = (targetDate: string, currentHHMM: string) => {
    const dayNum = getDayOfWeekNumber(targetDate);
    const dayName = getIndonesianDayName(targetDate);
    const nowMin = timeToMinutes(currentHHMM);

    const daySchedules = teachingSchedules
      .filter((sch) => sch.dayOfWeek === dayNum)
      .map((sch) => ({ sch, slot: slotMap.get(sch.slotId) }))
      .filter((x): x is { sch: typeof x.sch; slot: LessonSlot } =>
        Boolean(x.slot)
      );

    // 1. Check exact time match in today's configured teaching schedule
    const exactScheduled = daySchedules.find(
      ({ slot }) =>
        nowMin >= timeToMinutes(slot.startTime) &&
        nowMin <= timeToMinutes(slot.endTime)
    );

    if (exactScheduled) {
      const { sch, slot } = exactScheduled;
      return {
        slotIds: [slot.id],
        lessonHours: formatSelectedSlotsText([slot]),
        classId: sch.classId,
        subjectId: sch.subjectId,
        hint: `Terdeteksi otomatis dari jadwal ${dayName} (${currentHHMM}) · ${classMap.get(sch.classId) ?? ''} · ${subjectMap.get(sch.subjectId) ?? ''}`,
      };
    }

    // 2. If there are schedules on that day, pick the closest schedule slot by start time
    if (daySchedules.length > 0) {
      const sorted = [...daySchedules].sort(
        (a, b) =>
          Math.abs(timeToMinutes(a.slot.startTime) - nowMin) -
          Math.abs(timeToMinutes(b.slot.startTime) - nowMin)
      );
      const { sch, slot } = sorted[0];
      return {
        slotIds: [slot.id],
        lessonHours: formatSelectedSlotsText([slot]),
        classId: sch.classId,
        subjectId: sch.subjectId,
        hint: `Rekomendasi jadwal ${dayName}: ${slot.label} (${slot.startTime} - ${slot.endTime})`,
      };
    }

    // 3. No schedule for that day -> match active slot by current clock
    const activeSlot = effectiveSlots.find(
      (s) =>
        nowMin >= timeToMinutes(s.startTime) &&
        nowMin <= timeToMinutes(s.endTime)
    );
    if (activeSlot) {
      return {
        slotIds: activeSlot.id.startsWith('default-') ? [] : [activeSlot.id],
        lessonHours: formatSelectedSlotsText([activeSlot]),
        classId: classes[0]?.id ?? '',
        subjectId: subjects[0]?.id ?? '',
        hint: `Jam pelajaran terdeteksi otomatis sesuai pukul ${currentHHMM} (${activeSlot.label})`,
      };
    }

    // 4. Fallback: nearest slot by time
    if (effectiveSlots.length > 0) {
      const nearest = [...effectiveSlots].sort(
        (a, b) =>
          Math.abs(timeToMinutes(a.startTime) - nowMin) -
          Math.abs(timeToMinutes(b.startTime) - nowMin)
      )[0];
      return {
        slotIds: nearest.id.startsWith('default-') ? [] : [nearest.id],
        lessonHours: formatSelectedSlotsText([nearest]),
        classId: classes[0]?.id ?? '',
        subjectId: subjects[0]?.id ?? '',
        hint: `Saran jam terdekat untuk pukul ${currentHHMM}: ${nearest.label}`,
      };
    }

    return {
      slotIds: [],
      lessonHours: `Pukul ${currentHHMM}`,
      classId: classes[0]?.id ?? '',
      subjectId: subjects[0]?.id ?? '',
      hint: `Terisi otomatis sesuai waktu dibuka (${currentHHMM})`,
    };
  };

  const openCreate = () => {
    const today = getTodayIso();
    const currentTime = getCurrentTimeHHMM();
    const smart = runSmartSessionDetection(today, currentTime);

    setEditing(null);
    setDate(today);
    setSelectedSlotIds(smart.slotIds);
    setLessonHours(smart.lessonHours);
    setAutoDetectHint(smart.hint);
    setClassId(smart.classId);
    setSubjectId(smart.subjectId);
    setTopic('');
    setReflection('');
    setInlineSlotOpen(false);
    setFormError('');

    if (smart.classId) {
      initStatusesForClass(smart.classId);
    } else {
      setPresentCount(0);
      setSickCount(0);
      setPermissionCount(0);
      setAbsentCount(0);
      setStudentStatuses({});
    }
    setModalOpen(true);
  };

  const openEdit = (j: TeachingJournal) => {
    setEditing(j);
    setDate(j.date);
    setLessonHours(j.lessonHours);
    setSelectedSlotIds([]);
    setAutoDetectHint('');
    setClassId(j.classId);
    setSubjectId(j.subjectId);
    setTopic(j.topic);
    setPresentCount(j.presentCount);
    setSickCount(j.sickCount);
    setPermissionCount(j.permissionCount);
    setAbsentCount(j.absentCount);
    setReflection(j.reflection ?? '');
    setInlineSlotOpen(false);
    setFormError('');
    initStatusesForClass(j.classId, j.id);
    setModalOpen(true);
  };

  const handleDateChangeInForm = (newDate: string) => {
    setDate(newDate);
    if (!editing && newDate) {
      const smart = runSmartSessionDetection(newDate, getCurrentTimeHHMM());
      setSelectedSlotIds(smart.slotIds);
      setLessonHours(smart.lessonHours);
      setAutoDetectHint(smart.hint);
      if (smart.classId) {
        setClassId(smart.classId);
        initStatusesForClass(smart.classId);
      }
      if (smart.subjectId) {
        setSubjectId(smart.subjectId);
      }
    }
  };

  const handleToggleSlotInForm = (slot: LessonSlot) => {
    const exists = selectedSlotIds.includes(slot.id);
    const nextIds = exists
      ? selectedSlotIds.filter((id) => id !== slot.id)
      : [...selectedSlotIds, slot.id];

    setSelectedSlotIds(nextIds);
    if (nextIds.length > 0) {
      const chosen = effectiveSlots.filter((s) => nextIds.includes(s.id));
      setLessonHours(formatSelectedSlotsText(chosen));
      // Check if single slot matches a schedule on selected day
      if (chosen.length === 1 && !editing) {
        const matchedSchedule = schedulesForSelectedDay.find(
          (s) => s.slotId === chosen[0].id
        );
        if (matchedSchedule) {
          setClassId(matchedSchedule.classId);
          setSubjectId(matchedSchedule.subjectId);
          initStatusesForClass(matchedSchedule.classId);
          setAutoDetectHint(
            `Kelas & mapel disesuaikan otomatis dengan jadwal ${selectedDayName} (${chosen[0].label})`
          );
        }
      }
    }
  };

  const handleApplyScheduleChip = (sch: {
    slotId: string;
    classId: string;
    subjectId: string;
  }) => {
    const slot = slotMap.get(sch.slotId);
    if (!slot) return;
    setSelectedSlotIds([slot.id]);
    setLessonHours(formatSelectedSlotsText([slot]));
    setClassId(sch.classId);
    setSubjectId(sch.subjectId);
    initStatusesForClass(sch.classId);
    setAutoDetectHint(
      `Diterapkan dari jadwal ${selectedDayName}: ${slot.label} · ${classMap.get(sch.classId) ?? ''}`
    );
  };

  const handleCreateInlineSlot = async () => {
    if (!inlineLabel.trim() || !inlineStart || !inlineEnd) return;
    setSaving(true);
    try {
      const newOrder = lessonSlots.length + 1;
      const newId = await addLessonSlot({
        label: inlineLabel,
        startTime: inlineStart,
        endTime: inlineEnd,
        order: newOrder,
      });
      const newSlot: LessonSlot = {
        id: newId,
        ownerId: '',
        label: inlineLabel.trim(),
        startTime: inlineStart,
        endTime: inlineEnd,
        order: newOrder,
      };
      setSelectedSlotIds([newId]);
      setLessonHours(formatSelectedSlotsText([newSlot]));
      setInlineLabel('');
      setInlineSlotOpen(false);
    } finally {
      setSaving(false);
    }
  };

  const handleClassChangeInForm = (newClassId: string) => {
    setClassId(newClassId);
    initStatusesForClass(newClassId);
  };

  const handleStudentStatusChange = (
    studentId: string,
    status: AttendanceStatus
  ) => {
    const updated = { ...studentStatuses, [studentId]: status };
    setStudentStatuses(updated);
    recalcCountsFromMap(updated, classId);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !date ||
      !lessonHours.trim() ||
      !classId ||
      !subjectId ||
      !topic.trim()
    ) {
      setFormError(
        'Tanggal, jam pelajaran, kelas, mata pelajaran, dan materi pokok wajib diisi.'
      );
      return;
    }

    setSaving(true);
    setFormError('');
    try {
      const perStudentPayload = modalClassStudents.map((st) => ({
        studentId: st.id,
        status: studentStatuses[st.id] ?? 'Hadir',
      }));

      await saveJournalWithAttendance(
        {
          id: editing?.id,
          date,
          lessonHours,
          classId,
          subjectId,
          topic,
          presentCount,
          sickCount,
          permissionCount,
          absentCount,
          reflection,
        },
        perStudentPayload
      );
      setModalOpen(false);
    } catch (err) {
      setFormError(
        err instanceof Error ? err.message : 'Gagal menyimpan jurnal mengajar.'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      await deleteJournal(deleteTarget.id);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(deleteTarget.id);
        return next;
      });
      setDeleteTarget(null);
    } finally {
      setSaving(false);
    }
  };

  const filteredIds = useMemo(
    () => filteredJournals.map((j) => j.id),
    [filteredJournals]
  );

  const allFilteredSelected =
    filteredJournals.length > 0 &&
    filteredJournals.every((j) => selectedIds.has(j.id));

  const toggleSelectAll = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allFilteredSelected) {
        for (const id of filteredIds) next.delete(id);
      } else {
        for (const id of filteredIds) next.add(id);
      }
      return next;
    });
  };

  const toggleSelectCard = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleConfirmBulkDelete = async () => {
    const targetIds =
      bulkDeleteMode === 'filtered' ? filteredIds : Array.from(selectedIds);
    if (targetIds.length === 0) {
      setBulkDeleteMode(null);
      return;
    }
    setBulkDeleting(true);
    try {
      await deleteJournalsBulk(targetIds);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        for (const id of targetIds) next.delete(id);
        return next;
      });
      setBulkDeleteMode(null);
    } finally {
      setBulkDeleting(false);
    }
  };

  // Manager Modal handlers
  const openManager = (tab: 'slots' | 'schedules' = 'slots') => {
    setManagerTab(tab);
    setEditingSlot(null);
    setSlotLabel('');
    setSlotStart('07:00');
    setSlotEnd('07:45');
    setSlotOrder(String(lessonSlots.length + 1));
    setSchDay(new Date().getDay());
    setSchSlotId(lessonSlots[0]?.id ?? '');
    setSchClassId(classes[0]?.id ?? '');
    setSchSubjectId(subjects[0]?.id ?? '');
    setManagerOpen(true);
  };

  const handleSaveSlotInManager = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!slotLabel.trim() || !slotStart || !slotEnd) return;
    setSaving(true);
    try {
      const ord = Number(slotOrder) || lessonSlots.length + 1;
      if (editingSlot) {
        await updateLessonSlot(editingSlot.id, {
          label: slotLabel,
          startTime: slotStart,
          endTime: slotEnd,
          order: ord,
        });
        setEditingSlot(null);
      } else {
        await addLessonSlot({
          label: slotLabel,
          startTime: slotStart,
          endTime: slotEnd,
          order: ord,
        });
      }
      setSlotLabel('');
      setSlotOrder(String(lessonSlots.length + 2));
    } finally {
      setSaving(false);
    }
  };

  const handleAddScheduleInManager = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!schSlotId || !schClassId || !schSubjectId) return;
    setSaving(true);
    try {
      await addSchedule({
        dayOfWeek: schDay,
        slotId: schSlotId,
        classId: schClassId,
        subjectId: schSubjectId,
      });
    } finally {
      setSaving(false);
    }
  };

  const todayDisplay = `${getIndonesianDayName(todayIso)}, ${formatIndonesianDate(todayIso)} · ${nowHHMM}`;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Jurnal Harian Mengajar
          </h1>
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500 dark:text-slate-400 mt-1">
            <span>
              Catat agenda KBM harian, materi pokok, kehadiran siswa, serta
              refleksi pembelajaran.
            </span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1.5 font-mono text-xs text-blue-700 dark:text-blue-400 tabular-nums">
              <CalendarClock className="w-3.5 h-3.5 shrink-0" />
              {todayDisplay}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => openManager('slots')}
            className="inline-flex items-center justify-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Settings2 className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
            <span>Atur Jam & Jadwal</span>
          </button>

          <button
            type="button"
            onClick={openCreate}
            disabled={classes.length === 0 || subjects.length === 0}
            className="inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4 shrink-0" />
            <span>Tambah Jurnal</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <select
          value={filterClassId}
          onChange={(e) => setFilterClassId(e.target.value)}
          className="flex-1 px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200"
        >
          <option value="ALL">Semua Kelas</option>
          {classes.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} ({c.academicYear})
            </option>
          ))}
        </select>

        <div className="flex items-center gap-2">
          <input
            type="date"
            value={filterDate}
            onChange={(e) => setFilterDate(e.target.value)}
            className="px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
          />
          {filterDate && (
            <button
              type="button"
              onClick={() => setFilterDate('')}
              className="px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Bulk Action Bar */}
      {filteredJournals.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
            <label className="inline-flex items-center gap-2 cursor-pointer font-medium">
              <input
                type="checkbox"
                checked={allFilteredSelected}
                onChange={toggleSelectAll}
                className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
              />
              <span>Pilih Semua ({filteredJournals.length})</span>
            </label>
            {selectedIds.size > 0 && (
              <span className="font-mono text-blue-700 dark:text-blue-400 font-semibold">
                · {selectedIds.size} terpilih
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {selectedIds.size > 0 && (
              <button
                type="button"
                onClick={() => setBulkDeleteMode('selected')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus Terpilih ({selectedIds.size})</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setBulkDeleteMode('filtered')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/60 rounded-lg cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>
                Hapus{' '}
                {filteredJournals.length === journals.length
                  ? 'Semua'
                  : 'Sesuai Filter'}{' '}
                ({filteredJournals.length})
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Journal List */}
      {filteredJournals.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center">
          <p className="text-sm font-medium text-slate-800 dark:text-slate-100">
            {journals.length === 0
              ? 'Belum ada jurnal mengajar'
              : 'Tidak ada jurnal pada tanggal atau kelas tersebut'}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">
            {journals.length === 0
              ? 'Catat agenda KBM harian dengan deteksi hari dan jam pelajaran otomatis.'
              : 'Ubah filter kelas atau tanggal.'}
          </p>
          {journals.length === 0 &&
            classes.length > 0 &&
            subjects.length > 0 && (
              <button
                type="button"
                onClick={openCreate}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Tulis Jurnal Pertama</span>
              </button>
            )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredJournals.map((j) => (
            <div
              key={j.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={selectedIds.has(j.id)}
                    onChange={() => toggleSelectCard(j.id)}
                    aria-label={`Pilih jurnal ${j.topic}`}
                    className="mt-1 w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700 shrink-0"
                  />
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-mono font-medium text-slate-700 dark:text-slate-200 tabular-nums">
                        {getIndonesianDayName(j.date)},{' '}
                        {formatIndonesianDate(j.date)}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-slate-600 dark:text-slate-300">
                        {j.lessonHours}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-medium text-blue-800 dark:text-blue-400">
                        {classMap.get(j.classId) ?? '-'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{subjectMap.get(j.subjectId) ?? '-'}</span>
                    </div>

                    <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
                      {j.topic}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => openEdit(j)}
                    className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-blue-700 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 rounded-md cursor-pointer"
                    title="Edit Jurnal"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(j)}
                    className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-red-700 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-md cursor-pointer"
                    title="Hapus Jurnal"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-sm">
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Catatan / Refleksi Pembelajaran
                </p>
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                  {j.reflection || '-'}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-4 text-xs tabular-nums">
                <span className="text-slate-500 dark:text-slate-400 font-medium">
                  Kehadiran:
                </span>
                <span
                  className="text-emerald-700 dark:text-emerald-400 font-medium"
                  title="Hadir"
                >
                  H: {j.presentCount}
                </span>
                <span
                  className="text-amber-700 dark:text-amber-400 font-medium"
                  title="Sakit"
                >
                  S: {j.sickCount}
                </span>
                <span
                  className="text-blue-700 dark:text-blue-400 font-medium"
                  title="Izin"
                >
                  I: {j.permissionCount}
                </span>
                <span
                  className="text-red-700 dark:text-red-400 font-medium"
                  title="Alfa"
                >
                  A: {j.absentCount}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create/Edit Journal Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-3xl w-full max-h-[92vh] flex flex-col">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
              <div>
                <h2 className="font-display font-semibold text-lg text-slate-900 dark:text-slate-100">
                  {editing
                    ? 'Edit Jurnal Mengajar'
                    : 'Tambah Jurnal Harian Mengajar'}
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Hari terdeteksi:{' '}
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    {selectedDayName}
                  </span>{' '}
                  · {formatIndonesianDate(date)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={handleSubmit}
              className="p-6 overflow-y-auto space-y-5 flex-1"
            >
              {formError && (
                <div className="p-3 text-xs text-red-800 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 rounded-lg">
                  {formError}
                </div>
              )}

              {/* Quick Schedule Picks for Selected Day */}
              {schedulesForSelectedDay.length > 0 && (
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-lg space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                      Jadwal Mengajar Hari {selectedDayName}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      Klik untuk mengisi otomatis
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {schedulesForSelectedDay.map((sch) => {
                      const slot = slotMap.get(sch.slotId);
                      if (!slot) return null;
                      const active =
                        selectedSlotIds.includes(sch.slotId) &&
                        classId === sch.classId &&
                        subjectId === sch.subjectId;
                      return (
                        <button
                          key={sch.id}
                          type="button"
                          onClick={() => handleApplyScheduleChip(sch)}
                          className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                            active
                              ? 'bg-blue-700 border-blue-700 text-white dark:bg-blue-600 dark:border-blue-600'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-blue-500'
                          }`}
                        >
                          {slot.label} ({slot.startTime}) ·{' '}
                          {classMap.get(sch.classId) ?? '-'} ·{' '}
                          {subjectMap.get(sch.subjectId) ?? '-'}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Date + Auto-detect Day & Class/Subject */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Tanggal ({selectedDayName})
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => handleDateChangeInForm(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Kelas
                  </label>
                  <select
                    required
                    value={classId}
                    onChange={(e) => handleClassChangeInForm(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  >
                    <option value="">Pilih Kelas</option>
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Mata Pelajaran
                  </label>
                  <select
                    required
                    value={subjectId}
                    onChange={(e) => setSubjectId(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  >
                    <option value="">Pilih Mata Pelajaran</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.code} · {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Dynamic Lesson Hours Picker + Custom Inline Slot Creator */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-lg p-4 space-y-3 bg-slate-50/50 dark:bg-slate-800/30">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-blue-700 dark:text-blue-400 shrink-0" />
                    <label className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                      Pilihan & Penyesuaian Jam Pelajaran
                    </label>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setInlineSlotOpen((v) => !v)}
                      className="text-xs font-medium text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
                    >
                      {inlineSlotOpen
                        ? 'Tutup Form Slot'
                        : '+ Tambah Slot Jam Kustom'}
                    </button>
                    <span className="text-slate-300 dark:text-slate-700">·</span>
                    <button
                      type="button"
                      onClick={() => openManager('slots')}
                      className="text-xs font-medium text-slate-600 dark:text-slate-400 hover:underline cursor-pointer"
                    >
                      Kelola Semua Slot
                    </button>
                  </div>
                </div>

                {/* Slot Picker Grid */}
                <div className="flex flex-wrap gap-1.5">
                  {effectiveSlots.map((slot) => {
                    const isSelected = selectedSlotIds.includes(slot.id);
                    return (
                      <button
                        key={slot.id}
                        type="button"
                        onClick={() => handleToggleSlotInForm(slot)}
                        className={`px-2.5 py-1.5 text-xs rounded-md border font-mono tabular-nums transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-blue-700 border-blue-700 text-white dark:bg-blue-600 dark:border-blue-600'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-blue-500'
                        }`}
                      >
                        <span className="font-sans font-medium">
                          {slot.label}
                        </span>{' '}
                        <span className="opacity-80">
                          ({slot.startTime}-{slot.endTime})
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Inline Custom Slot Creator */}
                {inlineSlotOpen && (
                  <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg grid grid-cols-1 sm:grid-cols-4 gap-2.5 items-end">
                    <div className="sm:col-span-1">
                      <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1">
                        Label Slot
                      </label>
                      <input
                        type="text"
                        maxLength={FIELD_LIMITS.SLOT_LABEL}
                        value={inlineLabel}
                        onChange={(e) => setInlineLabel(e.target.value)}
                        placeholder="Jam Tambahan"
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1">
                        Mulai
                      </label>
                      <input
                        type="time"
                        value={inlineStart}
                        onChange={(e) => setInlineStart(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1">
                        Selesai
                      </label>
                      <input
                        type="time"
                        value={inlineEnd}
                        onChange={(e) => setInlineEnd(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleCreateInlineSlot}
                      disabled={saving || !inlineLabel.trim()}
                      className="px-3 py-1.5 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-50 rounded-md cursor-pointer"
                    >
                      Simpan Slot
                    </button>
                  </div>
                )}

                <div>
                  <input
                    type="text"
                    required
                    maxLength={FIELD_LIMITS.LESSON_HOURS}
                    value={lessonHours}
                    onChange={(e) => setLessonHours(e.target.value)}
                    placeholder="Contoh: Jam ke-1 - Jam ke-2 (07:00 - 08:30)"
                    className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  />
                  {autoDetectHint && (
                    <p className="text-xs text-blue-700 dark:text-blue-400 mt-1.5">
                      {autoDetectHint}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Materi Pokok / Topik Pembelajaran
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.JOURNAL_TOPIC}
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="Contoh: Persamaan dan Fungsi Kuadrat"
                  className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>

              {/* Attendance Counts + Per-student Checklist */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-lg p-4 space-y-3 bg-slate-50/50 dark:bg-slate-800/30">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Rekapitulasi Kehadiran Siswa
                  </p>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    Otomatis sinkron dengan Laporan Kehadiran Bulanan
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label
                      className="block text-xs text-emerald-700 dark:text-emerald-400 font-medium mb-1"
                      title="Hadir"
                    >
                      H
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={200}
                      value={presentCount}
                      onChange={(e) =>
                        setPresentCount(Math.max(0, Number(e.target.value)))
                      }
                      className="w-full px-2.5 py-1.5 text-sm font-mono tabular-nums border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label
                      className="block text-xs text-amber-700 dark:text-amber-400 font-medium mb-1"
                      title="Sakit"
                    >
                      S
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={200}
                      value={sickCount}
                      onChange={(e) =>
                        setSickCount(Math.max(0, Number(e.target.value)))
                      }
                      className="w-full px-2.5 py-1.5 text-sm font-mono tabular-nums border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label
                      className="block text-xs text-blue-700 dark:text-blue-400 font-medium mb-1"
                      title="Izin"
                    >
                      I
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={200}
                      value={permissionCount}
                      onChange={(e) =>
                        setPermissionCount(Math.max(0, Number(e.target.value)))
                      }
                      className="w-full px-2.5 py-1.5 text-sm font-mono tabular-nums border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label
                      className="block text-xs text-red-700 dark:text-red-400 font-medium mb-1"
                      title="Alfa"
                    >
                      A
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={200}
                      value={absentCount}
                      onChange={(e) =>
                        setAbsentCount(Math.max(0, Number(e.target.value)))
                      }
                      className="w-full px-2.5 py-1.5 text-sm font-mono tabular-nums border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>

                {modalClassStudents.length > 0 && (
                  <div className="max-h-44 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-950 divide-y divide-slate-100 dark:divide-slate-800">
                    {modalClassStudents.map((st) => {
                      const curr = studentStatuses[st.id] ?? 'Hadir';
                      return (
                        <div
                          key={st.id}
                          className="px-3 py-2 flex items-center justify-between gap-3 text-xs"
                        >
                          <span className="font-medium text-slate-800 dark:text-slate-200 truncate">
                            {st.fullName}
                          </span>
                          <div className="flex items-center gap-1 shrink-0">
                            {ATTENDANCE_STATUSES.map((status) => (
                              <button
                                key={status}
                                type="button"
                                title={status}
                                aria-label={status}
                                onClick={() =>
                                  handleStudentStatusChange(st.id, status)
                                }
                                className={`min-w-7 px-2 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
                                  curr === status
                                    ? status === 'Hadir'
                                      ? 'bg-emerald-600 text-white'
                                      : status === 'Sakit'
                                      ? 'bg-amber-600 text-white'
                                      : status === 'Izin'
                                      ? 'bg-blue-600 text-white'
                                      : 'bg-red-600 text-white'
                                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                                }`}
                              >
                                {ATTENDANCE_SHORT_LABEL[status]}
                              </button>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Catatan / Refleksi Pembelajaran
                </label>
                <textarea
                  rows={2}
                  maxLength={FIELD_LIMITS.JOURNAL_REFLECTION}
                  value={reflection}
                  onChange={(e) => setReflection(e.target.value)}
                  placeholder="Catatan capaian siswa, kendala, dan tindak lanjut..."
                  className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {saving ? 'Menyimpan...' : 'Simpan Jurnal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Lesson Slots & Weekly Schedule Manager Modal */}
      {managerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-3xl w-full max-h-[90vh] flex flex-col">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
              <h2 className="font-display font-semibold text-lg text-slate-900 dark:text-slate-100">
                Manajemen Jam Pelajaran & Jadwal Mengajar
              </h2>
              <button
                type="button"
                onClick={() => setManagerOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="px-6 pt-4 shrink-0">
              <div className="inline-flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                <button
                  type="button"
                  onClick={() => setManagerTab('slots')}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                    managerTab === 'slots'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                  }`}
                >
                  Daftar Slot Jam Pelajaran ({lessonSlots.length})
                </button>
                <button
                  type="button"
                  onClick={() => setManagerTab('schedules')}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                    managerTab === 'schedules'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                  }`}
                >
                  Jadwal Mengajar Mingguan ({teachingSchedules.length})
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              {managerTab === 'slots' ? (
                <>
                  <form
                    onSubmit={handleSaveSlotInManager}
                    className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-lg grid grid-cols-1 sm:grid-cols-12 gap-3 items-end"
                  >
                    <div className="sm:col-span-4">
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                        Nama / Label Slot
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={FIELD_LIMITS.SLOT_LABEL}
                        value={slotLabel}
                        onChange={(e) => setSlotLabel(e.target.value)}
                        placeholder="Contoh: Jam ke-9 / Remedial"
                        className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div className="sm:col-span-3">
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                        Jam Mulai
                      </label>
                      <input
                        type="time"
                        required
                        value={slotStart}
                        onChange={(e) => setSlotStart(e.target.value)}
                        className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div className="sm:col-span-3">
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                        Jam Selesai
                      </label>
                      <input
                        type="time"
                        required
                        value={slotEnd}
                        onChange={(e) => setSlotEnd(e.target.value)}
                        className="w-full px-3 py-2 text-sm font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div className="sm:col-span-2 flex gap-1.5">
                      <button
                        type="submit"
                        disabled={saving}
                        className="flex-1 px-3 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg cursor-pointer"
                      >
                        {editingSlot ? 'Perbarui' : 'Tambah'}
                      </button>
                      {editingSlot && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingSlot(null);
                            setSlotLabel('');
                          }}
                          className="px-2 py-2 text-xs text-slate-600 dark:text-slate-300 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
                        >
                          Batal
                        </button>
                      )}
                    </div>
                  </form>

                  <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
                    <table className="w-full text-left border-collapse text-sm">
                      <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                        <tr>
                          <th className="py-2.5 px-4">Urutan</th>
                          <th className="py-2.5 px-4">Label Jam</th>
                          <th className="py-2.5 px-4">Rentang Waktu</th>
                          <th className="py-2.5 px-4 text-right">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {lessonSlots.map((slot) => (
                          <tr key={slot.id}>
                            <td className="py-2.5 px-4 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                              #{slot.order}
                            </td>
                            <td className="py-2.5 px-4 font-medium text-slate-900 dark:text-slate-100">
                              {slot.label}
                            </td>
                            <td className="py-2.5 px-4 font-mono text-xs tabular-nums text-slate-600 dark:text-slate-300">
                              {slot.startTime} - {slot.endTime}
                            </td>
                            <td className="py-2.5 px-4 text-right">
                              <div className="inline-flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingSlot(slot);
                                    setSlotLabel(slot.label);
                                    setSlotStart(slot.startTime);
                                    setSlotEnd(slot.endTime);
                                    setSlotOrder(String(slot.order));
                                  }}
                                  className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-blue-700 dark:hover:text-blue-400 rounded-md cursor-pointer"
                                  title="Ubah slot"
                                >
                                  <Pencil className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => void deleteLessonSlot(slot.id)}
                                  className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-red-700 dark:hover:text-red-400 rounded-md cursor-pointer"
                                  title="Hapus slot"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : (
                <>
                  <form
                    onSubmit={handleAddScheduleInManager}
                    className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-lg grid grid-cols-1 sm:grid-cols-12 gap-3 items-end"
                  >
                    <div className="sm:col-span-3">
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                        Hari
                      </label>
                      <select
                        value={schDay}
                        onChange={(e) => setSchDay(Number(e.target.value))}
                        className="w-full px-2.5 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      >
                        {INDONESIAN_DAYS.map((d) => (
                          <option key={d.value} value={d.value}>
                            {d.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="sm:col-span-3">
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                        Slot Jam
                      </label>
                      <select
                        required
                        value={schSlotId}
                        onChange={(e) => setSchSlotId(e.target.value)}
                        className="w-full px-2.5 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      >
                        <option value="">Pilih Slot</option>
                        {lessonSlots.map((sl) => (
                          <option key={sl.id} value={sl.id}>
                            {sl.label} ({sl.startTime})
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                        Kelas
                      </label>
                      <select
                        required
                        value={schClassId}
                        onChange={(e) => setSchClassId(e.target.value)}
                        className="w-full px-2.5 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      >
                        <option value="">Pilih</option>
                        {classes.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                        Mapel
                      </label>
                      <select
                        required
                        value={schSubjectId}
                        onChange={(e) => setSchSubjectId(e.target.value)}
                        className="w-full px-2.5 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                      >
                        <option value="">Pilih</option>
                        {subjects.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.code}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <button
                        type="submit"
                        disabled={saving || !schSlotId || !schClassId || !schSubjectId}
                        className="w-full px-3 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-50 rounded-lg cursor-pointer"
                      >
                        Simpan
                      </button>
                    </div>
                  </form>

                  <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
                    {teachingSchedules.length === 0 ? (
                      <p className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
                        Belum ada jadwal mengajar mingguan. Tambahkan jadwal di
                        atas agar Jurnal Mengajar otomatis mendeteksi kelas dan
                        jam sesuai hari.
                      </p>
                    ) : (
                      <table className="w-full text-left border-collapse text-sm">
                        <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                          <tr>
                            <th className="py-2.5 px-4">Hari</th>
                            <th className="py-2.5 px-4">Slot Jam</th>
                            <th className="py-2.5 px-4">Kelas</th>
                            <th className="py-2.5 px-4">Mata Pelajaran</th>
                            <th className="py-2.5 px-4 text-right">Hapus</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                          {teachingSchedules.map((sch) => {
                            const dayLabel =
                              INDONESIAN_DAYS.find(
                                (d) => d.value === sch.dayOfWeek
                              )?.label ?? '-';
                            const slot = slotMap.get(sch.slotId);
                            return (
                              <tr key={sch.id}>
                                <td className="py-2.5 px-4 font-medium text-slate-900 dark:text-slate-100">
                                  {dayLabel}
                                </td>
                                <td className="py-2.5 px-4 font-mono text-xs text-slate-600 dark:text-slate-300">
                                  {slot
                                    ? `${slot.label} (${slot.startTime}-${slot.endTime})`
                                    : '-'}
                                </td>
                                <td className="py-2.5 px-4 text-slate-700 dark:text-slate-200">
                                  {classMap.get(sch.classId) ?? '-'}
                                </td>
                                <td className="py-2.5 px-4 text-slate-700 dark:text-slate-200">
                                  {subjectMap.get(sch.subjectId) ?? '-'}
                                </td>
                                <td className="py-2.5 px-4 text-right">
                                  <button
                                    type="button"
                                    onClick={() => void deleteSchedule(sch.id)}
                                    className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-red-700 dark:hover:text-red-400 rounded-md cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    )}
                  </div>
                </>
              )}
            </div>

            <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex justify-end shrink-0">
              <button
                type="button"
                onClick={() => setManagerOpen(false)}
                className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
              >
                Selesai
              </button>
            </div>
          </div>
        </div>
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Hapus Jurnal Mengajar"
        description={`Yakin ingin menghapus jurnal "${deleteTarget?.topic}" pada tanggal ${formatIndonesianDate(deleteTarget?.date ?? '')}?`}
        loading={saving}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <ConfirmModal
        open={Boolean(bulkDeleteMode)}
        title="Hapus Jurnal Mengajar"
        description={
          bulkDeleteMode === 'filtered'
            ? `Apakah Anda yakin ingin menghapus ${filteredJournals.length} jurnal mengajar yang ditampilkan beserta daftar kehadiran siswa terkait? Tindakan ini tidak dapat dibatalkan.`
            : `Apakah Anda yakin ingin menghapus ${selectedIds.size} jurnal mengajar yang dipilih beserta daftar kehadiran siswa terkait? Tindakan ini tidak dapat dibatalkan.`
        }
        confirmLabel="Ya, Hapus Jurnal"
        loading={bulkDeleting}
        onConfirm={handleConfirmBulkDelete}
        onCancel={() => setBulkDeleteMode(null)}
      />
    </div>
  );
}
