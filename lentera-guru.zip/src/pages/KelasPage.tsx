import React, { useMemo, useState } from 'react';
import { Pencil, Plus, Search, Trash2, X } from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useApp } from '../contexts/AppContext';
import { FIELD_LIMITS, SchoolClass } from '../types';

export function KelasPage() {
  const {
    classes,
    students,
    addClass,
    updateClass,
    deleteClass,
    deleteClassesBulk,
  } = useApp();

  const [search, setSearch] = useState('');
  const [yearFilter, setYearFilter] = useState('ALL');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<SchoolClass | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<SchoolClass | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleteMode, setBulkDeleteMode] = useState<
    'selected' | 'filtered' | null
  >(null);
  const [bulkDeleting, setBulkDeleting] = useState(false);

  const [name, setName] = useState('');
  const [gradeLevel, setGradeLevel] = useState('');
  const [academicYear, setAcademicYear] = useState('2026/2027');
  const [homeroomTeacher, setHomeroomTeacher] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  const academicYears = useMemo(() => {
    const set = new Set(classes.map((c) => c.academicYear));
    return Array.from(set).sort();
  }, [classes]);

  const studentCountByClass = useMemo(() => {
    const counts = new Map<string, number>();
    for (const s of students) {
      counts.set(s.classId, (counts.get(s.classId) ?? 0) + 1);
    }
    return counts;
  }, [students]);

  const filteredClasses = useMemo(() => {
    const q = search.trim().toLowerCase();
    return classes.filter((c) => {
      if (yearFilter !== 'ALL' && c.academicYear !== yearFilter) return false;
      if (!q) return true;
      return (
        c.name.toLowerCase().includes(q) ||
        c.gradeLevel.toLowerCase().includes(q) ||
        (c.homeroomTeacher ?? '').toLowerCase().includes(q)
      );
    });
  }, [classes, search, yearFilter]);

  const openCreate = () => {
    setEditing(null);
    setName('');
    setGradeLevel('');
    setAcademicYear('2026/2027');
    setHomeroomTeacher('');
    setFormError('');
    setModalOpen(true);
  };

  const openEdit = (cls: SchoolClass) => {
    setEditing(cls);
    setName(cls.name);
    setGradeLevel(cls.gradeLevel);
    setAcademicYear(cls.academicYear);
    setHomeroomTeacher(cls.homeroomTeacher ?? '');
    setFormError('');
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !gradeLevel.trim() || academicYear.trim().length < 4) {
      setFormError(
        'Nama kelas, tingkat kelas, dan tahun ajaran wajib diisi dengan benar.'
      );
      return;
    }
    setSaving(true);
    setFormError('');
    try {
      if (editing) {
        await updateClass(editing.id, {
          name,
          gradeLevel,
          academicYear,
          homeroomTeacher,
        });
      } else {
        await addClass({
          name,
          gradeLevel,
          academicYear,
          homeroomTeacher,
        });
      }
      setModalOpen(false);
    } catch (err) {
      setFormError(
        err instanceof Error ? err.message : 'Gagal menyimpan data kelas.'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      await deleteClass(deleteTarget.id);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(deleteTarget.id);
        return next;
      });
      setDeleteTarget(null);
    } finally {
      setSaving(false);
    }
  };

  const filteredIds = useMemo(
    () => filteredClasses.map((c) => c.id),
    [filteredClasses]
  );

  const allFilteredSelected =
    filteredClasses.length > 0 &&
    filteredClasses.every((c) => selectedIds.has(c.id));

  const toggleSelectAll = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allFilteredSelected) {
        for (const id of filteredIds) next.delete(id);
      } else {
        for (const id of filteredIds) next.add(id);
      }
      return next;
    });
  };

  const toggleSelectRow = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleConfirmBulkDelete = async () => {
    const targetIds =
      bulkDeleteMode === 'filtered' ? filteredIds : Array.from(selectedIds);
    if (targetIds.length === 0) {
      setBulkDeleteMode(null);
      return;
    }
    setBulkDeleting(true);
    try {
      await deleteClassesBulk(targetIds);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        for (const id of targetIds) next.delete(id);
        return next;
      });
      setBulkDeleteMode(null);
    } finally {
      setBulkDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Manajemen Kelas
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Kelola daftar rombongan belajar, tingkat kelas, dan tahun ajaran
            aktif.
          </p>
        </div>

        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4 shrink-0" />
          <span>Tambah Kelas</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari nama kelas, tingkat, atau wali kelas..."
            className="w-full pl-9 pr-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
          />
        </div>
        <select
          value={yearFilter}
          onChange={(e) => setYearFilter(e.target.value)}
          className="px-3 py-2 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
        >
          <option value="ALL">Semua Tahun Ajaran</option>
          {academicYears.map((y) => (
            <option key={y} value={y}>
              {y}
            </option>
          ))}
        </select>
      </div>

      {/* Bulk Action Bar */}
      {filteredClasses.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
            <label className="inline-flex items-center gap-2 cursor-pointer font-medium">
              <input
                type="checkbox"
                checked={allFilteredSelected}
                onChange={toggleSelectAll}
                className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
              />
              <span>Pilih Semua ({filteredClasses.length})</span>
            </label>
            {selectedIds.size > 0 && (
              <span className="font-mono text-blue-700 dark:text-blue-400 font-semibold">
                · {selectedIds.size} terpilih
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {selectedIds.size > 0 && (
              <button
                type="button"
                onClick={() => setBulkDeleteMode('selected')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus Terpilih ({selectedIds.size})</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setBulkDeleteMode('filtered')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/60 rounded-lg cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>
                Hapus{' '}
                {filteredClasses.length === classes.length
                  ? 'Semua'
                  : 'Sesuai Filter'}{' '}
                ({filteredClasses.length})
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        {filteredClasses.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
              {classes.length === 0
                ? 'Belum ada data kelas'
                : 'Tidak ada kelas yang cocok dengan filter'}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">
              {classes.length === 0
                ? 'Tambahkan kelas pertama Anda untuk mulai mengelompokkan siswa dan penilaian.'
                : 'Ubah kata kunci pencarian atau filter tahun ajaran.'}
            </p>
            {classes.length === 0 && (
              <button
                type="button"
                onClick={openCreate}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Kelas Pertama</span>
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-xs font-medium text-slate-500 dark:text-slate-400">
                  <th className="py-3 px-3 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={allFilteredSelected}
                      onChange={toggleSelectAll}
                      aria-label="Pilih semua kelas"
                      className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
                    />
                  </th>
                  <th className="py-3 px-4">Nama Kelas</th>
                  <th className="py-3 px-4">Tingkat</th>
                  <th className="py-3 px-4">Tahun Ajaran</th>
                  <th className="py-3 px-4">Wali Kelas</th>
                  <th className="py-3 px-4 text-right">Jumlah Siswa</th>
                  <th className="py-3 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {filteredClasses.map((cls) => (
                  <tr
                    key={cls.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                  >
                    <td className="py-3 px-3 text-center">
                      <input
                        type="checkbox"
                        checked={selectedIds.has(cls.id)}
                        onChange={() => toggleSelectRow(cls.id)}
                        className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-700"
                      />
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-900 dark:text-slate-100">
                      {cls.name}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                      {cls.gradeLevel}
                    </td>
                    <td className="py-3 px-4 font-mono text-xs text-slate-700 dark:text-slate-300 tabular-nums">
                      {cls.academicYear}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                      {cls.homeroomTeacher || '-'}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                      {studentCountByClass.get(cls.id) ?? 0}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => openEdit(cls)}
                          className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-blue-700 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 rounded-md transition-colors cursor-pointer"
                          title="Edit Kelas"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteTarget(cls)}
                          className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-red-700 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-md transition-colors cursor-pointer"
                          title="Hapus Kelas"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 dark:bg-slate-950/70">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display font-semibold text-lg text-slate-900 dark:text-slate-100">
                {editing ? 'Edit Data Kelas' : 'Tambah Kelas Baru'}
              </h2>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1 text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 rounded-md cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 p-3 text-xs text-red-800 dark:text-red-200 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 rounded-lg">
                {formError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Nama Kelas
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.CLASS_NAME}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: X IPA 1 atau VII-A"
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Tingkat Kelas
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.GRADE_LEVEL}
                  value={gradeLevel}
                  onChange={(e) => setGradeLevel(e.target.value)}
                  placeholder="Contoh: Kelas X atau Tingkat VII"
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Tahun Ajaran
                </label>
                <input
                  type="text"
                  required
                  minLength={4}
                  maxLength={FIELD_LIMITS.ACADEMIC_YEAR}
                  value={academicYear}
                  onChange={(e) => setAcademicYear(e.target.value)}
                  placeholder="Contoh: 2026/2027"
                  className="w-full px-3 py-2 text-sm font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Wali Kelas (Opsional)
                </label>
                <input
                  type="text"
                  maxLength={FIELD_LIMITS.HOMEROOM_TEACHER}
                  value={homeroomTeacher}
                  onChange={(e) => setHomeroomTeacher(e.target.value)}
                  placeholder="Nama wali kelas"
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-lg placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {saving ? 'Menyimpan...' : 'Simpan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Hapus Data Kelas"
        description={`Apakah Anda yakin ingin menghapus kelas "${deleteTarget?.name}"? Pastikan siswa dan catatan di kelas ini sudah dipindahkan jika masih diperlukan.`}
        loading={saving}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <ConfirmModal
        open={Boolean(bulkDeleteMode)}
        title="Hapus Data Kelas"
        description={
          bulkDeleteMode === 'filtered'
            ? `Apakah Anda yakin ingin menghapus ${filteredClasses.length} data kelas yang ditampilkan? Tindakan ini tidak dapat dibatalkan.`
            : `Apakah Anda yakin ingin menghapus ${selectedIds.size} data kelas yang dipilih? Tindakan ini tidak dapat dibatalkan.`
        }
        confirmLabel="Ya, Hapus Kelas"
        loading={bulkDeleting}
        onConfirm={handleConfirmBulkDelete}
        onCancel={() => setBulkDeleteMode(null)}
      />
    </div>
  );
}
