import * as XLSX from 'xlsx';

export function exportToExcel(
  rows: Record<string, string | number>[],
  sheetName: string,
  fileName: string
): void {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName.slice(0, 31));
  XLSX.writeFile(workbook, `${fileName}.xlsx`);
}

export function exportToCsv(
  rows: Record<string, string | number>[],
  fileName: string
): void {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const csvContent = XLSX.utils.sheet_to_csv(worksheet);
  const blob = new Blob(['\uFEFF' + csvContent], {
    type: 'text/csv;charset=utf-8;',
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${fileName}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function jsonReplacer(_key: string, value: unknown): unknown {
  if (
    value &&
    typeof value === 'object' &&
    'toDate' in value &&
    typeof (value as { toDate: unknown }).toDate === 'function'
  ) {
    try {
      return (value as { toDate: () => Date }).toDate().toISOString();
    } catch {
      return value;
    }
  }
  return value;
}

export function exportToJson(data: unknown, fileName: string): void {
  const jsonText = JSON.stringify(data, jsonReplacer, 2);
  const blob = new Blob([jsonText], {
    type: 'application/json;charset=utf-8;',
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${fileName}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function downloadStudentTemplateExcel(): void {
  const sampleRows = [
    {
      NIS: '2026001',
      'Nama Lengkap': 'Ahmad Fauzi Pratama',
      'Jenis Kelamin': 'L',
      Kelas: 'X IPA 1',
    },
    {
      NIS: '2026002',
      'Nama Lengkap': 'Nadia Putri Rahmawati',
      'Jenis Kelamin': 'P',
      Kelas: 'X IPA 1',
    },
    {
      NIS: '2026003',
      'Nama Lengkap': 'Budi Santoso',
      'Jenis Kelamin': 'L',
      Kelas: 'X IPA 2',
    },
  ];
  const worksheet = XLSX.utils.json_to_sheet(sampleRows);
  worksheet['!cols'] = [
    { wch: 15 },
    { wch: 30 },
    { wch: 16 },
    { wch: 16 },
  ];
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Template Siswa');
  XLSX.writeFile(workbook, 'template_import_siswa.xlsx');
}

export function downloadGradeTemplateExcel(): void {
  const today = getTodayIso();
  const sampleRows = [
    {
      Tanggal: today,
      NIS: '2026101',
      'Nama Siswa': 'Ahmad Rizky Pratama',
      Kelas: 'VII A',
      'Mata Pelajaran': 'Matematika',
      'Jenis Penilaian': 'Formatif',
      Kategori: 'Tugas Harian',
      Bab: 'Bab 1',
      'Penilaian Ke': 1,
      Nilai: 85,
      Catatan: 'Formatif awal Bab 1',
    },
    {
      Tanggal: today,
      NIS: '2026101',
      'Nama Siswa': 'Ahmad Rizky Pratama',
      Kelas: 'VII A',
      'Mata Pelajaran': 'Matematika',
      'Jenis Penilaian': 'Formatif',
      Kategori: 'Tugas Harian',
      Bab: 'Bab 1',
      'Penilaian Ke': 2,
      Nilai: 88,
      Catatan: 'Latihan soal Bab 1',
    },
    {
      Tanggal: today,
      NIS: '2026101',
      'Nama Siswa': 'Ahmad Rizky Pratama',
      Kelas: 'VII A',
      'Mata Pelajaran': 'Matematika',
      'Jenis Penilaian': 'Sumatif',
      Kategori: 'PTS',
      Bab: 'Sumatif Lingkup Materi (Bab 1)',
      'Penilaian Ke': 1,
      Nilai: 92,
      Catatan: 'Evaluasi Sumatif Bab 1',
    },
    {
      Tanggal: today,
      NIS: '2026102',
      'Nama Siswa': 'Aulia Putri Maharani',
      Kelas: 'VII A',
      'Mata Pelajaran': 'Matematika',
      'Jenis Penilaian': 'Sumatif',
      Kategori: 'Ulangan Harian',
      Bab: 'Sumatif Lingkup Materi (Bab 1)',
      'Penilaian Ke': 1,
      Nilai: 90,
      Catatan: '',
    },
  ];
  const worksheet = XLSX.utils.json_to_sheet(sampleRows);
  worksheet['!cols'] = [
    { wch: 13 },
    { wch: 13 },
    { wch: 26 },
    { wch: 12 },
    { wch: 18 },
    { wch: 16 },
    { wch: 18 },
    { wch: 26 },
    { wch: 13 },
    { wch: 10 },
    { wch: 28 },
  ];
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Template Penilaian');
  XLSX.writeFile(workbook, 'template_import_penilaian.xlsx');
}

export function formatIndonesianDate(isoDate: string): string {
  if (!isoDate) return '-';
  const [y, m, d] = isoDate.split('-').map(Number);
  if (!y || !m || !d) return isoDate;
  const months = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember',
  ];
  return `${d} ${months[m - 1] ?? m} ${y}`;
}

export function getTodayIso(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getCurrentMonthIso(): string {
  return getTodayIso().slice(0, 7);
}

export function getDayOfWeekNumber(isoDate: string): number {
  const [y, m, d] = isoDate.split('-').map(Number);
  if (!y || !m || !d) return new Date().getDay();
  return new Date(y, m - 1, d).getDay();
}

export function getIndonesianDayName(isoDate: string): string {
  const dayNames = [
    'Minggu',
    'Senin',
    'Selasa',
    'Rabu',
    'Kamis',
    'Jumat',
    'Sabtu',
  ];
  return dayNames[getDayOfWeekNumber(isoDate)] ?? '';
}

export function getCurrentTimeHHMM(): string {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

export function timeToMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  if (!Number.isFinite(h) || !Number.isFinite(m)) return 0;
  return h * 60 + m;
}

