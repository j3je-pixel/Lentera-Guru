import {
  Auth,
  createUserWithEmailAndPassword,
  getAuth,
  initializeAuth,
  inMemoryPersistence,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
} from 'firebase/auth';
import {
  doc,
  Firestore,
  getDocFromServer,
  getFirestore,
} from 'firebase/firestore';
import { deleteApp, initializeApp } from 'firebase/app';
import firebaseConfig from '../firebase-applet-config.json';
import { isGasEnvironment } from './services/gasClient';

export const BOOTSTRAP_ADMIN_EMAIL = 'j3je.prolinx@gmail.com';

const inGas = isGasEnvironment();
const app = inGas ? null : initializeApp(firebaseConfig);
export const db: Firestore = app
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : (null as unknown as Firestore);
export const auth: Auth = app ? getAuth(app) : (null as unknown as Auth);

export async function createSecondaryAuthUser(
  email: string,
  password: string,
  displayName: string,
  options?: { allowExistingAuthLink?: boolean }
): Promise<{ uid: string; email: string; relinked?: boolean }> {
  if (inGas) {
    throw new Error('Fungsi pembuatan akun Firebase hanya tersedia di mode web.');
  }
  const cleanEmail = email.trim();
  const cleanName = clampString(displayName, 120);
  const secondaryApp = initializeApp(
    firebaseConfig,
    `user-creator-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
  );
  // Use in-memory persistence so secondary user creation never touches IndexedDB or the admin's active session.
  const secondaryAuth = initializeAuth(secondaryApp, {
    persistence: inMemoryPersistence,
  });
  try {
    try {
      const cred = await createUserWithEmailAndPassword(
        secondaryAuth,
        cleanEmail,
        password
      );
      if (cleanName) {
        await updateProfile(cred.user, {
          displayName: cleanName,
        }).catch(() => undefined);
      }
      const createdEmail = cred.user.email || cleanEmail;
      const createdUid = cred.user.uid;
      await signOut(secondaryAuth).catch(() => undefined);
      return { uid: createdUid, email: createdEmail, relinked: false };
    } catch (createErr: unknown) {
      const errCode =
        typeof createErr === 'object' && createErr !== null && 'code' in createErr
          ? String((createErr as { code?: unknown }).code ?? '')
          : '';
      if (
        errCode === 'auth/email-already-in-use' &&
        options?.allowExistingAuthLink
      ) {
        try {
          const existingCred = await signInWithEmailAndPassword(
            secondaryAuth,
            cleanEmail,
            password
          );
          if (cleanName) {
            await updateProfile(existingCred.user, {
              displayName: cleanName,
            }).catch(() => undefined);
          }
          const linkedEmail = existingCred.user.email || cleanEmail;
          const linkedUid = existingCred.user.uid;
          await signOut(secondaryAuth).catch(() => undefined);
          return { uid: linkedUid, email: linkedEmail, relinked: true };
        } catch {
          const linkErr = new Error(
            'Email ini sudah terdaftar di Firebase Authentication (kemungkinan pernah dibuat atau dihapus dari daftar pengguna). Masukkan kata sandi lama akun tersebut untuk menautkan kembali, gunakan email lain, atau hapus akun lama di Firebase Console → Authentication.'
          ) as Error & { code?: string };
          linkErr.code = 'auth/existing-auth-password-mismatch';
          throw linkErr;
        }
      }
      throw createErr;
    }
  } finally {
    await deleteApp(secondaryApp).catch(() => undefined);
  }
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function parseFirestoreErrorMessage(
  error: unknown,
  fallback = 'Terjadi kesalahan saat mengakses database.'
): string {
  const raw = error instanceof Error ? error.message : String(error ?? '');
  if (!raw) return fallback;

  let innerMessage = raw;
  try {
    const parsed = JSON.parse(raw) as Partial<FirestoreErrorInfo>;
    if (parsed && typeof parsed.error === 'string') {
      innerMessage = parsed.error;
    }
  } catch {
    // Plain error message
  }

  const lower = innerMessage.toLowerCase();
  if (
    lower.includes('missing or insufficient permissions') ||
    lower.includes('permission-denied') ||
    lower.includes('permission denied')
  ) {
    return 'Akses database ditolak oleh aturan keamanan Firestore. Pastikan akun Anda terdaftar sebagai Administrator aktif dan coba muat ulang halaman.';
  }
  if (lower.includes('quota exceeded')) {
    return 'Kuota harian database Firestore tercapai. Silakan coba lagi besok atau tingkatkan paket Firebase.';
  }
  if (lower.includes('network') || lower.includes('offline')) {
    return 'Koneksi jaringan bermasalah. Periksa internet Anda lalu coba lagi.';
  }
  return innerMessage || fallback;
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid ?? null,
      email: auth.currentUser?.email ?? null,
      emailVerified: auth.currentUser?.emailVerified ?? null,
      isAnonymous: auth.currentUser?.isAnonymous ?? null,
      tenantId: auth.currentUser?.tenantId ?? null,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes('the client is offline')
    ) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

export function clampString(value: string, maxLength: number): string {
  return value.trim().slice(0, maxLength);
}

export function clampNumber(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, value));
}
