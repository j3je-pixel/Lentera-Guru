import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import {
  User,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  deleteField,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  BOOTSTRAP_ADMIN_EMAIL,
  auth,
  clampNumber,
  clampString,
  createSecondaryAuthUser,
  db,
  handleFirestoreError,
  OperationType,
  parseFirestoreErrorMessage,
  testConnection,
} from '../firebase';
import {
  callGas,
  GasBootstrapResponse,
  GasMutationResponse,
  GasSnapshot,
  isGasEnvironment,
} from '../services/gasClient';
import {
  AcademicGrade,
  AssessmentType,
  AttendanceStatus,
  AttitudeAssessment,
  AttitudePredicate,
  DEFAULT_LESSON_SLOTS,
  FIELD_LIMITS,
  Gender,
  GradingCategory,
  LessonSlot,
  SchoolClass,
  Student,
  StudentAttendance,
  Subject,
  TeachingJournal,
  TeachingSchedule,
  UserProfile,
  UserRole,
  UserStatus,
} from '../types';

export interface BulkStudentInput {
  nis: string;
  fullName: string;
  gender: Gender;
  className: string;
  classId?: string;
}

export type RestoreMode = 'merge' | 'replace';

export interface BackupDataPayload {
  metadata?: {
    appName?: string;
    school?: string;
    backupVersion?: string;
    exportedAt?: string;
    exportedBy?: {
      uid?: string | null;
      displayName?: string | null;
      email?: string | null;
    };
    totalRecords?: number;
    counts?: Record<string, number>;
  };
  data: {
    classes?: Partial<SchoolClass>[];
    subjects?: Partial<Subject>[];
    students?: Partial<Student>[];
    gradingCategories?: Partial<GradingCategory>[];
    academicGrades?: Partial<AcademicGrade>[];
    attitudeAssessments?: Partial<AttitudeAssessment>[];
    teachingJournals?: Partial<TeachingJournal>[];
    studentAttendance?: Partial<StudentAttendance>[];
    lessonSlots?: Partial<LessonSlot>[];
    teachingSchedules?: Partial<TeachingSchedule>[];
  };
}

export interface RestoreResult {
  restoredCounts: Record<string, number>;
  totalRestored: number;
  skippedOrphans: number;
}

interface AppContextValue {
  user: User | null;
  currentUserProfile: UserProfile | null;
  userProfiles: UserProfile[];
  isAdmin: boolean;
  authReady: boolean;
  profileReady: boolean;
  dataLoading: boolean;
  authError: string | null;
  storageMode: 'firebase' | 'gas';
  spreadsheetUrl: string | null;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  clearAuthError: () => void;
  signInWithAdmin: (email: string, password: string) => Promise<void>;
  registerTeacher: (input: {
    displayName: string;
    email: string;
    password: string;
    nip?: string;
    subjectSpecialty?: string;
  }) => Promise<void>;
  updateOwnProfile: (input: {
    displayName: string;
    nip?: string;
    subjectSpecialty?: string;
  }) => Promise<void>;
  createUserAccount: (input: {
    displayName: string;
    email: string;
    password: string;
    role: UserRole;
    nip?: string;
    subjectSpecialty?: string;
  }) => Promise<void>;
  updateManagedUser: (
    uid: string,
    input: {
      displayName: string;
      role: UserRole;
      status: UserStatus;
      nip?: string;
      subjectSpecialty?: string;
    }
  ) => Promise<void>;
  deleteManagedUserProfile: (uid: string) => Promise<void>;
  logout: () => Promise<void>;
  classes: SchoolClass[];
  subjects: Subject[];
  students: Student[];
  categories: GradingCategory[];
  grades: AcademicGrade[];
  attitudes: AttitudeAssessment[];
  journals: TeachingJournal[];
  attendances: StudentAttendance[];
  lessonSlots: LessonSlot[];
  teachingSchedules: TeachingSchedule[];

  addClass: (input: {
    name: string;
    gradeLevel: string;
    academicYear: string;
    homeroomTeacher?: string;
  }) => Promise<string>;
  updateClass: (
    id: string,
    input: {
      name: string;
      gradeLevel: string;
      academicYear: string;
      homeroomTeacher?: string;
    }
  ) => Promise<void>;
  deleteClass: (id: string) => Promise<void>;

  addSubject: (input: { code: string; name: string }) => Promise<string>;
  updateSubject: (
    id: string,
    input: { code: string; name: string }
  ) => Promise<void>;
  deleteSubject: (id: string) => Promise<void>;

  addStudent: (input: {
    nis: string;
    fullName: string;
    gender: Gender;
    classId: string;
  }) => Promise<string>;
  updateStudent: (
    id: string,
    input: {
      nis: string;
      fullName: string;
      gender: Gender;
      classId: string;
    }
  ) => Promise<void>;
  deleteStudent: (id: string) => Promise<void>;
  deleteStudentsBulk: (ids: string[]) => Promise<number>;
  bulkImportStudents: (
    rows: BulkStudentInput[],
    createMissingClasses: boolean,
    defaultAcademicYear: string
  ) => Promise<{ importedCount: number; createdClassesCount: number }>;

  addCategory: (input: {
    subjectId: string;
    name: string;
    weight: number;
  }) => Promise<string>;
  updateCategory: (
    id: string,
    input: {
      subjectId: string;
      name: string;
      weight: number;
    }
  ) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;

  saveBatchGrades: (
    entries: {
      existingId?: string;
      date: string;
      classId: string;
      subjectId: string;
      categoryId: string;
      studentId: string;
      score: number;
      assessmentType?: AssessmentType;
      chapter?: string;
      assessmentOrder?: number;
      assessmentLabel?: string;
      notes?: string;
    }[]
  ) => Promise<void>;
  updateGrade: (
    id: string,
    input: {
      date: string;
      classId: string;
      subjectId: string;
      categoryId: string;
      studentId: string;
      score: number;
      assessmentType?: AssessmentType;
      chapter?: string;
      assessmentOrder?: number;
      assessmentLabel?: string;
      notes?: string;
    }
  ) => Promise<void>;
  deleteGrade: (id: string) => Promise<void>;
  deleteClassesBulk: (ids: string[]) => Promise<number>;
  deleteSubjectsBulk: (ids: string[]) => Promise<number>;
  deleteGradesBulk: (ids: string[]) => Promise<number>;
  deleteAttitudesBulk: (ids: string[]) => Promise<number>;
  deleteJournalsBulk: (ids: string[]) => Promise<number>;

  saveBatchAttitudes: (
    entries: {
      existingId?: string;
      date: string;
      classId: string;
      subjectId: string;
      studentId: string;
      aspect: string;
      predicate: AttitudePredicate;
      notes?: string;
    }[]
  ) => Promise<void>;
  updateAttitude: (
    id: string,
    input: {
      date: string;
      classId: string;
      subjectId: string;
      studentId: string;
      aspect: string;
      predicate: AttitudePredicate;
      notes?: string;
    }
  ) => Promise<void>;
  deleteAttitude: (id: string) => Promise<void>;

  saveJournalWithAttendance: (
    input: {
      id?: string;
      date: string;
      lessonHours: string;
      classId: string;
      subjectId: string;
      topic: string;
      presentCount: number;
      sickCount: number;
      permissionCount: number;
      absentCount: number;
      reflection?: string;
    },
    studentStatuses: { studentId: string; status: AttendanceStatus }[]
  ) => Promise<void>;
  deleteJournal: (id: string) => Promise<void>;

  addLessonSlot: (input: {
    label: string;
    startTime: string;
    endTime: string;
    order: number;
  }) => Promise<string>;
  updateLessonSlot: (
    id: string,
    input: {
      label: string;
      startTime: string;
      endTime: string;
      order: number;
    }
  ) => Promise<void>;
  deleteLessonSlot: (id: string) => Promise<void>;
  seedDefaultLessonSlots: () => Promise<void>;

  addSchedule: (input: {
    dayOfWeek: number;
    slotId: string;
    classId: string;
    subjectId: string;
  }) => Promise<string>;
  updateSchedule: (
    id: string,
    input: {
      dayOfWeek: number;
      slotId: string;
      classId: string;
      subjectId: string;
    }
  ) => Promise<void>;
  deleteSchedule: (id: string) => Promise<void>;

  seedSampleData: () => Promise<void>;
  restoreBackupData: (
    payload: BackupDataPayload,
    mode: RestoreMode
  ) => Promise<RestoreResult>;
}

const AppContext = createContext<AppContextValue | null>(null);

function mapFirebaseAuthError(error: unknown, fallback: string): string {
  const code =
    typeof error === 'object' && error !== null && 'code' in error
      ? String((error as { code?: unknown }).code ?? '')
      : '';
  if (
    code === 'auth/invalid-credential' ||
    code === 'auth/wrong-password' ||
    code === 'auth/user-not-found'
  ) {
    return 'Email atau kata sandi tidak sesuai.';
  }
  if (code === 'auth/invalid-email') {
    return 'Format email tidak valid.';
  }
  if (code === 'auth/email-already-in-use') {
    return 'Email ini sudah terdaftar. Silakan gunakan email lain atau masuk ke akun tersebut.';
  }
  if (code === 'auth/weak-password') {
    return 'Kata sandi terlalu lemah. Gunakan minimal 6 karakter.';
  }
  if (code === 'auth/user-disabled') {
    return 'Akun ini sedang dinonaktifkan.';
  }
  if (code === 'auth/too-many-requests') {
    return 'Terlalu banyak percobaan. Tunggu beberapa saat lalu coba kembali.';
  }
  if (code === 'auth/existing-auth-password-mismatch') {
    return error instanceof Error && error.message ? error.message : fallback;
  }
  if (code === 'auth/operation-not-allowed' || code === 'auth/admin-restricted-operation') {
    return 'Metode login Email/Password belum diaktifkan di Firebase Console (Authentication → Sign-in method → Email/Password).';
  }
  if (code === 'auth/network-request-failed') {
    return 'Koneksi internet bermasalah. Periksa jaringan Anda lalu coba lagi.';
  }
  if (error instanceof Error && error.message) {
    return error.message;
  }
  return fallback;
}

async function runInBatches<T>(
  items: T[],
  chunkSize: number,
  buildBatch: (batch: ReturnType<typeof writeBatch>, item: T) => void
): Promise<void> {
  if (items.length === 0) return;
  const commits: Promise<void>[] = [];
  for (let i = 0; i < items.length; i += chunkSize) {
    const chunk = items.slice(i, i + chunkSize);
    const batch = writeBatch(db);
    for (const item of chunk) {
      buildBatch(batch, item);
    }
    commits.push(batch.commit());
  }
  await Promise.all(commits);
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const gasMode = isGasEnvironment();
  const storageMode: 'firebase' | 'gas' = gasMode ? 'gas' : 'firebase';

  const [user, setUser] = useState<User | null>(null);
  const [currentUserProfile, setCurrentUserProfile] =
    useState<UserProfile | null>(null);
  const [userProfiles, setUserProfiles] = useState<UserProfile[]>([]);
  const [authReady, setAuthReady] = useState(false);
  const [profileReady, setProfileReady] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [dataLoading, setDataLoading] = useState(true);
  const [spreadsheetUrl, setSpreadsheetUrl] = useState<string | null>(null);

  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try {
      return localStorage.getItem('lentera_theme') === 'light'
        ? 'light'
        : 'dark';
    } catch {
      return 'dark';
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem('lentera_theme', theme);
    } catch {
      // Ignore storage failures
    }
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  }, []);

  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [categories, setCategories] = useState<GradingCategory[]>([]);
  const [grades, setGrades] = useState<AcademicGrade[]>([]);
  const [attitudes, setAttitudes] = useState<AttitudeAssessment[]>([]);
  const [journals, setJournals] = useState<TeachingJournal[]>([]);
  const [attendances, setAttendances] = useState<StudentAttendance[]>([]);
  const [lessonSlots, setLessonSlots] = useState<LessonSlot[]>([]);
  const [teachingSchedules, setTeachingSchedules] = useState<
    TeachingSchedule[]
  >([]);

  const applyGasSnapshot = useCallback((snap: GasSnapshot) => {
    setClasses(
      [...(snap.classes ?? [])].sort((a, b) => a.name.localeCompare(b.name, 'id'))
    );
    setSubjects(
      [...(snap.subjects ?? [])].sort((a, b) =>
        a.name.localeCompare(b.name, 'id')
      )
    );
    setStudents(
      [...(snap.students ?? [])].sort((a, b) =>
        a.fullName.localeCompare(b.fullName, 'id')
      )
    );
    setCategories(
      [...(snap.categories ?? [])].sort((a, b) =>
        a.name.localeCompare(b.name, 'id')
      )
    );
    setGrades(
      [...(snap.grades ?? [])]
        .map((g) => ({
          ...g,
          chapter: g.chapter ? String(g.chapter).trim() : undefined,
          assessmentOrder:
            Number(g.assessmentOrder) >= 1
              ? Number(g.assessmentOrder)
              : undefined,
          assessmentLabel: g.assessmentLabel
            ? String(g.assessmentLabel).trim()
            : undefined,
        }))
        .sort((a, b) => b.date.localeCompare(a.date))
    );
    setAttitudes(
      [...(snap.attitudes ?? [])].sort((a, b) => b.date.localeCompare(a.date))
    );
    setJournals(
      [...(snap.journals ?? [])].sort((a, b) => b.date.localeCompare(a.date))
    );
    setAttendances([...(snap.attendances ?? [])]);
    setLessonSlots(
      [...(snap.lessonSlots ?? [])].sort(
        (a, b) => a.order - b.order || a.startTime.localeCompare(b.startTime)
      )
    );
    setTeachingSchedules([...(snap.teachingSchedules ?? [])]);
    if (snap.userProfile !== undefined) {
      setCurrentUserProfile(snap.userProfile ?? null);
    }
    if (snap.userProfiles !== undefined) {
      const sorted = [...snap.userProfiles].sort(
        (a, b) =>
          (a.role === 'admin' ? 0 : 1) - (b.role === 'admin' ? 0 : 1) ||
          a.displayName.localeCompare(b.displayName, 'id')
      );
      setUserProfiles(sorted);
    }
  }, []);

  useEffect(() => {
    if (gasMode) {
      let cancelled = false;
      setDataLoading(true);
      callGas<GasBootstrapResponse>('gasGetBootstrapData')
        .then((res) => {
          if (cancelled) return;
          const profileFromGas =
            res.userProfile || res.snapshot.userProfile || null;
          const syntheticUser = {
            uid: res.user.uid || 'gas-owner',
            email: res.user.email || 'guru@smpzaha.sch.id',
            displayName:
              profileFromGas?.displayName ||
              res.user.displayName ||
              'Guru Pengajar',
            photoURL: null,
          } as unknown as User;
          setUser(syntheticUser);
          setCurrentUserProfile(profileFromGas);
          setSpreadsheetUrl(res.spreadsheetUrl || null);
          applyGasSnapshot(res.snapshot);
          setAuthReady(true);
          setProfileReady(true);
          setDataLoading(false);
        })
        .catch((err: unknown) => {
          if (cancelled) return;
          setAuthError(
            err instanceof Error
              ? err.message
              : 'Gagal memuat data dari Google Spreadsheet.'
          );
          setAuthReady(true);
          setProfileReady(true);
          setDataLoading(false);
        });
      return () => {
        cancelled = true;
      };
    }

    void testConnection();
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthReady(true);
      if (!currentUser) {
        setCurrentUserProfile(null);
        setUserProfiles([]);
        setProfileReady(true);
        setClasses([]);
        setSubjects([]);
        setStudents([]);
        setCategories([]);
        setGrades([]);
        setAttitudes([]);
        setJournals([]);
        setAttendances([]);
        setLessonSlots([]);
        setTeachingSchedules([]);
        setDataLoading(false);
      } else {
        setProfileReady(false);
      }
    });
    return () => unsubscribe();
  }, [gasMode, applyGasSnapshot]);

  // Bootstrap and subscribe to current user's RBAC profile
  useEffect(() => {
    if (gasMode || !authReady || !user) {
      return;
    }

    let cancelled = false;
    let unsubProfile: (() => void) | null = null;
    const uid = user.uid;
    const emailLower = (user.email || '').trim().toLowerCase();

    const initProfile = async () => {
      try {
        const userRef = doc(db, 'users', uid);
        const adminRef = doc(db, 'admins', uid);

        const [userSnap, adminSnap] = await Promise.all([
          getDoc(userRef),
          getDoc(adminRef),
        ]);

        if (cancelled) return;

        let hasAdminGrant = adminSnap.exists();
        if (!hasAdminGrant && emailLower === BOOTSTRAP_ADMIN_EMAIL) {
          await setDoc(adminRef, {
            uid,
            email: clampString(
              user.email || BOOTSTRAP_ADMIN_EMAIL,
              FIELD_LIMITS.USER_EMAIL
            ),
            grantedBy: uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
          hasAdminGrant = true;
        }

        if (!userSnap.exists()) {
          const initialRole: UserRole =
            hasAdminGrant || emailLower === BOOTSTRAP_ADMIN_EMAIL
              ? 'admin'
              : 'guru';
          const fallbackName =
            clampString(
              user.displayName ||
                (user.email
                  ? user.email.split('@')[0].replace(/[._-]+/g, ' ')
                  : '') ||
                (initialRole === 'admin' ? 'Administrator' : 'Guru Pengajar'),
              FIELD_LIMITS.USER_DISPLAY_NAME
            ) || 'Pengguna';

          await setDoc(userRef, {
            uid,
            email: clampString(
              user.email || 'user@smpzaha.sch.id',
              FIELD_LIMITS.USER_EMAIL
            ),
            displayName: fallbackName,
            role: initialRole,
            status: 'active',
            nip: '',
            subjectSpecialty: '',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } else if (emailLower === BOOTSTRAP_ADMIN_EMAIL) {
          const existingData = userSnap.data();
          if (
            existingData?.role !== 'admin' ||
            existingData?.status !== 'active'
          ) {
            await updateDoc(userRef, {
              role: 'admin',
              status: 'active',
              updatedAt: serverTimestamp(),
            });
          }
        }

        if (cancelled) return;

        unsubProfile = onSnapshot(
          userRef,
          (snap) => {
            if (snap.exists()) {
              setCurrentUserProfile({
                id: snap.id,
                ...(snap.data() as Omit<UserProfile, 'id'>),
              });
            } else {
              setCurrentUserProfile(null);
            }
            setProfileReady(true);
          },
          (error) => handleFirestoreError(error, OperationType.GET, `users/${uid}`)
        );
      } catch (error) {
        if (!cancelled) {
          setProfileReady(true);
          handleFirestoreError(error, OperationType.WRITE, `users/${uid}`);
        }
      }
    };

    void initProfile();

    return () => {
      cancelled = true;
      if (unsubProfile) unsubProfile();
    };
  }, [gasMode, authReady, user]);

  // Admin listener for all registered users
  useEffect(() => {
    if (
      gasMode ||
      !authReady ||
      !user ||
      !profileReady ||
      currentUserProfile?.role !== 'admin' ||
      currentUserProfile?.status === 'inactive'
    ) {
      if (!gasMode) {
        setUserProfiles([]);
      }
      return;
    }

    const unsubAllUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => {
        const list = snap.docs
          .map((d) => ({
            id: d.id,
            ...(d.data() as Omit<UserProfile, 'id'>),
          }))
          .sort(
            (a, b) =>
              (a.role === 'admin' ? 0 : 1) - (b.role === 'admin' ? 0 : 1) ||
              a.displayName.localeCompare(b.displayName, 'id')
          );
        setUserProfiles(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'users')
    );

    return () => unsubAllUsers();
  }, [
    gasMode,
    authReady,
    user,
    profileReady,
    currentUserProfile?.role,
    currentUserProfile?.status,
  ]);

  useEffect(() => {
    if (
      gasMode ||
      !authReady ||
      !user ||
      !profileReady ||
      currentUserProfile?.status === 'inactive'
    ) {
      if (!gasMode && currentUserProfile?.status === 'inactive') {
        setDataLoading(false);
      }
      return;
    }

    setDataLoading(true);
    let loadedCollections = 0;
    const markLoaded = () => {
      loadedCollections += 1;
      if (loadedCollections >= 10) {
        setDataLoading(false);
      }
    };

    const uid = user.uid;

    const unsubClasses = onSnapshot(
      query(collection(db, 'classes'), where('ownerId', '==', uid)),
      (snap) => {
        const list = snap.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<SchoolClass, 'id'>) }))
          .sort((a, b) => a.name.localeCompare(b.name, 'id'));
        setClasses(list);
        markLoaded();
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'classes')
    );

    const unsubSubjects = onSnapshot(
      query(collection(db, 'subjects'), where('ownerId', '==', uid)),
      (snap) => {
        const list = snap.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<Subject, 'id'>) }))
          .sort((a, b) => a.name.localeCompare(b.name, 'id'));
        setSubjects(list);
        markLoaded();
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'subjects')
    );

    const unsubStudents = onSnapshot(
      query(collection(db, 'students'), where('ownerId', '==', uid)),
      (snap) => {
        const list = snap.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<Student, 'id'>) }))
          .sort((a, b) => a.fullName.localeCompare(b.fullName, 'id'));
        setStudents(list);
        markLoaded();
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'students')
    );

    const unsubCategories = onSnapshot(
      query(collection(db, 'gradingCategories'), where('ownerId', '==', uid)),
      (snap) => {
        const list = snap.docs
          .map((d) => ({
            id: d.id,
            ...(d.data() as Omit<GradingCategory, 'id'>),
          }))
          .sort((a, b) => a.name.localeCompare(b.name, 'id'));
        setCategories(list);
        markLoaded();
      },
      (error) =>
        handleFirestoreError(error, OperationType.LIST, 'gradingCategories')
    );

    const unsubGrades = onSnapshot(
      query(collection(db, 'academicGrades'), where('ownerId', '==', uid)),
      (snap) => {
        const list = snap.docs
          .map((d) => ({
            id: d.id,
            ...(d.data() as Omit<AcademicGrade, 'id'>),
          }))
          .sort((a, b) => b.date.localeCompare(a.date));
        setGrades(list);
        markLoaded();
      },
      (error) =>
        handleFirestoreError(error, OperationType.LIST, 'academicGrades')
    );

    const unsubAttitudes = onSnapshot(
      query(collection(db, 'attitudeAssessments'), where('ownerId', '==', uid)),
      (snap) => {
        const list = snap.docs
          .map((d) => ({
            id: d.id,
            ...(d.data() as Omit<AttitudeAssessment, 'id'>),
          }))
          .sort((a, b) => b.date.localeCompare(a.date));
        setAttitudes(list);
        markLoaded();
      },
      (error) =>
        handleFirestoreError(error, OperationType.LIST, 'attitudeAssessments')
    );

    const unsubJournals = onSnapshot(
      query(collection(db, 'teachingJournals'), where('ownerId', '==', uid)),
      (snap) => {
        const list = snap.docs
          .map((d) => ({
            id: d.id,
            ...(d.data() as Omit<TeachingJournal, 'id'>),
          }))
          .sort((a, b) => b.date.localeCompare(a.date));
        setJournals(list);
        markLoaded();
      },
      (error) =>
        handleFirestoreError(error, OperationType.LIST, 'teachingJournals')
    );

    const unsubAttendances = onSnapshot(
      query(collection(db, 'studentAttendance'), where('ownerId', '==', uid)),
      (snap) => {
        const list = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<StudentAttendance, 'id'>),
        }));
        setAttendances(list);
        markLoaded();
      },
      (error) =>
        handleFirestoreError(error, OperationType.LIST, 'studentAttendance')
    );

    const unsubLessonSlots = onSnapshot(
      query(collection(db, 'lessonSlots'), where('ownerId', '==', uid)),
      (snap) => {
        const list = snap.docs
          .map((d) => ({
            id: d.id,
            ...(d.data() as Omit<LessonSlot, 'id'>),
          }))
          .sort(
            (a, b) =>
              a.order - b.order || a.startTime.localeCompare(b.startTime)
          );
        setLessonSlots(list);
        markLoaded();
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'lessonSlots')
    );

    const unsubSchedules = onSnapshot(
      query(collection(db, 'teachingSchedules'), where('ownerId', '==', uid)),
      (snap) => {
        const list = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<TeachingSchedule, 'id'>),
        }));
        setTeachingSchedules(list);
        markLoaded();
      },
      (error) =>
        handleFirestoreError(error, OperationType.LIST, 'teachingSchedules')
    );

    return () => {
      unsubClasses();
      unsubSubjects();
      unsubStudents();
      unsubCategories();
      unsubGrades();
      unsubAttitudes();
      unsubJournals();
      unsubAttendances();
      unsubLessonSlots();
      unsubSchedules();
    };
  }, [
    gasMode,
    authReady,
    user,
    profileReady,
    currentUserProfile?.status,
  ]);

  const clearAuthError = useCallback(() => {
    setAuthError(null);
  }, []);

  const signInWithAdmin = useCallback(
    async (email: string, password: string) => {
      if (gasMode) return;
      setAuthError(null);
      const cleanEmail = email.trim();
      if (!cleanEmail || !password) {
        setAuthError('Email dan kata sandi wajib diisi.');
        return;
      }
      try {
        await signInWithEmailAndPassword(auth, cleanEmail, password);
      } catch (error: unknown) {
        setAuthError(mapFirebaseAuthError(error, 'Gagal masuk ke akun.'));
      }
    },
    [gasMode]
  );

  const registerTeacher = useCallback(
    async (input: {
      displayName: string;
      email: string;
      password: string;
      nip?: string;
      subjectSpecialty?: string;
    }) => {
      if (gasMode) return;
      setAuthError(null);
      const cleanName = clampString(
        input.displayName,
        FIELD_LIMITS.USER_DISPLAY_NAME
      );
      const cleanEmail = clampString(input.email, FIELD_LIMITS.USER_EMAIL);
      if (!cleanName || !cleanEmail || !input.password) {
        setAuthError('Nama lengkap, email, dan kata sandi wajib diisi.');
        return;
      }
      if (input.password.length < 6) {
        setAuthError('Kata sandi minimal harus 6 karakter.');
        return;
      }
      if (cleanEmail.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL) {
        setAuthError(
          'Email ini dicadangkan untuk akun Administrator utama sekolah.'
        );
        return;
      }
      try {
        const cred = await createUserWithEmailAndPassword(
          auth,
          cleanEmail,
          input.password
        );
        await updateProfile(cred.user, { displayName: cleanName });
        await setDoc(doc(db, 'users', cred.user.uid), {
          uid: cred.user.uid,
          email: clampString(
            cred.user.email || cleanEmail,
            FIELD_LIMITS.USER_EMAIL
          ),
          displayName: cleanName,
          role: 'guru',
          status: 'active',
          nip: clampString(input.nip ?? '', FIELD_LIMITS.USER_NIP),
          subjectSpecialty: clampString(
            input.subjectSpecialty ?? '',
            FIELD_LIMITS.USER_SPECIALTY
          ),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (error: unknown) {
        setAuthError(
          mapFirebaseAuthError(error, 'Gagal mendaftarkan akun guru.')
        );
      }
    },
    [gasMode]
  );

  const logout = useCallback(async () => {
    if (gasMode) return;
    setAuthError(null);
    await signOut(auth);
  }, [gasMode]);

  const requireUid = useCallback(() => {
    if (!user) throw new Error('Pengguna belum masuk.');
    return user.uid;
  }, [user]);

  const isAdmin = currentUserProfile?.role === 'admin';

  const updateOwnProfile = useCallback(
    async (input: {
      displayName: string;
      nip?: string;
      subjectSpecialty?: string;
    }) => {
      const cleanName =
        clampString(input.displayName, FIELD_LIMITS.USER_DISPLAY_NAME) ||
        'Pengguna';
      const cleanNip = clampString(input.nip ?? '', FIELD_LIMITS.USER_NIP);
      const cleanSpecialty = clampString(
        input.subjectSpecialty ?? '',
        FIELD_LIMITS.USER_SPECIALTY
      );

      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasUpdateOwnProfile', {
          displayName: cleanName,
          nip: cleanNip,
          subjectSpecialty: cleanSpecialty,
        });
        applyGasSnapshot(res.snapshot);
        return;
      }

      const uid = requireUid();
      if (auth.currentUser) {
        await updateProfile(auth.currentUser, { displayName: cleanName });
      }
      try {
        await updateDoc(doc(db, 'users', uid), {
          displayName: cleanName,
          nip: cleanNip,
          subjectSpecialty: cleanSpecialty,
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const createUserAccount = useCallback(
    async (input: {
      displayName: string;
      email: string;
      password: string;
      role: UserRole;
      nip?: string;
      subjectSpecialty?: string;
    }) => {
      if (!isAdmin) {
        throw new Error('Hanya Administrator yang dapat menambah akun pengguna.');
      }
      const cleanName = clampString(
        input.displayName,
        FIELD_LIMITS.USER_DISPLAY_NAME
      );
      const cleanEmail = clampString(input.email, FIELD_LIMITS.USER_EMAIL);
      const cleanNip = clampString(input.nip ?? '', FIELD_LIMITS.USER_NIP);
      const cleanSpecialty = clampString(
        input.subjectSpecialty ?? '',
        FIELD_LIMITS.USER_SPECIALTY
      );

      if (!cleanName || !cleanEmail) {
        throw new Error('Nama lengkap dan email pengguna wajib diisi.');
      }

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
        throw new Error('Format alamat email tidak valid.');
      }

      const duplicateProfile = userProfiles.find(
        (u) => u.email.trim().toLowerCase() === cleanEmail.toLowerCase()
      );
      if (duplicateProfile) {
        throw new Error(
          `Email "${cleanEmail}" sudah terdaftar pada daftar pengguna (${duplicateProfile.displayName}). Gunakan email lain atau edit pengguna tersebut di tabel.`
        );
      }

      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasAdminCreateUser', {
          displayName: cleanName,
          email: cleanEmail,
          role: input.role,
          nip: cleanNip,
          subjectSpecialty: cleanSpecialty,
        });
        applyGasSnapshot(res.snapshot);
        return;
      }

      const adminUid = requireUid();
      if (!input.password || input.password.length < 6) {
        throw new Error('Kata sandi awal minimal 6 karakter.');
      }

      let created: { uid: string; email: string; relinked?: boolean };
      try {
        created = await createSecondaryAuthUser(
          cleanEmail,
          input.password,
          cleanName,
          { allowExistingAuthLink: true }
        );
      } catch (error) {
        throw new Error(
          mapFirebaseAuthError(error, 'Gagal membuat akun pengguna baru.')
        );
      }

      try {
        const batch = writeBatch(db);
        const normalizedEmail = clampString(
          created.email || cleanEmail,
          FIELD_LIMITS.USER_EMAIL
        );

        batch.set(doc(db, 'users', created.uid), {
          uid: created.uid,
          email: normalizedEmail,
          displayName: cleanName,
          role: input.role,
          status: 'active',
          nip: cleanNip,
          subjectSpecialty: cleanSpecialty,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        if (input.role === 'admin') {
          batch.set(doc(db, 'admins', created.uid), {
            uid: created.uid,
            email: normalizedEmail,
            grantedBy: adminUid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }

        await batch.commit();
      } catch (error) {
        try {
          handleFirestoreError(
            error,
            OperationType.CREATE,
            `users/${created.uid}`
          );
        } catch (wrappedErr) {
          throw new Error(
            parseFirestoreErrorMessage(
              wrappedErr,
              'Gagal menyimpan profil pengguna baru ke database.'
            )
          );
        }
      }
    },
    [applyGasSnapshot, gasMode, isAdmin, requireUid, userProfiles]
  );

  const updateManagedUser = useCallback(
    async (
      targetUid: string,
      input: {
        displayName: string;
        role: UserRole;
        status: UserStatus;
        nip?: string;
        subjectSpecialty?: string;
      }
    ) => {
      if (!isAdmin) {
        throw new Error('Hanya Administrator yang dapat mengubah data pengguna.');
      }
      const adminUid = requireUid();
      if (
        targetUid === adminUid &&
        (input.role !== 'admin' || input.status !== 'active')
      ) {
        throw new Error(
          'Anda tidak dapat mencabut hak Administrator atau menonaktifkan akun Anda sendiri.'
        );
      }

      const cleanName =
        clampString(input.displayName, FIELD_LIMITS.USER_DISPLAY_NAME) ||
        'Pengguna';
      const cleanNip = clampString(input.nip ?? '', FIELD_LIMITS.USER_NIP);
      const cleanSpecialty = clampString(
        input.subjectSpecialty ?? '',
        FIELD_LIMITS.USER_SPECIALTY
      );

      if (gasMode) {
        const res = await callGas<GasMutationResponse>(
          'gasAdminUpdateUser',
          targetUid,
          {
            displayName: cleanName,
            role: input.role,
            status: input.status,
            nip: cleanNip,
            subjectSpecialty: cleanSpecialty,
          }
        );
        applyGasSnapshot(res.snapshot);
        return;
      }

      const targetProfile = userProfiles.find((u) => u.uid === targetUid);
      try {
        await updateDoc(doc(db, 'users', targetUid), {
          displayName: cleanName,
          role: input.role,
          status: input.status,
          nip: cleanNip,
          subjectSpecialty: cleanSpecialty,
          updatedAt: serverTimestamp(),
        });

        const adminDocRef = doc(db, 'admins', targetUid);
        const existingAdminDoc = await getDoc(adminDocRef);

        if (input.role === 'admin' && !existingAdminDoc.exists()) {
          await setDoc(adminDocRef, {
            uid: targetUid,
            email: clampString(
              targetProfile?.email || 'admin@smpzaha.sch.id',
              FIELD_LIMITS.USER_EMAIL
            ),
            grantedBy: adminUid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } else if (input.role === 'guru' && existingAdminDoc.exists()) {
          await deleteDoc(adminDocRef);
        }
      } catch (error) {
        try {
          handleFirestoreError(
            error,
            OperationType.UPDATE,
            `users/${targetUid}`
          );
        } catch (wrappedErr) {
          throw new Error(
            parseFirestoreErrorMessage(
              wrappedErr,
              'Gagal memperbarui data pengguna di database.'
            )
          );
        }
      }
    },
    [applyGasSnapshot, gasMode, isAdmin, requireUid, userProfiles]
  );

  const deleteManagedUserProfile = useCallback(
    async (targetUid: string) => {
      if (!isAdmin) {
        throw new Error('Hanya Administrator yang dapat menghapus profil pengguna.');
      }
      const adminUid = requireUid();
      if (targetUid === adminUid) {
        throw new Error('Anda tidak dapat menghapus profil akun Anda sendiri.');
      }

      if (gasMode) {
        const res = await callGas<GasMutationResponse>(
          'gasAdminDeleteUser',
          targetUid
        );
        applyGasSnapshot(res.snapshot);
        return;
      }

      try {
        const adminDocRef = doc(db, 'admins', targetUid);
        const adminSnap = await getDoc(adminDocRef);
        if (adminSnap.exists()) {
          await deleteDoc(adminDocRef);
        }
        await deleteDoc(doc(db, 'users', targetUid));
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.DELETE,
          `users/${targetUid}`
        );
      }
    },
    [applyGasSnapshot, gasMode, isAdmin, requireUid]
  );

  const addClass = useCallback(
    async (input: {
      name: string;
      gradeLevel: string;
      academicYear: string;
      homeroomTeacher?: string;
    }) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse<string>>('gasAddClass', {
          name: clampString(input.name, FIELD_LIMITS.CLASS_NAME),
          gradeLevel: clampString(input.gradeLevel, FIELD_LIMITS.GRADE_LEVEL),
          academicYear: clampString(
            input.academicYear,
            FIELD_LIMITS.ACADEMIC_YEAR
          ),
          homeroomTeacher: clampString(
            input.homeroomTeacher ?? '',
            FIELD_LIMITS.HOMEROOM_TEACHER
          ),
        });
        applyGasSnapshot(res.snapshot);
        return res.result;
      }
      const uid = requireUid();
      const ref = doc(collection(db, 'classes'));
      try {
        await setDoc(ref, {
          ownerId: uid,
          name: clampString(input.name, FIELD_LIMITS.CLASS_NAME),
          gradeLevel: clampString(input.gradeLevel, FIELD_LIMITS.GRADE_LEVEL),
          academicYear: clampString(
            input.academicYear,
            FIELD_LIMITS.ACADEMIC_YEAR
          ),
          homeroomTeacher: clampString(
            input.homeroomTeacher ?? '',
            FIELD_LIMITS.HOMEROOM_TEACHER
          ),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        return ref.id;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `classes/${ref.id}`);
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const updateClass = useCallback(
    async (
      id: string,
      input: {
        name: string;
        gradeLevel: string;
        academicYear: string;
        homeroomTeacher?: string;
      }
    ) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>(
          'gasUpdateClass',
          id,
          {
            name: clampString(input.name, FIELD_LIMITS.CLASS_NAME),
            gradeLevel: clampString(input.gradeLevel, FIELD_LIMITS.GRADE_LEVEL),
            academicYear: clampString(
              input.academicYear,
              FIELD_LIMITS.ACADEMIC_YEAR
            ),
            homeroomTeacher: clampString(
              input.homeroomTeacher ?? '',
              FIELD_LIMITS.HOMEROOM_TEACHER
            ),
          }
        );
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      const ref = doc(db, 'classes', id);
      try {
        await updateDoc(ref, {
          name: clampString(input.name, FIELD_LIMITS.CLASS_NAME),
          gradeLevel: clampString(input.gradeLevel, FIELD_LIMITS.GRADE_LEVEL),
          academicYear: clampString(
            input.academicYear,
            FIELD_LIMITS.ACADEMIC_YEAR
          ),
          homeroomTeacher: clampString(
            input.homeroomTeacher ?? '',
            FIELD_LIMITS.HOMEROOM_TEACHER
          ),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `classes/${id}`);
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteClass = useCallback(
    async (id: string) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasDeleteClass', id);
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await deleteDoc(doc(db, 'classes', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `classes/${id}`);
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const addSubject = useCallback(
    async (input: { code: string; name: string }) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse<string>>(
          'gasAddSubject',
          {
            code: clampString(input.code, FIELD_LIMITS.SUBJECT_CODE).toUpperCase(),
            name: clampString(input.name, FIELD_LIMITS.SUBJECT_NAME),
          }
        );
        applyGasSnapshot(res.snapshot);
        return res.result;
      }
      const uid = requireUid();
      const ref = doc(collection(db, 'subjects'));
      try {
        await setDoc(ref, {
          ownerId: uid,
          code: clampString(input.code, FIELD_LIMITS.SUBJECT_CODE).toUpperCase(),
          name: clampString(input.name, FIELD_LIMITS.SUBJECT_NAME),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        return ref.id;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `subjects/${ref.id}`);
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const updateSubject = useCallback(
    async (id: string, input: { code: string; name: string }) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasUpdateSubject', id, {
          code: clampString(input.code, FIELD_LIMITS.SUBJECT_CODE).toUpperCase(),
          name: clampString(input.name, FIELD_LIMITS.SUBJECT_NAME),
        });
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await updateDoc(doc(db, 'subjects', id), {
          code: clampString(input.code, FIELD_LIMITS.SUBJECT_CODE).toUpperCase(),
          name: clampString(input.name, FIELD_LIMITS.SUBJECT_NAME),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `subjects/${id}`);
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteSubject = useCallback(
    async (id: string) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasDeleteSubject', id);
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await deleteDoc(doc(db, 'subjects', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `subjects/${id}`);
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const addStudent = useCallback(
    async (input: {
      nis: string;
      fullName: string;
      gender: Gender;
      classId: string;
    }) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse<string>>(
          'gasAddStudent',
          {
            nis: clampString(input.nis, FIELD_LIMITS.STUDENT_NIS),
            fullName: clampString(input.fullName, FIELD_LIMITS.STUDENT_NAME),
            gender: input.gender,
            classId: input.classId,
          }
        );
        applyGasSnapshot(res.snapshot);
        return res.result;
      }
      const uid = requireUid();
      const ref = doc(collection(db, 'students'));
      try {
        await setDoc(ref, {
          ownerId: uid,
          nis: clampString(input.nis, FIELD_LIMITS.STUDENT_NIS),
          fullName: clampString(input.fullName, FIELD_LIMITS.STUDENT_NAME),
          gender: input.gender,
          classId: input.classId,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        return ref.id;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `students/${ref.id}`);
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const updateStudent = useCallback(
    async (
      id: string,
      input: {
        nis: string;
        fullName: string;
        gender: Gender;
        classId: string;
      }
    ) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasUpdateStudent', id, {
          nis: clampString(input.nis, FIELD_LIMITS.STUDENT_NIS),
          fullName: clampString(input.fullName, FIELD_LIMITS.STUDENT_NAME),
          gender: input.gender,
          classId: input.classId,
        });
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await updateDoc(doc(db, 'students', id), {
          nis: clampString(input.nis, FIELD_LIMITS.STUDENT_NIS),
          fullName: clampString(input.fullName, FIELD_LIMITS.STUDENT_NAME),
          gender: input.gender,
          classId: input.classId,
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `students/${id}`);
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteStudent = useCallback(
    async (id: string) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasDeleteStudent', id);
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await deleteDoc(doc(db, 'students', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `students/${id}`);
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteStudentsBulk = useCallback(
    async (ids: string[]) => {
      const uniqueIds = Array.from(new Set(ids)).filter(Boolean);
      if (uniqueIds.length === 0) return 0;
      if (gasMode) {
        const res = await callGas<GasMutationResponse<number>>(
          'gasDeleteStudentsBulk',
          uniqueIds
        );
        applyGasSnapshot(res.snapshot);
        return res.result ?? uniqueIds.length;
      }
      requireUid();
      try {
        await runInBatches(uniqueIds, 200, (batch, id) => {
          batch.delete(doc(db, 'students', id));
        });
        return uniqueIds.length;
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, 'students');
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const bulkImportStudents = useCallback(
    async (
      rows: BulkStudentInput[],
      createMissingClasses: boolean,
      defaultAcademicYear: string
    ) => {
      if (gasMode) {
        const res = await callGas<
          GasMutationResponse<{
            importedCount: number;
            createdClassesCount: number;
          }>
        >(
          'gasBulkImportStudents',
          rows.map((r) => ({
            nis: clampString(r.nis, FIELD_LIMITS.STUDENT_NIS),
            fullName: clampString(r.fullName, FIELD_LIMITS.STUDENT_NAME),
            gender: r.gender,
            className: clampString(r.className, FIELD_LIMITS.CLASS_NAME),
            classId: r.classId,
          })),
          createMissingClasses,
          clampString(defaultAcademicYear || '2026/2027', FIELD_LIMITS.ACADEMIC_YEAR)
        );
        applyGasSnapshot(res.snapshot);
        return res.result;
      }
      const uid = requireUid();
      const classMap = new Map<string, string>();
      for (const c of classes) {
        classMap.set(c.name.trim().toLowerCase(), c.id);
      }

      let createdClassesCount = 0;
      const missingClassNames = new Set<string>();

      for (const row of rows) {
        if (!row.classId) {
          const key = row.className.trim().toLowerCase();
          if (key && !classMap.has(key)) {
            missingClassNames.add(row.className.trim());
          }
        }
      }

      if (createMissingClasses && missingClassNames.size > 0) {
        const missingList = Array.from(missingClassNames).map((className) => {
          const newClassRef = doc(collection(db, 'classes'));
          classMap.set(className.toLowerCase(), newClassRef.id);
          return { className, newClassRef };
        });
        createdClassesCount = missingList.length;
        try {
          await runInBatches(missingList, 200, (batch, { className, newClassRef }) => {
            const guessLevel = className.split(' ')[0] || 'Umum';
            batch.set(newClassRef, {
              ownerId: uid,
              name: clampString(className, FIELD_LIMITS.CLASS_NAME),
              gradeLevel: clampString(
                `Tingkat ${guessLevel}`,
                FIELD_LIMITS.GRADE_LEVEL
              ),
              academicYear: clampString(
                defaultAcademicYear || '2026/2027',
                FIELD_LIMITS.ACADEMIC_YEAR
              ),
              homeroomTeacher: '',
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, 'classes');
        }
      }

      const validRows = rows
        .map((row) => {
          const resolvedClassId =
            row.classId || classMap.get(row.className.trim().toLowerCase());
          return resolvedClassId ? { ...row, classId: resolvedClassId } : null;
        })
        .filter(
          (r): r is BulkStudentInput & { classId: string } => r !== null
        );

      // Each student write triggers isClassOwned (2 rule lookups) -> max 8 per batch (16 <= 20)
      try {
        await runInBatches(validRows, 8, (batch, item) => {
          const ref = doc(collection(db, 'students'));
          batch.set(ref, {
            ownerId: uid,
            nis: clampString(item.nis, FIELD_LIMITS.STUDENT_NIS),
            fullName: clampString(item.fullName, FIELD_LIMITS.STUDENT_NAME),
            gender: item.gender,
            classId: item.classId,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'students');
      }

      return {
        importedCount: validRows.length,
        createdClassesCount,
      };
    },
    [applyGasSnapshot, classes, gasMode, requireUid]
  );

  const addCategory = useCallback(
    async (input: {
      subjectId: string;
      name: string;
      weight: number;
    }) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse<string>>(
          'gasAddCategory',
          {
            subjectId: input.subjectId,
            name: clampString(input.name, FIELD_LIMITS.CATEGORY_NAME),
            weight: clampNumber(input.weight, 0, 100),
          }
        );
        applyGasSnapshot(res.snapshot);
        return res.result;
      }
      const uid = requireUid();
      const ref = doc(collection(db, 'gradingCategories'));
      try {
        await setDoc(ref, {
          ownerId: uid,
          subjectId: input.subjectId,
          name: clampString(input.name, FIELD_LIMITS.CATEGORY_NAME),
          weight: clampNumber(input.weight, 0, 100),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        return ref.id;
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.CREATE,
          `gradingCategories/${ref.id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const updateCategory = useCallback(
    async (
      id: string,
      input: {
        subjectId: string;
        name: string;
        weight: number;
      }
    ) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasUpdateCategory', id, {
          subjectId: input.subjectId,
          name: clampString(input.name, FIELD_LIMITS.CATEGORY_NAME),
          weight: clampNumber(input.weight, 0, 100),
        });
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await updateDoc(doc(db, 'gradingCategories', id), {
          classId: deleteField(),
          subjectId: input.subjectId,
          name: clampString(input.name, FIELD_LIMITS.CATEGORY_NAME),
          weight: clampNumber(input.weight, 0, 100),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.UPDATE,
          `gradingCategories/${id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteCategory = useCallback(
    async (id: string) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasDeleteCategory', id);
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await deleteDoc(doc(db, 'gradingCategories', id));
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.DELETE,
          `gradingCategories/${id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const saveBatchGrades = useCallback(
    async (
      entries: {
        existingId?: string;
        date: string;
        classId: string;
        subjectId: string;
        categoryId: string;
        studentId: string;
        score: number;
        assessmentType?: AssessmentType;
        chapter?: string;
        assessmentOrder?: number;
        assessmentLabel?: string;
        notes?: string;
      }[]
    ) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>(
          'gasSaveBatchGrades',
          entries.map((e) => {
            const cleanType: AssessmentType | undefined =
              e.assessmentType === 'sumatif'
                ? 'sumatif'
                : e.assessmentType === 'formatif'
                ? 'formatif'
                : undefined;
            const cleanChapter = clampString(
              e.chapter ?? '',
              FIELD_LIMITS.GRADE_CHAPTER
            );
            const cleanOrder =
              typeof e.assessmentOrder === 'number' &&
              Number.isFinite(e.assessmentOrder) &&
              e.assessmentOrder >= 1
                ? clampNumber(Math.round(e.assessmentOrder), 1, 20)
                : undefined;
            const cleanLabel = clampString(
              e.assessmentLabel ?? '',
              FIELD_LIMITS.GRADE_ASSESSMENT_LABEL
            );
            return {
              ...e,
              score: clampNumber(e.score, 0, 100),
              assessmentType: cleanType ?? '',
              chapter: cleanChapter,
              assessmentOrder: cleanOrder,
              assessmentLabel: cleanLabel,
              notes: clampString(e.notes ?? '', FIELD_LIMITS.GRADE_NOTES),
            };
          })
        );
        applyGasSnapshot(res.snapshot);
        return;
      }
      const uid = requireUid();
      // Each grade write triggers 4 ownership checks (8 rule lookups) -> max 2 per batch (16 <= 20)
      try {
        await runInBatches(entries, 2, (batch, entry) => {
          const cleanType: AssessmentType | undefined =
            entry.assessmentType === 'sumatif'
              ? 'sumatif'
              : entry.assessmentType === 'formatif'
              ? 'formatif'
              : undefined;
          const cleanChapter = clampString(
            entry.chapter ?? '',
            FIELD_LIMITS.GRADE_CHAPTER
          );
          const cleanOrder =
            typeof entry.assessmentOrder === 'number' &&
            Number.isFinite(entry.assessmentOrder) &&
            entry.assessmentOrder >= 1
              ? clampNumber(Math.round(entry.assessmentOrder), 1, 20)
              : undefined;
          const cleanLabel = clampString(
            entry.assessmentLabel ?? '',
            FIELD_LIMITS.GRADE_ASSESSMENT_LABEL
          );

          if (entry.existingId) {
            batch.update(doc(db, 'academicGrades', entry.existingId), {
              date: entry.date,
              classId: entry.classId,
              subjectId: entry.subjectId,
              categoryId: entry.categoryId,
              studentId: entry.studentId,
              score: clampNumber(entry.score, 0, 100),
              assessmentType: cleanType ? cleanType : deleteField(),
              chapter: cleanChapter ? cleanChapter : deleteField(),
              assessmentOrder: cleanOrder ? cleanOrder : deleteField(),
              assessmentLabel: cleanLabel ? cleanLabel : deleteField(),
              notes: clampString(entry.notes ?? '', FIELD_LIMITS.GRADE_NOTES),
              updatedAt: serverTimestamp(),
            });
          } else {
            const ref = doc(collection(db, 'academicGrades'));
            const payload: Record<string, unknown> = {
              ownerId: uid,
              date: entry.date,
              classId: entry.classId,
              subjectId: entry.subjectId,
              categoryId: entry.categoryId,
              studentId: entry.studentId,
              score: clampNumber(entry.score, 0, 100),
              notes: clampString(entry.notes ?? '', FIELD_LIMITS.GRADE_NOTES),
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            };
            if (cleanType) payload.assessmentType = cleanType;
            if (cleanChapter) payload.chapter = cleanChapter;
            if (cleanOrder) payload.assessmentOrder = cleanOrder;
            if (cleanLabel) payload.assessmentLabel = cleanLabel;
            batch.set(ref, payload);
          }
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'academicGrades');
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const updateGrade = useCallback(
    async (
      id: string,
      input: {
        date: string;
        classId: string;
        subjectId: string;
        categoryId: string;
        studentId: string;
        score: number;
        assessmentType?: AssessmentType;
        chapter?: string;
        assessmentOrder?: number;
        assessmentLabel?: string;
        notes?: string;
      }
    ) => {
      const cleanType: AssessmentType | undefined =
        input.assessmentType === 'sumatif'
          ? 'sumatif'
          : input.assessmentType === 'formatif'
          ? 'formatif'
          : undefined;
      const cleanChapter = clampString(
        input.chapter ?? '',
        FIELD_LIMITS.GRADE_CHAPTER
      );
      const cleanOrder =
        typeof input.assessmentOrder === 'number' &&
        Number.isFinite(input.assessmentOrder) &&
        input.assessmentOrder >= 1
          ? clampNumber(Math.round(input.assessmentOrder), 1, 20)
          : undefined;
      const cleanLabel = clampString(
        input.assessmentLabel ?? '',
        FIELD_LIMITS.GRADE_ASSESSMENT_LABEL
      );

      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasUpdateGrade', id, {
          ...input,
          score: clampNumber(input.score, 0, 100),
          assessmentType: cleanType ?? '',
          chapter: cleanChapter,
          assessmentOrder: cleanOrder,
          assessmentLabel: cleanLabel,
          notes: clampString(input.notes ?? '', FIELD_LIMITS.GRADE_NOTES),
        });
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await updateDoc(doc(db, 'academicGrades', id), {
          date: input.date,
          classId: input.classId,
          subjectId: input.subjectId,
          categoryId: input.categoryId,
          studentId: input.studentId,
          score: clampNumber(input.score, 0, 100),
          assessmentType: cleanType ? cleanType : deleteField(),
          chapter: cleanChapter ? cleanChapter : deleteField(),
          assessmentOrder: cleanOrder ? cleanOrder : deleteField(),
          assessmentLabel: cleanLabel ? cleanLabel : deleteField(),
          notes: clampString(input.notes ?? '', FIELD_LIMITS.GRADE_NOTES),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.UPDATE,
          `academicGrades/${id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteGrade = useCallback(
    async (id: string) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasDeleteGrade', id);
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await deleteDoc(doc(db, 'academicGrades', id));
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.DELETE,
          `academicGrades/${id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteClassesBulk = useCallback(
    async (ids: string[]) => {
      const uniqueIds = Array.from(new Set(ids)).filter(Boolean);
      if (uniqueIds.length === 0) return 0;
      if (gasMode) {
        const res = await callGas<GasMutationResponse<number>>(
          'gasDeleteClassesBulk',
          uniqueIds
        );
        applyGasSnapshot(res.snapshot);
        return res.result ?? uniqueIds.length;
      }
      requireUid();
      try {
        await runInBatches(uniqueIds, 200, (batch, id) => {
          batch.delete(doc(db, 'classes', id));
        });
        return uniqueIds.length;
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, 'classes');
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteSubjectsBulk = useCallback(
    async (ids: string[]) => {
      const uniqueIds = Array.from(new Set(ids)).filter(Boolean);
      if (uniqueIds.length === 0) return 0;
      if (gasMode) {
        const res = await callGas<GasMutationResponse<number>>(
          'gasDeleteSubjectsBulk',
          uniqueIds
        );
        applyGasSnapshot(res.snapshot);
        return res.result ?? uniqueIds.length;
      }
      requireUid();
      try {
        await runInBatches(uniqueIds, 200, (batch, id) => {
          batch.delete(doc(db, 'subjects', id));
        });
        return uniqueIds.length;
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, 'subjects');
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteGradesBulk = useCallback(
    async (ids: string[]) => {
      const uniqueIds = Array.from(new Set(ids)).filter(Boolean);
      if (uniqueIds.length === 0) return 0;
      if (gasMode) {
        const res = await callGas<GasMutationResponse<number>>(
          'gasDeleteGradesBulk',
          uniqueIds
        );
        applyGasSnapshot(res.snapshot);
        return res.result ?? uniqueIds.length;
      }
      requireUid();
      try {
        await runInBatches(uniqueIds, 200, (batch, id) => {
          batch.delete(doc(db, 'academicGrades', id));
        });
        return uniqueIds.length;
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, 'academicGrades');
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteAttitudesBulk = useCallback(
    async (ids: string[]) => {
      const uniqueIds = Array.from(new Set(ids)).filter(Boolean);
      if (uniqueIds.length === 0) return 0;
      if (gasMode) {
        const res = await callGas<GasMutationResponse<number>>(
          'gasDeleteAttitudesBulk',
          uniqueIds
        );
        applyGasSnapshot(res.snapshot);
        return res.result ?? uniqueIds.length;
      }
      requireUid();
      try {
        await runInBatches(uniqueIds, 200, (batch, id) => {
          batch.delete(doc(db, 'attitudeAssessments', id));
        });
        return uniqueIds.length;
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, 'attitudeAssessments');
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteJournalsBulk = useCallback(
    async (ids: string[]) => {
      const uniqueIds = Array.from(new Set(ids)).filter(Boolean);
      if (uniqueIds.length === 0) return 0;
      if (gasMode) {
        const res = await callGas<GasMutationResponse<number>>(
          'gasDeleteJournalsBulk',
          uniqueIds
        );
        applyGasSnapshot(res.snapshot);
        return res.result ?? uniqueIds.length;
      }
      requireUid();
      const idSet = new Set(uniqueIds);
      const relatedAttendance = attendances.filter((a) =>
        idSet.has(a.journalId)
      );
      try {
        await runInBatches(uniqueIds, 200, (batch, id) => {
          batch.delete(doc(db, 'teachingJournals', id));
        });
        await runInBatches(relatedAttendance, 200, (batch, att) => {
          batch.delete(doc(db, 'studentAttendance', att.id));
        });
        return uniqueIds.length;
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, 'teachingJournals');
      }
    },
    [applyGasSnapshot, attendances, gasMode, requireUid]
  );

  const saveBatchAttitudes = useCallback(
    async (
      entries: {
        existingId?: string;
        date: string;
        classId: string;
        subjectId: string;
        studentId: string;
        aspect: string;
        predicate: AttitudePredicate;
        notes?: string;
      }[]
    ) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>(
          'gasSaveBatchAttitudes',
          entries.map((e) => ({
            ...e,
            aspect: clampString(e.aspect, FIELD_LIMITS.ATTITUDE_ASPECT),
            notes: clampString(e.notes ?? '', FIELD_LIMITS.ATTITUDE_NOTES),
          }))
        );
        applyGasSnapshot(res.snapshot);
        return;
      }
      const uid = requireUid();
      // Each attitude write triggers 3 ownership checks (6 rule lookups) -> max 3 per batch (18 <= 20)
      try {
        await runInBatches(entries, 3, (batch, entry) => {
          if (entry.existingId) {
            batch.update(doc(db, 'attitudeAssessments', entry.existingId), {
              date: entry.date,
              classId: entry.classId,
              subjectId: entry.subjectId,
              studentId: entry.studentId,
              aspect: clampString(entry.aspect, FIELD_LIMITS.ATTITUDE_ASPECT),
              predicate: entry.predicate,
              incidentType: deleteField(),
              notes: clampString(entry.notes ?? '', FIELD_LIMITS.ATTITUDE_NOTES),
              updatedAt: serverTimestamp(),
            });
          } else {
            const ref = doc(collection(db, 'attitudeAssessments'));
            batch.set(ref, {
              ownerId: uid,
              date: entry.date,
              classId: entry.classId,
              subjectId: entry.subjectId,
              studentId: entry.studentId,
              aspect: clampString(entry.aspect, FIELD_LIMITS.ATTITUDE_ASPECT),
              predicate: entry.predicate,
              notes: clampString(entry.notes ?? '', FIELD_LIMITS.ATTITUDE_NOTES),
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          }
        });
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.WRITE,
          'attitudeAssessments'
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const updateAttitude = useCallback(
    async (
      id: string,
      input: {
        date: string;
        classId: string;
        subjectId: string;
        studentId: string;
        aspect: string;
        predicate: AttitudePredicate;
        notes?: string;
      }
    ) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasUpdateAttitude', id, {
          ...input,
          aspect: clampString(input.aspect, FIELD_LIMITS.ATTITUDE_ASPECT),
          notes: clampString(input.notes ?? '', FIELD_LIMITS.ATTITUDE_NOTES),
        });
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await updateDoc(doc(db, 'attitudeAssessments', id), {
          date: input.date,
          classId: input.classId,
          subjectId: input.subjectId,
          studentId: input.studentId,
          aspect: clampString(input.aspect, FIELD_LIMITS.ATTITUDE_ASPECT),
          predicate: input.predicate,
          incidentType: deleteField(),
          notes: clampString(input.notes ?? '', FIELD_LIMITS.ATTITUDE_NOTES),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.UPDATE,
          `attitudeAssessments/${id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteAttitude = useCallback(
    async (id: string) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasDeleteAttitude', id);
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await deleteDoc(doc(db, 'attitudeAssessments', id));
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.DELETE,
          `attitudeAssessments/${id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const saveJournalWithAttendance = useCallback(
    async (
      input: {
        id?: string;
        date: string;
        lessonHours: string;
        classId: string;
        subjectId: string;
        topic: string;
        presentCount: number;
        sickCount: number;
        permissionCount: number;
        absentCount: number;
        reflection?: string;
      },
      studentStatuses: { studentId: string; status: AttendanceStatus }[]
    ) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>(
          'gasSaveJournalWithAttendance',
          {
            ...input,
            lessonHours: clampString(
              input.lessonHours,
              FIELD_LIMITS.LESSON_HOURS
            ),
            topic: clampString(input.topic, FIELD_LIMITS.JOURNAL_TOPIC),
            presentCount: clampNumber(input.presentCount, 0, 200),
            sickCount: clampNumber(input.sickCount, 0, 200),
            permissionCount: clampNumber(input.permissionCount, 0, 200),
            absentCount: clampNumber(input.absentCount, 0, 200),
            reflection: clampString(
              input.reflection ?? '',
              FIELD_LIMITS.JOURNAL_REFLECTION
            ),
          },
          studentStatuses
        );
        applyGasSnapshot(res.snapshot);
        return;
      }
      const uid = requireUid();
      const journalRef = input.id
        ? doc(db, 'teachingJournals', input.id)
        : doc(collection(db, 'teachingJournals'));

      try {
        if (input.id) {
          await updateDoc(journalRef, {
            date: input.date,
            lessonHours: clampString(
              input.lessonHours,
              FIELD_LIMITS.LESSON_HOURS
            ),
            classId: input.classId,
            subjectId: input.subjectId,
            topic: clampString(input.topic, FIELD_LIMITS.JOURNAL_TOPIC),
            learningObjectives: deleteField(),
            presentCount: clampNumber(input.presentCount, 0, 200),
            sickCount: clampNumber(input.sickCount, 0, 200),
            permissionCount: clampNumber(input.permissionCount, 0, 200),
            absentCount: clampNumber(input.absentCount, 0, 200),
            reflection: clampString(
              input.reflection ?? '',
              FIELD_LIMITS.JOURNAL_REFLECTION
            ),
            updatedAt: serverTimestamp(),
          });
        } else {
          await setDoc(journalRef, {
            ownerId: uid,
            date: input.date,
            lessonHours: clampString(
              input.lessonHours,
              FIELD_LIMITS.LESSON_HOURS
            ),
            classId: input.classId,
            subjectId: input.subjectId,
            topic: clampString(input.topic, FIELD_LIMITS.JOURNAL_TOPIC),
            presentCount: clampNumber(input.presentCount, 0, 200),
            sickCount: clampNumber(input.sickCount, 0, 200),
            permissionCount: clampNumber(input.permissionCount, 0, 200),
            absentCount: clampNumber(input.absentCount, 0, 200),
            reflection: clampString(
              input.reflection ?? '',
              FIELD_LIMITS.JOURNAL_REFLECTION
            ),
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'teachingJournals');
      }

      if (input.id) {
        const existingAttendance = attendances.filter(
          (a) => a.journalId === input.id
        );
        try {
          await runInBatches(existingAttendance, 200, (batch, oldAtt) => {
            batch.delete(doc(db, 'studentAttendance', oldAtt.id));
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.DELETE, 'studentAttendance');
        }
      }

      // Each attendance write triggers 4 ownership checks (8 rule lookups) -> max 2 per batch (16 <= 20)
      try {
        await runInBatches(studentStatuses, 2, (batch, st) => {
          const attRef = doc(collection(db, 'studentAttendance'));
          batch.set(attRef, {
            ownerId: uid,
            journalId: journalRef.id,
            date: input.date,
            classId: input.classId,
            subjectId: input.subjectId,
            studentId: st.studentId,
            status: st.status,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'studentAttendance');
      }
    },
    [applyGasSnapshot, attendances, gasMode, requireUid]
  );

  const deleteJournal = useCallback(
    async (id: string) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasDeleteJournal', id);
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      const relatedAttendance = attendances.filter((a) => a.journalId === id);
      try {
        await deleteDoc(doc(db, 'teachingJournals', id));
        await runInBatches(relatedAttendance, 200, (batch, att) => {
          batch.delete(doc(db, 'studentAttendance', att.id));
        });
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.DELETE,
          `teachingJournals/${id}`
        );
      }
    },
    [applyGasSnapshot, attendances, gasMode, requireUid]
  );

  const addLessonSlot = useCallback(
    async (input: {
      label: string;
      startTime: string;
      endTime: string;
      order: number;
    }) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse<string>>(
          'gasAddLessonSlot',
          {
            label: clampString(input.label, FIELD_LIMITS.SLOT_LABEL),
            startTime: input.startTime,
            endTime: input.endTime,
            order: clampNumber(input.order, 0, 100),
          }
        );
        applyGasSnapshot(res.snapshot);
        return res.result;
      }
      const uid = requireUid();
      const ref = doc(collection(db, 'lessonSlots'));
      try {
        await setDoc(ref, {
          ownerId: uid,
          label: clampString(input.label, FIELD_LIMITS.SLOT_LABEL),
          startTime: input.startTime,
          endTime: input.endTime,
          order: clampNumber(input.order, 0, 100),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        return ref.id;
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.CREATE,
          `lessonSlots/${ref.id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const updateLessonSlot = useCallback(
    async (
      id: string,
      input: {
        label: string;
        startTime: string;
        endTime: string;
        order: number;
      }
    ) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>(
          'gasUpdateLessonSlot',
          id,
          {
            label: clampString(input.label, FIELD_LIMITS.SLOT_LABEL),
            startTime: input.startTime,
            endTime: input.endTime,
            order: clampNumber(input.order, 0, 100),
          }
        );
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await updateDoc(doc(db, 'lessonSlots', id), {
          label: clampString(input.label, FIELD_LIMITS.SLOT_LABEL),
          startTime: input.startTime,
          endTime: input.endTime,
          order: clampNumber(input.order, 0, 100),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.UPDATE,
          `lessonSlots/${id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteLessonSlot = useCallback(
    async (id: string) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>(
          'gasDeleteLessonSlot',
          id
        );
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      const batch = writeBatch(db);
      batch.delete(doc(db, 'lessonSlots', id));
      for (const sch of teachingSchedules.filter((s) => s.slotId === id)) {
        batch.delete(doc(db, 'teachingSchedules', sch.id));
      }
      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.DELETE,
          `lessonSlots/${id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, teachingSchedules, requireUid]
  );

  const seedDefaultLessonSlots = useCallback(async () => {
    if (gasMode) {
      const res = await callGas<GasMutationResponse>(
        'gasSeedDefaultLessonSlots',
        DEFAULT_LESSON_SLOTS
      );
      applyGasSnapshot(res.snapshot);
      return;
    }
    const uid = requireUid();
    const batch = writeBatch(db);
    for (const slot of DEFAULT_LESSON_SLOTS) {
      const ref = doc(collection(db, 'lessonSlots'));
      batch.set(ref, {
        ownerId: uid,
        label: slot.label,
        startTime: slot.startTime,
        endTime: slot.endTime,
        order: slot.order,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
    try {
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'lessonSlots');
    }
  }, [applyGasSnapshot, gasMode, requireUid]);

  const addSchedule = useCallback(
    async (input: {
      dayOfWeek: number;
      slotId: string;
      classId: string;
      subjectId: string;
    }) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse<string>>(
          'gasAddSchedule',
          {
            dayOfWeek: clampNumber(input.dayOfWeek, 0, 6),
            slotId: input.slotId,
            classId: input.classId,
            subjectId: input.subjectId,
          }
        );
        applyGasSnapshot(res.snapshot);
        return res.result;
      }
      const uid = requireUid();
      const ref = doc(collection(db, 'teachingSchedules'));
      try {
        await setDoc(ref, {
          ownerId: uid,
          dayOfWeek: clampNumber(input.dayOfWeek, 0, 6),
          slotId: input.slotId,
          classId: input.classId,
          subjectId: input.subjectId,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        return ref.id;
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.CREATE,
          `teachingSchedules/${ref.id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const updateSchedule = useCallback(
    async (
      id: string,
      input: {
        dayOfWeek: number;
        slotId: string;
        classId: string;
        subjectId: string;
      }
    ) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasUpdateSchedule', id, {
          dayOfWeek: clampNumber(input.dayOfWeek, 0, 6),
          slotId: input.slotId,
          classId: input.classId,
          subjectId: input.subjectId,
        });
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await updateDoc(doc(db, 'teachingSchedules', id), {
          dayOfWeek: clampNumber(input.dayOfWeek, 0, 6),
          slotId: input.slotId,
          classId: input.classId,
          subjectId: input.subjectId,
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.UPDATE,
          `teachingSchedules/${id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const deleteSchedule = useCallback(
    async (id: string) => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse>('gasDeleteSchedule', id);
        applyGasSnapshot(res.snapshot);
        return;
      }
      requireUid();
      try {
        await deleteDoc(doc(db, 'teachingSchedules', id));
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.DELETE,
          `teachingSchedules/${id}`
        );
      }
    },
    [applyGasSnapshot, gasMode, requireUid]
  );

  const seedSampleData = useCallback(async () => {
    if (gasMode) {
      const res = await callGas<GasMutationResponse>(
        'gasSeedSampleData',
        DEFAULT_LESSON_SLOTS.slice(0, 4)
      );
      applyGasSnapshot(res.snapshot);
      return;
    }
    const uid = requireUid();
    // Phase 1: classes and subjects
    const c1 = doc(collection(db, 'classes'));
    const c2 = doc(collection(db, 'classes'));
    const s1 = doc(collection(db, 'subjects'));
    const s2 = doc(collection(db, 'subjects'));

    const batch1 = writeBatch(db);
    batch1.set(c1, {
      ownerId: uid,
      name: 'X IPA 1',
      gradeLevel: 'Kelas X',
      academicYear: '2026/2027',
      homeroomTeacher: user?.displayName || 'Wali Kelas X IPA 1',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch1.set(c2, {
      ownerId: uid,
      name: 'X IPA 2',
      gradeLevel: 'Kelas X',
      academicYear: '2026/2027',
      homeroomTeacher: 'Dra. Siti Aminah, M.Pd.',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch1.set(s1, {
      ownerId: uid,
      code: 'MAT-10',
      name: 'Matematika Wajib',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch1.set(s2, {
      ownerId: uid,
      code: 'FIS-10',
      name: 'Fisika Dasar',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    try {
      await batch1.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'classes');
    }

    // Phase 2: students & grading categories
    const sampleStudents: {
      nis: string;
      fullName: string;
      gender: Gender;
      classId: string;
    }[] = [
      { nis: '2026101', fullName: 'Ahmad Rizky Pratama', gender: 'L', classId: c1.id },
      { nis: '2026102', fullName: 'Aulia Putri Maharani', gender: 'P', classId: c1.id },
      { nis: '2026103', fullName: 'Bagas Adriansyah', gender: 'L', classId: c1.id },
      { nis: '2026104', fullName: 'Citra Dewi Lestari', gender: 'P', classId: c1.id },
      { nis: '2026105', fullName: 'Dimas Saputra Wijaya', gender: 'L', classId: c1.id },
      { nis: '2026201', fullName: 'Fajar Ramadhan', gender: 'L', classId: c2.id },
      { nis: '2026202', fullName: 'Gita Kusuma Wardani', gender: 'P', classId: c2.id },
      { nis: '2026203', fullName: 'Hendra Gunawan', gender: 'L', classId: c2.id },
      { nis: '2026204', fullName: 'Intan Permata Sari', gender: 'P', classId: c2.id },
    ];

    const studentRefs = sampleStudents.map((st) => ({
      ref: doc(collection(db, 'students')),
      data: st,
    }));

    const catDefs = [
      { subjectId: s1.id, name: 'Tugas Harian', weight: 25 },
      { subjectId: s1.id, name: 'Ulangan Harian', weight: 25 },
      { subjectId: s1.id, name: 'PTS', weight: 25 },
      { subjectId: s1.id, name: 'PAS', weight: 25 },
    ];
    const catRefs = catDefs.map((ct) => ({
      ref: doc(collection(db, 'gradingCategories')),
      data: ct,
    }));

    try {
      await runInBatches(studentRefs, 8, (batch, item) => {
        batch.set(item.ref, {
          ownerId: uid,
          ...item.data,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
      await runInBatches(catRefs, 8, (batch, item) => {
        batch.set(item.ref, {
          ownerId: uid,
          ...item.data,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'students');
    }

    // Phase 3: grades, attitudes, journals & attendance
    const c1Students = studentRefs.filter((s) => s.data.classId === c1.id);
    const dates = ['2026-11-02', '2026-11-09', '2026-11-16'];
    const scoreMatrix = [
      [88, 84, 90],
      [92, 95, 94],
      [74, 78, 82],
      [85, 86, 89],
      [68, 72, 79],
    ];

    const sampleGrades: {
      date: string;
      categoryId: string;
      studentId: string;
      score: number;
      notes: string;
    }[] = [];
    const sampleAttitudes: {
      studentId: string;
      aspect: string;
      predicate: AttitudePredicate;
      notes: string;
    }[] = [];

    c1Students.forEach((st, idx) => {
      dates.forEach((dt, dIdx) => {
        sampleGrades.push({
          date: dt,
          categoryId: catRefs[dIdx % catRefs.length].ref.id,
          studentId: st.ref.id,
          score: scoreMatrix[idx][dIdx],
          notes: dIdx === 2 ? 'Menguasai materi fungsi kuadrat' : '',
        });
      });

      sampleAttitudes.push({
        studentId: st.ref.id,
        aspect: idx % 2 === 0 ? 'Kedisiplinan' : 'Keaktifan',
        predicate: idx === 1 ? 'Sangat Baik' : idx === 4 ? 'Cukup' : 'Baik',
        notes:
          idx === 1
            ? 'Membantu menjelaskan soal di papan tulis dengan runtut.'
            : idx === 4
            ? 'Perlu pendampingan fokus saat latihan mandiri.'
            : '',
      });
    });

    const journalRef = doc(collection(db, 'teachingJournals'));
    const slotRefs = DEFAULT_LESSON_SLOTS.slice(0, 4).map((slot) => ({
      ref: doc(collection(db, 'lessonSlots')),
      data: slot,
    }));

    try {
      await setDoc(journalRef, {
        ownerId: uid,
        date: '2026-11-16',
        lessonHours: 'Jam ke 1-2 (07:00 - 08:30)',
        classId: c1.id,
        subjectId: s1.id,
        topic: 'Persamaan dan Fungsi Kuadrat',
        presentCount: 4,
        sickCount: 1,
        permissionCount: 0,
        absentCount: 0,
        reflection:
          'Sebagian besar siswa aktif berdiskusi. Latihan pemfaktoran perlu diperkuat pada pertemuan berikutnya.',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      await Promise.all([
        runInBatches(sampleGrades, 2, (batch, g) => {
          batch.set(doc(collection(db, 'academicGrades')), {
            ownerId: uid,
            date: g.date,
            classId: c1.id,
            subjectId: s1.id,
            categoryId: g.categoryId,
            studentId: g.studentId,
            score: g.score,
            notes: g.notes,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }),
        runInBatches(sampleAttitudes, 3, (batch, att) => {
          batch.set(doc(collection(db, 'attitudeAssessments')), {
            ownerId: uid,
            date: '2026-11-16',
            classId: c1.id,
            subjectId: s1.id,
            studentId: att.studentId,
            aspect: att.aspect,
            predicate: att.predicate,
            notes: att.notes,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }),
        runInBatches(
          c1Students.map((st, idx) => ({ st, idx })),
          2,
          (batch, { st, idx }) => {
            batch.set(doc(collection(db, 'studentAttendance')), {
              ownerId: uid,
              journalId: journalRef.id,
              date: '2026-11-16',
              classId: c1.id,
              subjectId: s1.id,
              studentId: st.ref.id,
              status: idx === 4 ? 'Sakit' : 'Hadir',
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          }
        ),
        runInBatches(slotRefs, 50, (batch, sItem) => {
          batch.set(sItem.ref, {
            ownerId: uid,
            label: sItem.data.label,
            startTime: sItem.data.startTime,
            endTime: sItem.data.endTime,
            order: sItem.data.order,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }),
      ]);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'academicGrades');
    }

    // Phase 4: sample teaching schedules referencing committed slots/classes/subjects
    const batch4 = writeBatch(db);
    const todayDay = new Date().getDay();
    batch4.set(doc(collection(db, 'teachingSchedules')), {
      ownerId: uid,
      dayOfWeek: todayDay,
      slotId: slotRefs[0].ref.id,
      classId: c1.id,
      subjectId: s1.id,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch4.set(doc(collection(db, 'teachingSchedules')), {
      ownerId: uid,
      dayOfWeek: todayDay,
      slotId: slotRefs[2].ref.id,
      classId: c2.id,
      subjectId: s2.id,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    try {
      await batch4.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'teachingSchedules');
    }
  }, [applyGasSnapshot, gasMode, requireUid, user?.displayName]);

  const restoreBackupData = useCallback(
    async (
      payload: BackupDataPayload,
      mode: RestoreMode
    ): Promise<RestoreResult> => {
      if (gasMode) {
        const res = await callGas<GasMutationResponse<RestoreResult>>(
          'gasRestoreBackupData',
          payload,
          mode
        );
        applyGasSnapshot(res.snapshot);
        return res.result;
      }
      const uid = requireUid();
      const raw = payload.data ?? {};
      const backupUid = payload.metadata?.exportedBy?.uid ?? null;
      const isSameAccount = !backupUid || backupUid === uid;

      const isValidDocId = (id: unknown): id is string =>
        typeof id === 'string' &&
        id.length >= 1 &&
        id.length <= 128 &&
        /^[a-zA-Z0-9_-]+$/.test(id);

      const safeDate = (d: unknown): string => {
        if (typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d)) return d;
        const now = new Date();
        return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(
          2,
          '0'
        )}-${String(now.getDate()).padStart(2, '0')}`;
      };

      const safeTime = (t: unknown, fallback: string): string =>
        typeof t === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(t)
          ? t
          : fallback;

      const safePredicate = (p: unknown): AttitudePredicate =>
        p === 'Sangat Baik' ||
        p === 'Baik' ||
        p === 'Cukup' ||
        p === 'Perlu Bimbingan'
          ? p
          : 'Baik';

      const safeStatus = (s: unknown): AttendanceStatus =>
        s === 'Hadir' || s === 'Sakit' || s === 'Izin' || s === 'Alfa'
          ? s
          : 'Hadir';

      // Step 1: If replace mode, delete all current user documents (child -> parent)
      if (mode === 'replace') {
        const deleteIds = async (colName: string, ids: string[]) => {
          if (ids.length === 0) return;
          try {
            await runInBatches(ids, 200, (batch, id) => {
              batch.delete(doc(db, colName, id));
            });
          } catch (error) {
            handleFirestoreError(error, OperationType.DELETE, colName);
          }
        };

        await Promise.all([
          deleteIds(
            'studentAttendance',
            attendances.map((x) => x.id)
          ),
          deleteIds(
            'academicGrades',
            grades.map((x) => x.id)
          ),
          deleteIds(
            'attitudeAssessments',
            attitudes.map((x) => x.id)
          ),
        ]);
        await Promise.all([
          deleteIds(
            'teachingSchedules',
            teachingSchedules.map((x) => x.id)
          ),
          deleteIds(
            'teachingJournals',
            journals.map((x) => x.id)
          ),
          deleteIds(
            'gradingCategories',
            categories.map((x) => x.id)
          ),
          deleteIds(
            'students',
            students.map((x) => x.id)
          ),
        ]);
        await Promise.all([
          deleteIds(
            'lessonSlots',
            lessonSlots.map((x) => x.id)
          ),
          deleteIds(
            'subjects',
            subjects.map((x) => x.id)
          ),
          deleteIds(
            'classes',
            classes.map((x) => x.id)
          ),
        ]);
      }

      // Existing ID sets (empty in replace mode)
      const existingClasses =
        mode === 'merge' ? new Set(classes.map((x) => x.id)) : new Set<string>();
      const existingSubjects =
        mode === 'merge'
          ? new Set(subjects.map((x) => x.id))
          : new Set<string>();
      const existingSlots =
        mode === 'merge'
          ? new Set(lessonSlots.map((x) => x.id))
          : new Set<string>();
      const existingStudents =
        mode === 'merge'
          ? new Set(students.map((x) => x.id))
          : new Set<string>();
      const existingCategories =
        mode === 'merge'
          ? new Set(categories.map((x) => x.id))
          : new Set<string>();
      const existingJournals =
        mode === 'merge'
          ? new Set(journals.map((x) => x.id))
          : new Set<string>();
      const existingSchedules =
        mode === 'merge'
          ? new Set(teachingSchedules.map((x) => x.id))
          : new Set<string>();
      const existingGrades =
        mode === 'merge' ? new Set(grades.map((x) => x.id)) : new Set<string>();
      const existingAttitudes =
        mode === 'merge'
          ? new Set(attitudes.map((x) => x.id))
          : new Set<string>();
      const existingAttendances =
        mode === 'merge'
          ? new Set(attendances.map((x) => x.id))
          : new Set<string>();

      const resolveId = (
        colName: string,
        rawId: unknown,
        map?: Map<string, string>
      ): string => {
        if (isSameAccount && isValidDocId(rawId)) {
          map?.set(rawId, rawId);
          return rawId;
        }
        if (typeof rawId === 'string' && map?.has(rawId)) {
          return map.get(rawId)!;
        }
        const freshId = doc(collection(db, colName)).id;
        if (typeof rawId === 'string' && rawId) {
          map?.set(rawId, freshId);
        }
        return freshId;
      };

      const classIdMap = new Map<string, string>();
      const subjectIdMap = new Map<string, string>();
      const slotIdMap = new Map<string, string>();
      const studentIdMap = new Map<string, string>();
      const categoryIdMap = new Map<string, string>();
      const journalIdMap = new Map<string, string>();

      const restoredCounts: Record<string, number> = {
        classes: 0,
        subjects: 0,
        lessonSlots: 0,
        students: 0,
        gradingCategories: 0,
        teachingJournals: 0,
        teachingSchedules: 0,
        academicGrades: 0,
        attitudeAssessments: 0,
        studentAttendance: 0,
      };
      let skippedOrphans = 0;

      // Wave 1: Independent parent collections (classes, subjects, lessonSlots)
      const rawClasses = Array.isArray(raw.classes) ? raw.classes : [];
      const classItems = rawClasses.map((c) => {
        const targetId = resolveId('classes', c.id, classIdMap);
        const ay = clampString(
          String(c.academicYear ?? ''),
          FIELD_LIMITS.ACADEMIC_YEAR
        );
        return {
          targetId,
          isUpdate: existingClasses.has(targetId),
          fields: {
            name:
              clampString(String(c.name ?? ''), FIELD_LIMITS.CLASS_NAME) ||
              'Kelas',
            gradeLevel:
              clampString(
                String(c.gradeLevel ?? ''),
                FIELD_LIMITS.GRADE_LEVEL
              ) || 'Umum',
            academicYear: ay.length >= 4 ? ay : '2026/2027',
            homeroomTeacher: clampString(
              String(c.homeroomTeacher ?? ''),
              FIELD_LIMITS.HOMEROOM_TEACHER
            ),
          },
        };
      });

      const rawSubjects = Array.isArray(raw.subjects) ? raw.subjects : [];
      const subjectItems = rawSubjects.map((s) => {
        const targetId = resolveId('subjects', s.id, subjectIdMap);
        return {
          targetId,
          isUpdate: existingSubjects.has(targetId),
          fields: {
            code:
              clampString(
                String(s.code ?? ''),
                FIELD_LIMITS.SUBJECT_CODE
              ).toUpperCase() || 'MAPEL',
            name:
              clampString(String(s.name ?? ''), FIELD_LIMITS.SUBJECT_NAME) ||
              'Mata Pelajaran',
          },
        };
      });

      const rawSlots = Array.isArray(raw.lessonSlots) ? raw.lessonSlots : [];
      const slotItems = rawSlots.map((sl, idx) => {
        const targetId = resolveId('lessonSlots', sl.id, slotIdMap);
        return {
          targetId,
          isUpdate: existingSlots.has(targetId),
          fields: {
            label:
              clampString(String(sl.label ?? ''), FIELD_LIMITS.SLOT_LABEL) ||
              `Jam ke-${idx + 1}`,
            startTime: safeTime(sl.startTime, '07:00'),
            endTime: safeTime(sl.endTime, '07:45'),
            order: clampNumber(Number(sl.order ?? idx + 1), 0, 100),
          },
        };
      });

      try {
        await Promise.all([
          runInBatches(classItems, 200, (batch, item) => {
            const ref = doc(db, 'classes', item.targetId);
            if (item.isUpdate) {
              batch.update(ref, {
                ...item.fields,
                updatedAt: serverTimestamp(),
              });
            } else {
              batch.set(ref, {
                ownerId: uid,
                ...item.fields,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }),
          runInBatches(subjectItems, 200, (batch, item) => {
            const ref = doc(db, 'subjects', item.targetId);
            if (item.isUpdate) {
              batch.update(ref, {
                ...item.fields,
                updatedAt: serverTimestamp(),
              });
            } else {
              batch.set(ref, {
                ownerId: uid,
                ...item.fields,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }),
          runInBatches(slotItems, 200, (batch, item) => {
            const ref = doc(db, 'lessonSlots', item.targetId);
            if (item.isUpdate) {
              batch.update(ref, {
                ...item.fields,
                updatedAt: serverTimestamp(),
              });
            } else {
              batch.set(ref, {
                ownerId: uid,
                ...item.fields,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }),
        ]);
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'classes');
      }

      restoredCounts.classes = classItems.length;
      restoredCounts.subjects = subjectItems.length;
      restoredCounts.lessonSlots = slotItems.length;

      const knownClassIds = new Set<string>([
        ...existingClasses,
        ...classItems.map((x) => x.targetId),
      ]);
      const knownSubjectIds = new Set<string>([
        ...existingSubjects,
        ...subjectItems.map((x) => x.targetId),
      ]);
      const knownSlotIds = new Set<string>([
        ...existingSlots,
        ...slotItems.map((x) => x.targetId),
      ]);

      // Wave 2: students, gradingCategories, teachingJournals, teachingSchedules
      const rawStudents = Array.isArray(raw.students) ? raw.students : [];
      const studentItems = rawStudents
        .map((st) => {
          const mappedClassId =
            classIdMap.get(String(st.classId ?? '')) ??
            (isSameAccount && isValidDocId(st.classId) ? st.classId : '');
          if (!mappedClassId || !knownClassIds.has(mappedClassId)) {
            skippedOrphans += 1;
            return null;
          }
          const targetId = resolveId('students', st.id, studentIdMap);
          return {
            targetId,
            isUpdate: existingStudents.has(targetId),
            fields: {
              nis:
                clampString(String(st.nis ?? ''), FIELD_LIMITS.STUDENT_NIS) ||
                '000',
              fullName:
                clampString(
                  String(st.fullName ?? ''),
                  FIELD_LIMITS.STUDENT_NAME
                ) || 'Siswa',
              gender: (st.gender === 'P' ? 'P' : 'L') as Gender,
              classId: mappedClassId,
            },
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null);

      const rawCategories = Array.isArray(raw.gradingCategories)
        ? raw.gradingCategories
        : [];
      const categoryItems = rawCategories
        .map((cat) => {
          const mappedSubjectId =
            subjectIdMap.get(String(cat.subjectId ?? '')) ??
            (isSameAccount && isValidDocId(cat.subjectId)
              ? cat.subjectId
              : '');
          if (!mappedSubjectId || !knownSubjectIds.has(mappedSubjectId)) {
            skippedOrphans += 1;
            return null;
          }
          const targetId = resolveId(
            'gradingCategories',
            cat.id,
            categoryIdMap
          );
          return {
            targetId,
            isUpdate: existingCategories.has(targetId),
            fields: {
              subjectId: mappedSubjectId,
              name:
                clampString(
                  String(cat.name ?? ''),
                  FIELD_LIMITS.CATEGORY_NAME
                ) || 'Kategori',
              weight: clampNumber(Number(cat.weight ?? 0), 0, 100),
            },
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null);

      const rawJournals = Array.isArray(raw.teachingJournals)
        ? raw.teachingJournals
        : [];
      const journalItems = rawJournals
        .map((j) => {
          const mappedClassId =
            classIdMap.get(String(j.classId ?? '')) ??
            (isSameAccount && isValidDocId(j.classId) ? j.classId : '');
          const mappedSubjectId =
            subjectIdMap.get(String(j.subjectId ?? '')) ??
            (isSameAccount && isValidDocId(j.subjectId) ? j.subjectId : '');
          if (
            !mappedClassId ||
            !knownClassIds.has(mappedClassId) ||
            !mappedSubjectId ||
            !knownSubjectIds.has(mappedSubjectId)
          ) {
            skippedOrphans += 1;
            return null;
          }
          const targetId = resolveId('teachingJournals', j.id, journalIdMap);
          return {
            targetId,
            isUpdate: existingJournals.has(targetId),
            fields: {
              date: safeDate(j.date),
              lessonHours:
                clampString(
                  String(j.lessonHours ?? ''),
                  FIELD_LIMITS.LESSON_HOURS
                ) || 'Jam ke-1',
              classId: mappedClassId,
              subjectId: mappedSubjectId,
              topic:
                clampString(
                  String(j.topic ?? ''),
                  FIELD_LIMITS.JOURNAL_TOPIC
                ) || 'Materi Pembelajaran',
              presentCount: clampNumber(Number(j.presentCount ?? 0), 0, 200),
              sickCount: clampNumber(Number(j.sickCount ?? 0), 0, 200),
              permissionCount: clampNumber(
                Number(j.permissionCount ?? 0),
                0,
                200
              ),
              absentCount: clampNumber(Number(j.absentCount ?? 0), 0, 200),
              reflection: clampString(
                String(j.reflection ?? ''),
                FIELD_LIMITS.JOURNAL_REFLECTION
              ),
            },
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null);

      const rawSchedules = Array.isArray(raw.teachingSchedules)
        ? raw.teachingSchedules
        : [];
      const scheduleItems = rawSchedules
        .map((sch) => {
          const mappedSlotId =
            slotIdMap.get(String(sch.slotId ?? '')) ??
            (isSameAccount && isValidDocId(sch.slotId) ? sch.slotId : '');
          const mappedClassId =
            classIdMap.get(String(sch.classId ?? '')) ??
            (isSameAccount && isValidDocId(sch.classId) ? sch.classId : '');
          const mappedSubjectId =
            subjectIdMap.get(String(sch.subjectId ?? '')) ??
            (isSameAccount && isValidDocId(sch.subjectId)
              ? sch.subjectId
              : '');
          if (
            !mappedSlotId ||
            !knownSlotIds.has(mappedSlotId) ||
            !mappedClassId ||
            !knownClassIds.has(mappedClassId) ||
            !mappedSubjectId ||
            !knownSubjectIds.has(mappedSubjectId)
          ) {
            skippedOrphans += 1;
            return null;
          }
          const targetId = resolveId('teachingSchedules', sch.id);
          return {
            targetId,
            isUpdate: existingSchedules.has(targetId),
            fields: {
              dayOfWeek: clampNumber(Number(sch.dayOfWeek ?? 1), 0, 6),
              slotId: mappedSlotId,
              classId: mappedClassId,
              subjectId: mappedSubjectId,
            },
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null);

      try {
        await Promise.all([
          runInBatches(studentItems, 8, (batch, item) => {
            const ref = doc(db, 'students', item.targetId);
            if (item.isUpdate) {
              batch.update(ref, {
                ...item.fields,
                updatedAt: serverTimestamp(),
              });
            } else {
              batch.set(ref, {
                ownerId: uid,
                ...item.fields,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }),
          runInBatches(categoryItems, 4, (batch, item) => {
            const ref = doc(db, 'gradingCategories', item.targetId);
            if (item.isUpdate) {
              batch.update(ref, {
                ...item.fields,
                classId: deleteField(),
                updatedAt: serverTimestamp(),
              });
            } else {
              batch.set(ref, {
                ownerId: uid,
                ...item.fields,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }),
          runInBatches(journalItems, 4, (batch, item) => {
            const ref = doc(db, 'teachingJournals', item.targetId);
            if (item.isUpdate) {
              batch.update(ref, {
                ...item.fields,
                learningObjectives: deleteField(),
                updatedAt: serverTimestamp(),
              });
            } else {
              batch.set(ref, {
                ownerId: uid,
                ...item.fields,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }),
          runInBatches(scheduleItems, 3, (batch, item) => {
            const ref = doc(db, 'teachingSchedules', item.targetId);
            if (item.isUpdate) {
              batch.update(ref, {
                ...item.fields,
                updatedAt: serverTimestamp(),
              });
            } else {
              batch.set(ref, {
                ownerId: uid,
                ...item.fields,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }),
        ]);
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'students');
      }

      restoredCounts.students = studentItems.length;
      restoredCounts.gradingCategories = categoryItems.length;
      restoredCounts.teachingJournals = journalItems.length;
      restoredCounts.teachingSchedules = scheduleItems.length;

      const knownStudentIds = new Set<string>([
        ...existingStudents,
        ...studentItems.map((x) => x.targetId),
      ]);
      const knownCategoryIds = new Set<string>([
        ...existingCategories,
        ...categoryItems.map((x) => x.targetId),
      ]);
      const knownJournalIds = new Set<string>([
        ...existingJournals,
        ...journalItems.map((x) => x.targetId),
      ]);

      // Wave 3: academicGrades, attitudeAssessments, studentAttendance
      const rawGrades = Array.isArray(raw.academicGrades)
        ? raw.academicGrades
        : [];
      const gradeItems = rawGrades
        .map((g) => {
          const mappedClassId =
            classIdMap.get(String(g.classId ?? '')) ??
            (isSameAccount && isValidDocId(g.classId) ? g.classId : '');
          const mappedSubjectId =
            subjectIdMap.get(String(g.subjectId ?? '')) ??
            (isSameAccount && isValidDocId(g.subjectId) ? g.subjectId : '');
          const mappedCategoryId =
            categoryIdMap.get(String(g.categoryId ?? '')) ??
            (isSameAccount && isValidDocId(g.categoryId) ? g.categoryId : '');
          const mappedStudentId =
            studentIdMap.get(String(g.studentId ?? '')) ??
            (isSameAccount && isValidDocId(g.studentId) ? g.studentId : '');
          if (
            !knownClassIds.has(mappedClassId) ||
            !knownSubjectIds.has(mappedSubjectId) ||
            !knownCategoryIds.has(mappedCategoryId) ||
            !knownStudentIds.has(mappedStudentId)
          ) {
            skippedOrphans += 1;
            return null;
          }
          const targetId = resolveId('academicGrades', g.id);
          const cleanType: AssessmentType | undefined =
            g.assessmentType === 'sumatif'
              ? 'sumatif'
              : g.assessmentType === 'formatif'
              ? 'formatif'
              : undefined;
          const cleanChapter = clampString(
            String(g.chapter ?? ''),
            FIELD_LIMITS.GRADE_CHAPTER
          );
          const rawOrder = Number(g.assessmentOrder);
          const cleanOrder =
            Number.isFinite(rawOrder) && rawOrder >= 1
              ? clampNumber(Math.round(rawOrder), 1, 20)
              : undefined;
          const cleanLabel = clampString(
            String(g.assessmentLabel ?? ''),
            FIELD_LIMITS.GRADE_ASSESSMENT_LABEL
          );
          return {
            targetId,
            isUpdate: existingGrades.has(targetId),
            fields: {
              date: safeDate(g.date),
              classId: mappedClassId,
              subjectId: mappedSubjectId,
              categoryId: mappedCategoryId,
              studentId: mappedStudentId,
              score: clampNumber(Number(g.score ?? 0), 0, 100),
              assessmentType: cleanType,
              chapter: cleanChapter,
              assessmentOrder: cleanOrder,
              assessmentLabel: cleanLabel,
              notes: clampString(
                String(g.notes ?? ''),
                FIELD_LIMITS.GRADE_NOTES
              ),
            },
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null);

      const rawAttitudes = Array.isArray(raw.attitudeAssessments)
        ? raw.attitudeAssessments
        : [];
      const attitudeItems = rawAttitudes
        .map((a) => {
          const mappedClassId =
            classIdMap.get(String(a.classId ?? '')) ??
            (isSameAccount && isValidDocId(a.classId) ? a.classId : '');
          const mappedSubjectId =
            subjectIdMap.get(String(a.subjectId ?? '')) ??
            (isSameAccount && isValidDocId(a.subjectId) ? a.subjectId : '');
          const mappedStudentId =
            studentIdMap.get(String(a.studentId ?? '')) ??
            (isSameAccount && isValidDocId(a.studentId) ? a.studentId : '');
          if (
            !knownClassIds.has(mappedClassId) ||
            !knownSubjectIds.has(mappedSubjectId) ||
            !knownStudentIds.has(mappedStudentId)
          ) {
            skippedOrphans += 1;
            return null;
          }
          const targetId = resolveId('attitudeAssessments', a.id);
          return {
            targetId,
            isUpdate: existingAttitudes.has(targetId),
            fields: {
              date: safeDate(a.date),
              classId: mappedClassId,
              subjectId: mappedSubjectId,
              studentId: mappedStudentId,
              aspect:
                clampString(
                  String(a.aspect ?? ''),
                  FIELD_LIMITS.ATTITUDE_ASPECT
                ) || 'Kedisiplinan',
              predicate: safePredicate(a.predicate),
              notes: clampString(
                String(a.notes ?? ''),
                FIELD_LIMITS.ATTITUDE_NOTES
              ),
            },
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null);

      const rawAttendances = Array.isArray(raw.studentAttendance)
        ? raw.studentAttendance
        : [];
      const attendanceItems = rawAttendances
        .map((att) => {
          const mappedJournalId =
            journalIdMap.get(String(att.journalId ?? '')) ??
            (isSameAccount && isValidDocId(att.journalId) ? att.journalId : '');
          const mappedClassId =
            classIdMap.get(String(att.classId ?? '')) ??
            (isSameAccount && isValidDocId(att.classId) ? att.classId : '');
          const mappedSubjectId =
            subjectIdMap.get(String(att.subjectId ?? '')) ??
            (isSameAccount && isValidDocId(att.subjectId)
              ? att.subjectId
              : '');
          const mappedStudentId =
            studentIdMap.get(String(att.studentId ?? '')) ??
            (isSameAccount && isValidDocId(att.studentId)
              ? att.studentId
              : '');
          if (
            !knownJournalIds.has(mappedJournalId) ||
            !knownClassIds.has(mappedClassId) ||
            !knownSubjectIds.has(mappedSubjectId) ||
            !knownStudentIds.has(mappedStudentId)
          ) {
            skippedOrphans += 1;
            return null;
          }
          const targetId = resolveId('studentAttendance', att.id);
          return {
            targetId,
            isUpdate: existingAttendances.has(targetId),
            fields: {
              journalId: mappedJournalId,
              date: safeDate(att.date),
              classId: mappedClassId,
              subjectId: mappedSubjectId,
              studentId: mappedStudentId,
              status: safeStatus(att.status),
            },
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null);

      try {
        await Promise.all([
          runInBatches(gradeItems, 2, (batch, item) => {
            const ref = doc(db, 'academicGrades', item.targetId);
            const {
              assessmentType,
              chapter,
              assessmentOrder,
              assessmentLabel,
              ...baseFields
            } = item.fields;
            if (item.isUpdate) {
              batch.update(ref, {
                ...baseFields,
                assessmentType: assessmentType ? assessmentType : deleteField(),
                chapter: chapter ? chapter : deleteField(),
                assessmentOrder: assessmentOrder
                  ? assessmentOrder
                  : deleteField(),
                assessmentLabel: assessmentLabel
                  ? assessmentLabel
                  : deleteField(),
                updatedAt: serverTimestamp(),
              });
            } else {
              const payload: Record<string, unknown> = {
                ownerId: uid,
                ...baseFields,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              };
              if (assessmentType) payload.assessmentType = assessmentType;
              if (chapter) payload.chapter = chapter;
              if (assessmentOrder) payload.assessmentOrder = assessmentOrder;
              if (assessmentLabel) payload.assessmentLabel = assessmentLabel;
              batch.set(ref, payload);
            }
          }),
          runInBatches(attitudeItems, 3, (batch, item) => {
            const ref = doc(db, 'attitudeAssessments', item.targetId);
            if (item.isUpdate) {
              batch.update(ref, {
                ...item.fields,
                incidentType: deleteField(),
                updatedAt: serverTimestamp(),
              });
            } else {
              batch.set(ref, {
                ownerId: uid,
                ...item.fields,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }),
          runInBatches(attendanceItems, 2, (batch, item) => {
            const ref = doc(db, 'studentAttendance', item.targetId);
            if (item.isUpdate) {
              batch.update(ref, {
                ...item.fields,
                updatedAt: serverTimestamp(),
              });
            } else {
              batch.set(ref, {
                ownerId: uid,
                ...item.fields,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }),
        ]);
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'academicGrades');
      }

      restoredCounts.academicGrades = gradeItems.length;
      restoredCounts.attitudeAssessments = attitudeItems.length;
      restoredCounts.studentAttendance = attendanceItems.length;

      const totalRestored = Object.values(restoredCounts).reduce(
        (sum, n) => sum + n,
        0
      );

      return {
        restoredCounts,
        totalRestored,
        skippedOrphans,
      };
    },
    [
      requireUid,
      attendances,
      grades,
      attitudes,
      teachingSchedules,
      journals,
      categories,
      students,
      lessonSlots,
      subjects,
      classes,
    ]
  );

  const value = useMemo<AppContextValue>(
    () => ({
      user,
      currentUserProfile,
      userProfiles,
      isAdmin,
      authReady,
      profileReady,
      dataLoading,
      authError,
      storageMode,
      spreadsheetUrl,
      theme,
      toggleTheme,
      clearAuthError,
      signInWithAdmin,
      registerTeacher,
      updateOwnProfile,
      createUserAccount,
      updateManagedUser,
      deleteManagedUserProfile,
      logout,
      classes,
      subjects,
      students,
      categories,
      grades,
      attitudes,
      journals,
      attendances,
      lessonSlots,
      teachingSchedules,
      addClass,
      updateClass,
      deleteClass,
      addSubject,
      updateSubject,
      deleteSubject,
      addStudent,
      updateStudent,
      deleteStudent,
      deleteStudentsBulk,
      bulkImportStudents,
      addCategory,
      updateCategory,
      deleteCategory,
      saveBatchGrades,
      updateGrade,
      deleteGrade,
      deleteClassesBulk,
      deleteSubjectsBulk,
      deleteGradesBulk,
      deleteAttitudesBulk,
      deleteJournalsBulk,
      saveBatchAttitudes,
      updateAttitude,
      deleteAttitude,
      saveJournalWithAttendance,
      deleteJournal,
      addLessonSlot,
      updateLessonSlot,
      deleteLessonSlot,
      seedDefaultLessonSlots,
      addSchedule,
      updateSchedule,
      deleteSchedule,
      seedSampleData,
      restoreBackupData,
    }),
    [
      user,
      currentUserProfile,
      userProfiles,
      isAdmin,
      authReady,
      profileReady,
      dataLoading,
      authError,
      storageMode,
      spreadsheetUrl,
      theme,
      toggleTheme,
      clearAuthError,
      signInWithAdmin,
      registerTeacher,
      updateOwnProfile,
      createUserAccount,
      updateManagedUser,
      deleteManagedUserProfile,
      logout,
      classes,
      subjects,
      students,
      categories,
      grades,
      attitudes,
      journals,
      attendances,
      lessonSlots,
      teachingSchedules,
      addClass,
      updateClass,
      deleteClass,
      addSubject,
      updateSubject,
      deleteSubject,
      addStudent,
      updateStudent,
      deleteStudent,
      deleteStudentsBulk,
      bulkImportStudents,
      addCategory,
      updateCategory,
      deleteCategory,
      saveBatchGrades,
      updateGrade,
      deleteGrade,
      deleteClassesBulk,
      deleteSubjectsBulk,
      deleteGradesBulk,
      deleteAttitudesBulk,
      deleteJournalsBulk,
      saveBatchAttitudes,
      updateAttitude,
      deleteAttitude,
      saveJournalWithAttendance,
      deleteJournal,
      addLessonSlot,
      updateLessonSlot,
      deleteLessonSlot,
      seedDefaultLessonSlots,
      addSchedule,
      updateSchedule,
      deleteSchedule,
      seedSampleData,
      restoreBackupData,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
