import React, { useMemo, useState } from 'react';
import {
  Award,
  BookOpen,
  ClipboardList,
  FileSpreadsheet,
  GraduationCap,
  Home,
  Layers,
  LogOut,
  Menu,
  Moon,
  NotebookPen,
  School,
  Settings,
  ShieldCheck,
  Sun,
  Users,
  X,
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { MenuKey } from '../types';
import { SchoolLogo } from './SchoolLogo';

export interface NavItem {
  key: MenuKey;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  adminOnly?: boolean;
}

export const NAV_ITEMS: NavItem[] = [
  { key: 'beranda', label: 'Beranda', icon: Home },
  { key: 'kelas', label: 'Kelas', icon: School },
  { key: 'mapel', label: 'Mata Pelajaran', icon: BookOpen },
  { key: 'siswa', label: 'Siswa', icon: GraduationCap },
  { key: 'kategori', label: 'Kategori Penilaian', icon: Layers },
  { key: 'nilai', label: 'Penilaian Akademik', icon: ClipboardList },
  { key: 'sikap', label: 'Penilaian Sikap', icon: Award },
  { key: 'jurnal', label: 'Jurnal Mengajar', icon: NotebookPen },
  { key: 'laporan', label: 'Laporan', icon: FileSpreadsheet },
  {
    key: 'pengguna',
    label: 'Manajemen Pengguna',
    icon: Users,
    adminOnly: true,
  },
  { key: 'pengaturan', label: 'Pengaturan', icon: Settings },
];

interface LayoutProps {
  activeMenu: MenuKey;
  onSelectMenu: (key: MenuKey) => void;
  children: React.ReactNode;
}

export function Layout({ activeMenu, onSelectMenu, children }: LayoutProps) {
  const {
    user,
    currentUserProfile,
    isAdmin,
    logout,
    classes,
    theme,
    toggleTheme,
    storageMode,
  } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);

  const visibleNavItems = useMemo(
    () => NAV_ITEMS.filter((item) => !item.adminOnly || isAdmin),
    [isAdmin]
  );

  const activeNav =
    visibleNavItems.find((n) => n.key === activeMenu) ?? visibleNavItems[0];
  const latestAcademicYear =
    classes[0]?.academicYear || 'Tahun Ajaran 2026/2027';

  const displayName =
    currentUserProfile?.displayName ||
    user?.displayName ||
    (isAdmin ? 'Administrator' : 'Guru Pengajar');

  const handleSelect = (key: MenuKey) => {
    onSelectMenu(key);
    setMobileOpen(false);
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800">
      <div className="h-16 px-4 flex items-center justify-between border-b border-slate-200 dark:border-slate-800 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-lg bg-slate-950 p-0.5 border border-slate-800/80 dark:border-slate-700/70 shrink-0 flex items-center justify-center overflow-hidden">
            <SchoolLogo className="w-full h-full object-contain" />
          </div>
          <div className="min-w-0">
            <span className="block font-display font-bold text-sm tracking-tight text-slate-900 dark:text-slate-100 truncate">
              SMP Zainul Hasan
            </span>
            <span className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 truncate">
              Genggong · Lentera Guru
            </span>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setMobileOpen(false)}
          className="lg:hidden p-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 rounded-md"
          aria-label="Tutup menu"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {visibleNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeMenu === item.key;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => handleSelect(item.key)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              <Icon
                className={`w-4 h-4 shrink-0 ${
                  isActive
                    ? 'text-blue-700 dark:text-blue-400'
                    : 'text-slate-400 dark:text-slate-500'
                }`}
              />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-200 dark:border-slate-800 shrink-0 space-y-3">
        <div className="flex items-start gap-3">
          {user?.photoURL ? (
            <img
              src={user.photoURL}
              alt={displayName}
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
            />
          ) : (
            <div className="w-9 h-9 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 flex items-center justify-center font-display font-semibold text-sm shrink-0">
              {(displayName || user?.email || 'G').charAt(0).toUpperCase()}
            </div>
          )}
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
              {displayName}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
              {currentUserProfile?.email || user?.email}
            </p>
            <div className="mt-1.5 flex items-center gap-1.5">
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold border ${
                  isAdmin
                    ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300'
                    : 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                }`}
              >
                {isAdmin && <ShieldCheck className="w-3 h-3 shrink-0" />}
                <span>{isAdmin ? 'Administrator' : 'Guru'}</span>
              </span>
            </div>
          </div>
        </div>

        {storageMode === 'gas' ? (
          <div className="w-full flex items-center justify-center gap-2 px-3 py-2 text-[11px] font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/70 rounded-lg">
            <span>Google Apps Script · Spreadsheet</span>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => void logout()}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 shrink-0" />
            <span>Keluar Akun</span>
          </button>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 no-print sticky top-0 h-screen">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex no-print">
          <div
            className="fixed inset-0 bg-slate-950/60"
            onClick={() => setMobileOpen(false)}
          />
          <div className="relative w-72 max-w-[85vw] h-full z-10">
            {sidebarContent}
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 md:px-8 flex items-center justify-between gap-4 sticky top-0 z-30 no-print">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 -ml-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-slate-100 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Buka navigasi"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="text-slate-400 dark:text-slate-500 hidden sm:inline whitespace-nowrap">
                SMP Zainul Hasan Genggong
              </span>
              <span
                className="text-slate-300 dark:text-slate-700 hidden sm:inline"
                aria-hidden="true"
              >
                /
              </span>
              <span className="font-display font-semibold text-slate-900 dark:text-slate-100 truncate">
                {activeNav.label}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400 shrink-0">
            <span className="hidden sm:inline whitespace-nowrap">
              {latestAcademicYear}
            </span>
            <button
              type="button"
              onClick={toggleTheme}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              title="Ubah tema gelap atau terang"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Mode Terang</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  <span>Mode Gelap</span>
                </>
              )}
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 md:p-8 max-w-[1400px] w-full mx-auto print-container">
          {children}
        </main>
      </div>
    </div>
  );
}
