import { useState } from 'react';

interface SchoolLogoProps {
  className?: string;
}

export function SchoolLogo({ className = 'w-full h-full object-contain' }: SchoolLogoProps) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <svg
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
        aria-label="Logo SMP Zainul Hasan Genggong"
      >
        <rect width="48" height="48" rx="10" fill="#0F172A" />
        <rect
          x="3"
          y="3"
          width="42"
          height="42"
          rx="8"
          stroke="#38BDF8"
          strokeOpacity="0.45"
          strokeWidth="1.5"
        />
        <path
          d="M24 9L36 14.5V23.5C36 30.8 30.8 36.8 24 39C17.2 36.8 12 30.8 12 23.5V14.5L24 9Z"
          fill="#1E3A8A"
          stroke="#60A5FA"
          strokeWidth="1.5"
        />
        <text
          x="24"
          y="27"
          textAnchor="middle"
          fill="#F8FAFC"
          fontSize="12"
          fontWeight="700"
          fontFamily="sans-serif"
        >
          ZH
        </text>
      </svg>
    );
  }

  return (
    <img
      src="/assets/aistudio/Logo_ZAHA_4f061485.png"
      alt="Logo SMP Zainul Hasan Genggong"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
