import { useState } from 'react';
import { LogOut, ShieldAlert } from 'lucide-react';
import { AuthGate } from './components/AuthGate';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Layout } from './components/Layout';
import { SchoolLogo } from './components/SchoolLogo';
import { AppProvider, useApp } from './contexts/AppContext';
import { BerandaPage } from './pages/BerandaPage';
import { JurnalPage } from './pages/JurnalPage';
import { KategoriPage } from './pages/KategoriPage';
import { KelasPage } from './pages/KelasPage';
import { LaporanPage } from './pages/LaporanPage';
import { MapelPage } from './pages/MapelPage';
import { NilaiAkademikPage } from './pages/NilaiAkademikPage';
import { PengaturanPage } from './pages/PengaturanPage';
import { PenggunaPage } from './pages/PenggunaPage';
import { SikapPage } from './pages/SikapPage';
import { SiswaPage } from './pages/SiswaPage';
import { MenuKey } from './types';

function AppShell() {
  const {
    user,
    currentUserProfile,
    isAdmin,
    authReady,
    profileReady,
    storageMode,
    logout,
  } = useApp();
  const [activeMenu, setActiveMenu] = useState<MenuKey>('beranda');

  if (!authReady || (user && !profileReady)) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-6">
        <div className="text-sm text-slate-500 dark:text-slate-400">
          Memuat aplikasi...
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthGate />;
  }

  if (currentUserProfile?.status === 'inactive') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-4">
          <div className="w-14 h-14 mx-auto rounded-xl bg-slate-950 p-1.5 border border-slate-800 flex items-center justify-center overflow-hidden">
            <SchoolLogo className="w-full h-full object-contain" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs font-semibold text-red-700 dark:text-red-300">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>Akun Dinonaktifkan</span>
          </div>
          <h1 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">
            Akses Akun Anda Sedang Ditangguhkan
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            Akun{' '}
            <span className="font-mono text-slate-800 dark:text-slate-200">
              {currentUserProfile.email || user.email}
            </span>{' '}
            saat ini berstatus nonaktif. Silakan hubungi Administrator SMP
            Zainul Hasan Genggong untuk mengaktifkan kembali akses Anda.
          </p>
          {storageMode !== 'gas' && (
            <button
              type="button"
              onClick={() => void logout()}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-lg transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4 shrink-0" />
              <span>Keluar Akun</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  const effectiveMenu: MenuKey =
    activeMenu === 'pengguna' && !isAdmin ? 'beranda' : activeMenu;

  return (
    <Layout activeMenu={effectiveMenu} onSelectMenu={setActiveMenu}>
      {effectiveMenu === 'beranda' && <BerandaPage onNavigate={setActiveMenu} />}
      {effectiveMenu === 'kelas' && <KelasPage />}
      {effectiveMenu === 'mapel' && <MapelPage />}
      {effectiveMenu === 'siswa' && <SiswaPage />}
      {effectiveMenu === 'kategori' && <KategoriPage />}
      {effectiveMenu === 'nilai' && <NilaiAkademikPage />}
      {effectiveMenu === 'sikap' && <SikapPage />}
      {effectiveMenu === 'jurnal' && <JurnalPage />}
      {effectiveMenu === 'laporan' && <LaporanPage />}
      {effectiveMenu === 'pengguna' && isAdmin && <PenggunaPage />}
      {effectiveMenu === 'pengaturan' && <PengaturanPage />}
    </Layout>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <AppShell />
      </AppProvider>
    </ErrorBoundary>
  );
}
