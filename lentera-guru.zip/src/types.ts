export type MenuKey =
  | 'beranda'
  | 'kelas'
  | 'mapel'
  | 'siswa'
  | 'kategori'
  | 'nilai'
  | 'sikap'
  | 'jurnal'
  | 'laporan'
  | 'pengguna'
  | 'pengaturan';

export type UserRole = 'admin' | 'guru';

export type UserStatus = 'active' | 'inactive';

export interface UserProfile {
  id: string;
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  status: UserStatus;
  nip?: string;
  subjectSpecialty?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type Gender = 'L' | 'P';

export type AttitudePredicate =
  | 'Sangat Baik'
  | 'Baik'
  | 'Cukup'
  | 'Perlu Bimbingan';

export type AttendanceStatus = 'Hadir' | 'Sakit' | 'Izin' | 'Alfa';

export interface SchoolClass {
  id: string;
  ownerId: string;
  name: string;
  gradeLevel: string;
  academicYear: string;
  homeroomTeacher?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Subject {
  id: string;
  ownerId: string;
  code: string;
  name: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Student {
  id: string;
  ownerId: string;
  nis: string;
  fullName: string;
  gender: Gender;
  classId: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface GradingCategory {
  id: string;
  ownerId: string;
  classId?: string;
  subjectId: string;
  name: string;
  weight: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type AssessmentType = 'formatif' | 'sumatif';

export interface AcademicGrade {
  id: string;
  ownerId: string;
  date: string;
  classId: string;
  subjectId: string;
  categoryId: string;
  studentId: string;
  score: number;
  assessmentType?: AssessmentType;
  chapter?: string;
  assessmentOrder?: number;
  assessmentLabel?: string;
  notes?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AttitudeAssessment {
  id: string;
  ownerId: string;
  date: string;
  classId: string;
  subjectId: string;
  studentId: string;
  aspect: string;
  predicate: AttitudePredicate;
  notes?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface TeachingJournal {
  id: string;
  ownerId: string;
  date: string;
  lessonHours: string;
  classId: string;
  subjectId: string;
  topic: string;
  presentCount: number;
  sickCount: number;
  permissionCount: number;
  absentCount: number;
  reflection?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface StudentAttendance {
  id: string;
  ownerId: string;
  journalId: string;
  date: string;
  classId: string;
  subjectId: string;
  studentId: string;
  status: AttendanceStatus;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface LessonSlot {
  id: string;
  ownerId: string;
  label: string;
  startTime: string;
  endTime: string;
  order: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface TeachingSchedule {
  id: string;
  ownerId: string;
  dayOfWeek: number; // 0=Minggu, 1=Senin..6=Sabtu
  slotId: string;
  classId: string;
  subjectId: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export const INDONESIAN_DAYS: { value: number; label: string }[] = [
  { value: 1, label: 'Senin' },
  { value: 2, label: 'Selasa' },
  { value: 3, label: 'Rabu' },
  { value: 4, label: 'Kamis' },
  { value: 5, label: 'Jumat' },
  { value: 6, label: 'Sabtu' },
  { value: 0, label: 'Minggu' },
];

export const DEFAULT_LESSON_SLOTS: {
  label: string;
  startTime: string;
  endTime: string;
  order: number;
}[] = [
  { label: 'Jam ke-1', startTime: '07:00', endTime: '07:45', order: 1 },
  { label: 'Jam ke-2', startTime: '07:45', endTime: '08:30', order: 2 },
  { label: 'Jam ke-3', startTime: '08:30', endTime: '09:15', order: 3 },
  { label: 'Jam ke-4', startTime: '09:30', endTime: '10:15', order: 4 },
  { label: 'Jam ke-5', startTime: '10:15', endTime: '11:00', order: 5 },
  { label: 'Jam ke-6', startTime: '11:00', endTime: '11:45', order: 6 },
  { label: 'Jam ke-7', startTime: '12:30', endTime: '13:15', order: 7 },
  { label: 'Jam ke-8', startTime: '13:15', endTime: '14:00', order: 8 },
];

export const ATTITUDE_ASPECTS = [
  'Kedisiplinan',
  'Tanggung Jawab',
  'Kerja Sama',
  'Keaktifan',
  'Kejujuran',
] as const;

export const ATTITUDE_PREDICATES: AttitudePredicate[] = [
  'Sangat Baik',
  'Baik',
  'Cukup',
  'Perlu Bimbingan',
];

export const ATTENDANCE_STATUSES: AttendanceStatus[] = [
  'Hadir',
  'Sakit',
  'Izin',
  'Alfa',
];

export const MIN_ASSESSMENTS_PER_BAB = 3;

export const DEFAULT_BAB_OPTIONS = [
  'Bab 1',
  'Bab 2',
  'Bab 3',
  'Bab 4',
  'Bab 5',
  'Bab 6',
  'Bab 7',
  'Bab 8',
] as const;

export const SUMATIF_SCOPE_OPTIONS = [
  'Sumatif Lingkup Materi (Bab 1)',
  'Sumatif Lingkup Materi (Bab 2)',
  'Sumatif Lingkup Materi (Bab 3)',
  'Sumatif Lingkup Materi (Bab 4)',
  'Sumatif Tengah Semester (STS/PTS)',
  'Sumatif Akhir Semester (SAS/PAS)',
] as const;

export function isSumatifCategoryName(categoryName?: string): boolean {
  const lower = (categoryName ?? '').toLowerCase();
  return (
    lower.includes('sumatif') ||
    lower.includes('ulangan') ||
    lower.includes('pts') ||
    lower.includes('pas') ||
    lower.includes('sts') ||
    lower.includes('sas') ||
    lower.includes('uts') ||
    lower.includes('uas') ||
    lower.includes('pat') ||
    lower.includes('akhir')
  );
}

export function isCategoryForAssessmentType(
  categoryName: string,
  assessmentType: AssessmentType
): boolean {
  if (assessmentType === 'sumatif') {
    return isSumatifCategoryName(categoryName);
  }
  return !isSumatifCategoryName(categoryName);
}

export function resolveGradeAssessmentType(
  grade: Pick<AcademicGrade, 'assessmentType'>,
  categoryName?: string
): AssessmentType {
  if (
    grade.assessmentType === 'sumatif' ||
    grade.assessmentType === 'formatif'
  ) {
    return grade.assessmentType;
  }
  if (isSumatifCategoryName(categoryName)) {
    return 'sumatif';
  }
  return 'formatif';
}

export const FIELD_LIMITS = {
  CLASS_NAME: 60,
  GRADE_LEVEL: 40,
  ACADEMIC_YEAR: 20,
  HOMEROOM_TEACHER: 100,
  SUBJECT_CODE: 24,
  SUBJECT_NAME: 100,
  STUDENT_NIS: 30,
  STUDENT_NAME: 120,
  CATEGORY_NAME: 60,
  GRADE_CHAPTER: 60,
  GRADE_ASSESSMENT_LABEL: 60,
  GRADE_NOTES: 300,
  ATTITUDE_ASPECT: 60,
  ATTITUDE_NOTES: 500,
  LESSON_HOURS: 60,
  SLOT_LABEL: 60,
  JOURNAL_TOPIC: 200,
  JOURNAL_REFLECTION: 1000,
  USER_DISPLAY_NAME: 120,
  USER_EMAIL: 160,
  USER_NIP: 40,
  USER_SPECIALTY: 120,
} as const;
