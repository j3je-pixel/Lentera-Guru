import {
  AcademicGrade,
  AttitudeAssessment,
  GradingCategory,
  LessonSlot,
  SchoolClass,
  Student,
  StudentAttendance,
  Subject,
  TeachingJournal,
  TeachingSchedule,
  UserProfile,
} from '../types';

interface GoogleScriptRunBuilder {
  withSuccessHandler: <T = unknown>(
    callback: (result: T) => void
  ) => GoogleScriptRunBuilder;
  withFailureHandler: (
    callback: (error: Error) => void
  ) => GoogleScriptRunBuilder;
}

declare global {
  interface Window {
    google?: {
      script?: {
        run?: GoogleScriptRunBuilder;
      };
    };
  }
}

export interface GasSnapshot {
  classes: SchoolClass[];
  subjects: Subject[];
  students: Student[];
  categories: GradingCategory[];
  grades: AcademicGrade[];
  attitudes: AttitudeAssessment[];
  journals: TeachingJournal[];
  attendances: StudentAttendance[];
  lessonSlots: LessonSlot[];
  teachingSchedules: TeachingSchedule[];
  userProfile?: UserProfile | null;
  userProfiles?: UserProfile[];
}

export interface GasBootstrapResponse {
  user: {
    uid: string;
    email: string;
    displayName: string;
  };
  userProfile?: UserProfile | null;
  spreadsheetUrl: string;
  spreadsheetName: string;
  snapshot: GasSnapshot;
}

export interface GasMutationResponse<T = void> {
  result: T;
  snapshot: GasSnapshot;
}

export function isGasEnvironment(): boolean {
  return (
    typeof window !== 'undefined' &&
    typeof window.google?.script?.run !== 'undefined'
  );
}

export function callGas<T>(
  functionName: string,
  ...args: unknown[]
): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const runner = window.google?.script?.run;
    if (!runner) {
      reject(new Error('Google Apps Script runtime tidak tersedia.'));
      return;
    }

    const builder = runner
      .withSuccessHandler((res) => resolve(res as T))
      .withFailureHandler((err) => {
        const message =
          err instanceof Error
            ? err.message
            : typeof err === 'string'
            ? err
            : 'Terjadi kesalahan pada Google Apps Script.';
        reject(new Error(message));
      });

    const fn = (
      builder as unknown as Record<string, ((...args: unknown[]) => void) | undefined>
    )[functionName];
    if (typeof fn !== 'function') {
      reject(new Error(`Fungsi Apps Script "${functionName}" tidak ditemukan.`));
      return;
    }

    fn.apply(builder, args);
  });
}
